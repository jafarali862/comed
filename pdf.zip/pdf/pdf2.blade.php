<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Od Report Reliance</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div style="text-align: right;">
        <img src="image.png" alt="">
    </div>


    <div style="text-align: center;">
        <h4>
            OD INVESTIGATION REPORT-RELIANCE
        </h4>
    </div>

    <table>
        <tr>
            <td>Claim no</td>
            <td>3124276798</td>
        </tr>
        <tr>
            <td>Name of insured</td>
            <td>MR VINOD V K</td>
        </tr>
        <tr>
            <td>Insured’s Address & contact No</td>
            <td>VINOD BHAVAN, KAROOR, AMBALAPPUZHA, ALAPPUZHA 688561. PH: 9745993320</td>
        </tr>
        <tr>
            <td>Vehicle No</td>
            <td>KL04AJ7236</td>
        </tr>
        <tr>
            <td>Vehicle make & model</td>
            <td>MARUTI SUZUKI INDIA LTD & MARUTI WAGON R VXI BSIV</td>
        </tr>
        <tr>
            <td>Date of Loss</td>
            <td>12.10.2024</td>
        </tr>
        <tr>
            <td>Claim intimation to Call center, if any delay specify the no. of days</td>
            <td>15.10.2024, 3 days delay in intimation to the company</td>
        </tr>
        <tr>
            <td>Investigator Name</td>
            <td>ERG ASSOCIATES</td>
        </tr>
        <tr>
            <td>Report Submitting date</td>
            <td>02.11.2024</td>
        </tr>

        <tr>
            <td>Policy details</td>
            <td>99179242311051719</td>
        </tr>
        <tr>
            <td>Policy period</td>
            <td>30.08.2024 TO 29.08.2025</td>
        </tr>
        <tr>
            <td>Policy type</td>
            <td>Private car comprehensive Policy</td>
        </tr>
        <tr>
            <td>FIR & Panchanama Details</td>
            <td>A GD entry registered at Edathwa Police station vide GD No:12-22/10/2024 dated 22.10.2024. (A copy of
                the same is attached with it.)</td>
        </tr>
        <tr>
            <td>Injury & Hospital Details</td>
            <td>No one in the IV had any injuries by this accident.</td>
        </tr>
        <tr>
            <td>No of passengers at the time of loss with ages</td>
            <td>1. Mr. Vinod K <br> 2. Mrs. Lekshmi (insured wife) <br> 3. Gagana (insured daughter)</td>
        </tr>
        <tr>
            <td>Gate entry date</td>
            <td>13.10.2024</td>
        </tr>
        <tr>
            <td>Job card date</td>
            <td>14.10.2024</td>
        </tr>
        <tr>
            <td>Google timeline of insured and driver</td>
            <td>Insured GTL collected, it shows no visit.</td>
        </tr>
        <tr>
            <td>Towing Receipt</td>
            <td>The vehicle was towed to garage by S.S Crane and services. (towing receipt attached.)</td>
        </tr>

    </table>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="text-align: end;">
                <img src="image.png">
            </div>


            <table>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 25;">Investigation Report -{{$finalReport->insurance_com_name}}</p>
                    </th>
                </tr>
                <tr>
                    <td>Name of Customer</td>
                    <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td>Contact Details of Customer</td>
                    <td><br>{{ $finalReport->customer_present_address ?? 'N/A' }}<br/>
                   
                        <br>Phone no:{{ $finalReport->customer_phone ?? 'N/A' }} <br>Email: {{ $finalReport->customer_email ?? 'N/A' }}
                    </td>
                </tr>

                 <tr>
                    <td>Policy Date</td>
                    <td>       
                    {{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }} - 

                    {{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}
                    </td>
                </tr>


                 <tr>
                    <td>Policy No</td>
                    <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Crime Number</td>
                    <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Police Station</td>
                    <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>Case Type</td>
                    <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>Investigation Date</td>
                    <td>  {{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
                </tr>




            </table>
            <br>


            <table border="1">

                <!-- <tr>
                    <td>Claim No</td>
                    <td>MOT15119272</td>
                </tr>
                <tr>
                    <td>Interaction No.</td>
                    <td>NA</td>
                </tr> -->
@php
    $groupedQuestions = $validQuestions12->groupBy('data_category');


    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <!-- <tr> -->
        <!-- <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th> -->
    <!-- </tr> -->

    @foreach($questions->where('input_type', '!=', 'file') as $question)
        @php
            $answer = $finalReport->{$question->column_name} ?? null;
        @endphp

        @if(!empty($answer))
            <tr>
                <td>{{ $question->question }}</td>
                <td>{{ $answer }}</td>
            </tr>
        @endif
    @endforeach
@endforeach



                
               
              
            </table>


            <br>
           <table>
                <!-- <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                        <p style="font-size: 10;">Findings on Google map timelines – Insured & Driver</p>
                    </th>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center; ">
                        <p style="font-size: 10;">IV RIDER GTL collected and attached with it.</p>
                    </td>
                </tr>
                <tr>
                    <th colspan="2" style="text-align: center; background-color: aquamarine;">
                    </th>
                </tr>
                <tr>
                    <td><img src="picture1.png" alt=""></td>
                    <td><img src="picture2.png" alt=""></td>
                </tr>
                <tr>
                    <td><img src="picture3.png" alt=""></td>
                    <td><img src="picture4.png" alt=""></td>
                </tr> -->

    @php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Filter groups where at least one file question has data in finalReport
    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)
    <tr>
        <th colspan="2" style="background-color: #d3d3d3; text-transform: uppercase;">
            {{ str_replace('_', ' ', $category) }}
        </th>
    </tr>

    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;
            $isImage = false;

            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }
        @endphp

        @if(!empty($filePath))
            <tr>
                <td>{{ $question->question }}</td>
                <td>
                    @if($isImage)
                        <img src="{{ asset('storage/' . $filePath) }}" alt="{{ $question->question }}" style="max-width:150px; max-height:150px;">
                    @else
                        <a href="{{ asset('storage/' . $filePath) }}" target="_blank">View File</a>
                    @endif
                </td>
            </tr>
        @endif
    @endforeach
@endforeach




            </table>
           
            
            <h4>FACTS, FINDINGS AND FINAL CONCLUSION:</h4>
            <ul>

                <li>On vehicle verification, the damages are tally with accident description.</li>
                <li>Further enquiry at the spot, the spot is tally with vehicle damages.</li>
                <li>Insured provided the accident time photos and its properties, while verifying the same it reveals
                    the
                    loss date and genuineness of the accident.(Accident time photos and properties attached with it.)
                </li>
                <li>Insured provided IV rider Aswanth’s medical document from Hridalaya Hospital, Pettah and while
                    verifying the same it is mentioned that “RTA sustained injuries to R knee” . (Medical document
                    attached
                    with it.)</li>
                <li>Further on concerned hospital enquiry, the hospital authorities confirm that he took treatment from
                    there.(Video recording attached with it)</li>
                <li>Insured and IV driver had valid DL at the time of accident. No other suspected trigger observed in
                    addition.</li>

            </ul>
            <h4> Considering the above facts and findings we come to the conclusion that the case is genuine.</h4>
            <br>
            <br>
            <br>

            <div style="display: flex; justify-content: space-between;">
                <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}
<br>THIRUVANATHAPURAM</div>
                <div>ANOOP N G <br> <img src="sign.png"> </div>
            </div>

        </div>
    </div>
</body>

</html>
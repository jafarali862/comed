<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyLogo extends Model
{
    use HasFactory;

     protected $fillable = ['name', 'email', 'phone', 'place', 'logo','template','logo_path'];
}

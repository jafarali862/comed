<?php

namespace App\Http\Controllers;

use App\Models\CompanyLogo;
use Illuminate\Http\Request;

class LogoManagenentController extends Controller
{

    public function index()
    {
        $logos = CompanyLogo::paginate(10);
        return view('dashboard.logo.index', compact('logos'));
    }

    public function getLogo()
    {
        return view('dashboard.logo.create');
    }

    public function storeLogo(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:company_logos,email',
            'phone' => 'required|string|max:15',
            'place' => 'required|string|max:255',
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            
        ]);

        
        if ($request->hasFile('logo')) {
           
            $logoPath = $request->file('logo')->store('logos', 'public');
        }

        CompanyLogo::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'place' => $request->place,
            'logo' => $logoPath,
            
        ]);

        return redirect()->route('logos')->with('success', 'Company logo added successfully!');
    }

    public function editLogo($id)
    {
        
        $logo = CompanyLogo::findOrFail($id);
        return view('dashboard.logo.edit', compact('logo'));
    }

   public function updateLogo(Request $request, $id)
    {

  $request->validate([
        'name'      => 'required|string|max:255',
        'email'     => 'required|email|unique:company_logos,email,' . $id,
        'phone'     => 'required|string|max:15',
        'place'     => 'required|string|max:255',
        'logo'      => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        'logo_path' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:150', // 150 KB max
    ]);

    $logo = CompanyLogo::findOrFail($id);
    $logo->name = $request->name;
    $logo->email = $request->email;
    $logo->phone = $request->phone;
    $logo->place = $request->place;

    // Upload plain logo
    if ($request->hasFile('logo')) {
        if ($logo->logo && Storage::disk('public')->exists($logo->logo)) {
            Storage::disk('public')->delete($logo->logo);
        }

        $path = $request->file('logo')->store('logos', 'public');
        $logo->logo = $path;
    }

    // Upload processed logo (logo_path)
    if ($request->hasFile('logo_path')) {
    // Delete existing logo if it exists
    if ($logo->logo_path && Storage::disk('public')->exists($logo->logo_path)) {
        Storage::disk('public')->delete($logo->logo_path);
    }

    $file = $request->file('logo_path');
    $extension = $file->getClientOriginalExtension();

    // Generate a unique filename
    $filename = 'company_logo_' . time() . '_' . Str::random(5) . '.' . $extension;

    // Save the file to storage/app/public/logos/
    $path = $file->storeAs('logos', $filename, 'public');

    // Save the path in the database
    $logo->logo_path = $path;
}

    $logo->save();

    session()->flash('success', 'Company logo updated successfully!');
    return redirect()->route('logo.edit', ['id' => $id]);

    }
}

<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InsuranceCompany;
use App\Models\Question;
use App\Models\Template;
use App\Models\User;
use App\Models\CompanyLogo;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;
use App\Models\QuestionTemplate;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Storage;




class CompanyController extends Controller
{
   
    public function index(Request $request)
    {
        $search = $request->input('search', '');

       $company = InsuranceCompany::with('templateModel') // eager load template
    ->when(!empty($search), function ($query) use ($search) {
        $query->where(function ($q) use ($search) {
            $q->where('name', 'like', '%' . $search . '%')
              ->orWhere('email', 'like', '%' . $search . '%')
              ->orWhere('phone', 'like', '%' . $search . '%');
        });
    })
    ->orderBy('created_at', 'desc') 
    ->paginate(15);


        return view("dashboard.company.index")->with(['companies'=>$company]);
    }


    public function create()
    {
    $templates = Template::all();

    return view("dashboard.company.create",compact("templates"));
    }

     public function getLogoPath()
    {

    // Assuming there's only one record
    $logo = CompanyLogo::first();

    if (!$logo || !$logo->logo_path) {
        return response()->json([
            'success' => false,
            'message' => 'Logo not found.',
        ], 404);
    }

    return response()->json([
        'success'    => true,
        'name'  => $logo->name,
        'logo_url'   => Storage::url($logo->logo_path),
    ]);

    }
    
    public function create_question()
    {
    return view("dashboard.company.create_question");
    }


      public function questionsByTemplate($templateId)
    {
    // Template::findOrFail($templateId);

    $questionIds = QuestionTemplate::where('template_id', $templateId)
                    ->pluck('question_id');

    $questions = Question::whereIn('id', $questionIds)
                ->get()
                ->groupBy('data_category'); 

    return response()->json([
    'questions_by_category' => $questions
    ]);
    }

 
    public function getQuestionsByCategory($category)
    {

    $validCategories = [
        'garage_data', 'spot_data', 'owner_data',
        'driver_data', 'accident_person_data'
    ];

    if (!in_array($category, $validCategories)) 
    {
    return response()->json(['error' => 'Invalid category'], 400);
    }

    return Question::where('data_category', $category)->get();
    }


    public function index_question(Request $request)
    {

       $search = $request->input('search', '');

        $questions = Question::when(!empty($search), function ($query) use ($search) {
        $query->where(function ($q) use ($search) {
        $q->where('question', 'like', '%' . $search . '%')
        ->orWhere('input_type', 'like', '%' . $search . '%')
        ->orWhere('data_category', 'like', '%' . $search . '%');
        });
        })
        ->orderBy('created_at', 'desc')
        ->get();

        return view('dashboard.company.index_question', compact('questions', 'search'));

       

    }

    public function create_templates()
    {

    // $companies = InsuranceCompany::all(); 
    // return view('dashboard.company.create_templates', compact('companies'));
    $companies = InsuranceCompany::all(); 
    $questions = Question::all()->groupBy('data_category');
    return view('dashboard.company.create_templates', compact('questions','companies'));

    }

    public function list_templates()
    {
    // $templates = Template::with('company')->get();

    $templates = Template::with('questions')->get();

    return view('dashboard.company.list_templates', compact('templates'));
    }

    public function edit_templates($id)
    {
    $template = Template::with('questions')->findOrFail($id);
        $companies = InsuranceCompany::all(); 
    // Group questions by data_category
    $questions = Question::all()->groupBy('data_category');

    return view('dashboard.company.edit_templates', compact('template', 'questions','companies'));
    }


    // public function update_templates(Request $request, $id)
    // {
    // $request->validate([
    // 'questions' => 'required|array'
    // ]);

    // $template = Template::findOrFail($id);

    // $template->questions()->sync($request->questions);
    // return response()->json([
    // 'success' => 'Template updated successfully',
    // 'redirect_url' => route('templates.list_templates')
    // ]);
    // }



   public function update_templates(Request $request, $id)
{
    // Validate inputs
    $request->validate([
        'company_id' => 'required|exists:insurance_companies,id',
        'questions' => 'required|array',
        'template_logo' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:1024', // 1MB
    ]);

    // Find template
    $template = Template::findOrFail($id);

    // Get selected company
    $company = InsuranceCompany::findOrFail($request->company_id);

    // Update company_id
    $template->company_id = $company->id;

    // Generate template ID based on company
    $shortCode = $this->generateCompanyCode($company->name);
    $templateId = 'TEMPLATE_' . $shortCode;
    $template->template_id = $templateId;

    // Handle logo upload
    if ($request->hasFile('template_logo')) {
        // Delete old logo if exists
        if ($template->template_logo && \Storage::disk('public')->exists($template->template_logo)) {
            \Storage::disk('public')->delete($template->template_logo);
        }

        // Store new logo
        $file = $request->file('template_logo');
        $filename = 'template_logo_' . $shortCode . '_' . time() . '_' . \Str::random(5) . '.' . $file->getClientOriginalExtension();
        $logoPath = $file->storeAs('template_logos', $filename, 'public');
        $template->template_logo = $logoPath;
    }

    // Save template
    $template->save();

    // Sync questions
    $template->questions()->sync($request->questions);

    // Return JSON response
    return response()->json([
        'success' => 'Template updated successfully',
        'redirect_url' => route('templates.list_templates')
    ]);
}



     public function caseReportView($executive_id, Request $request)
    {
    $period = $request->query('period', 'daily'); // default to daily
    $data = $this->getCaseReportData($executive_id, $period);

    if (!$data) 
    {
    return abort(404, 'Invalid period');
    }

    $executive = User::find($executive_id);

    if(!$executive) 
    {
    return abort(404, 'Executive not found');
    }

    return view('dashboard.case.report', compact('data', 'executive_id','executive'));
    }

    public function odometerList($executive_id, Request $request)
{
    $period = $request->query('period', 'daily'); // same as report page


     $executive = User::find($executive_id);

    if(!$executive) 
    {
    return abort(404, 'Executive not found');
    }

    $startDate = match ($period) {
        'daily' => Carbon::today(),
        'weekly' => Carbon::now()->startOfWeek(),
        'monthly' => Carbon::now()->startOfMonth(),
        default => null,
    };
    $endDate = Carbon::now();

    if (!$startDate) 
    {
        return abort(404, 'Invalid period');
    }


    $odometerReadings = OdometerReading::where('user_id', $executive_id)
        ->whereBetween('created_at', [$startDate, $endDate])
        ->orderBy('created_at', 'desc')
        ->get();

    return view('dashboard.case.odometer', compact('odometerReadings', 'executive_id', 'period', 'startDate', 'endDate','executive'));
}


public function caseexecutiveList($executive_id, Request $request)
{
    $period = $request->query('period', 'daily'); // same as report page


     $executive = User::find($executive_id);

    if(!$executive) 
    {
    return abort(404, 'Executive not found');
    }

    $startDate = match ($period) {
        'daily' => Carbon::today(),
        'weekly' => Carbon::now()->startOfWeek(),
        'monthly' => Carbon::now()->startOfMonth(),
        default => null,
    };
    $endDate = Carbon::now();

    if (!$startDate) {
        return abort(404, 'Invalid period');
    }


    $caselist = DB::table('case_assignments')
                ->join('insurance_customers', 'case_assignments.customer_id', '=', 'insurance_customers.id') // Assuming customer_id is in case_assignments
                ->join('insurance_companies', 'insurance_customers.company_id', '=', 'insurance_companies.id') // Correct foreign key relation
                ->where(function ($q) use ($executive_id) {
                $q->where('executive_driver', $executive_id)
                ->orWhere('executive_garage', $executive_id)
                ->orWhere('executive_spot', $executive_id)
                ->orWhere('executive_meeting', $executive_id)
                ->orWhere('executive_accident_person', $executive_id);
                })
                ->whereBetween('case_assignments.created_at', [$startDate, $endDate])
                ->orderBy('case_assignments.created_at', 'desc')
                ->select('case_assignments.date','insurance_companies.name as company_name','insurance_customers.policy_no',
                'insurance_customers.name as customer_name', 'insurance_customers.email','insurance_customers.crime_number',
                'insurance_customers.insurance_type', 'insurance_customers.police_station','insurance_customers.phone as customer_phone')
                ->get();

    return view('dashboard.case.caselist', compact('caselist', 'executive_id', 'period', 'startDate', 'endDate','executive'));
}




    private function getCaseReportData($executive_id, $period)
    {
    $startDate = match ($period) {
    'daily' => Carbon::today(),
    'weekly' => Carbon::now()->startOfWeek(),
    'monthly' => Carbon::now()->startOfMonth(),
    default => null,
    };

    if (!$startDate) {
    return null;
    }

    $query = DB::table('case_assignments')
    ->where(function ($q) use ($executive_id) {
        $q->where('executive_driver', $executive_id)
            ->orWhere('executive_garage', $executive_id)
            ->orWhere('executive_spot', $executive_id)
            ->orWhere('executive_meeting', $executive_id)
            ->orWhere('executive_accident_person', $executive_id);
    })
    ->whereDate('created_at', '>=', $startDate);

    return [
    'executive_id' => $executive_id,
    'period' => $period,
    'start_date' => $startDate->toDateString(),
    'new' => (clone $query)->where('status', 1)->count(),
    'completed' => (clone $query)->where('status', 2)->count(),
    ];

    }


    public function caseReportApi($executive_id, Request $request)
    {
    $period = $request->query('period', 'daily'); // default to daily
    $data = $this->getCaseReportData($executive_id, $period);

    if (!$data) 
    {
    return response()->json([
            'error' => 'Invalid period. Use ?period=daily, weekly, or monthly.'
    ], 400);
    }

    return response()->json($data);
    }


    public function destroy_templates($id)
    {
    $template = Template::findOrFail($id);

    $template->questions()->detach(); // remove relations
    $template->delete();

    return redirect()->route('templates.list_templates')
    ->with('success', 'Template deleted successfully!');
    }

    public function preview($id)
    {
    $template = Template::with('questions')->findOrFail($id);
    return view('dashboard.company.preview_template_modal', compact('template'));
    }


    public function store_templates(Request $request)
    {

       
        // $request->validate([
        // 'company_id' => 'required|exists:insurance_companies,id',
        // 'questions' => 'required|array',
        // 'template_logo' => 'nullable|image|mimes:jpeg,jpg,png,webp', // 1MB
        // ]);

        // $company = InsuranceCompany::findOrFail($request->company_id);

        // $shortCode = $this->generateCompanyCode($company->name);
        // $templateId = 'TEMPLATE_' . $shortCode;

        // if (Template::where('template_id', $templateId)->exists()) {
        // return back()->withErrors(['error' => 'Template already exists for this company.']);
        // }

        // $logoPath = null;
        // if ($request->hasFile('template_logo')) {
        // $file = $request->file('template_logo');
        // $filename = 'template_logo_' . $shortCode . '_' . time() . '_' . Str::random(5) . '.' . $file->getClientOriginalExtension();
        // $logoPath = $file->storeAs('template_logos', $filename, 'public');
        // }

    
        // $template = Template::create([
        // 'template_id' => $templateId,
        // 'company_id'  => $company->id,
        // 'template_logo'  => $logoPath,
        // ]);

        // $template->questions()->attach($request->questions);

        // return response()->json([
        // 'success' => 'Template created successfully for ' . $company->name,
        // 'template_id' => $templateId,
        // 'redirect_url' => route('templates.list_templates'),
        // ]);


         $request->validate([
        'company_id' => 'required|exists:insurance_companies,id',
        'questions' => 'required|array',
        'template_logo' => 'nullable|image|mimes:jpeg,jpg,png,webp',
        ]);

        $company = InsuranceCompany::findOrFail($request->company_id);

        $shortCode = $this->generateCompanyCode($company->name);
        $templateId = 'TEMPLATE_' . $shortCode;

        if (Template::where('template_id', $templateId)->exists()) 
        {
        // return back()->withErrors(['error' => 'Template already exists for this company.']);
        return response()->json([
        'errors' => [
            'company_id' => ['Template already exists for this company.']
        ]
        ], 422);
        }

        $logoPath = null;
        if ($request->hasFile('template_logo')) 
        {
        $file = $request->file('template_logo');
        $filename = 'template_logo_' . $shortCode . '_' . time() . '_' . Str::random(5) . '.' . $file->getClientOriginalExtension();
        $logoPath = $file->storeAs('template_logos', $filename, 'public');
        }

        $template = Template::create([
        'template_id' => $templateId,
        'company_id'  => $company->id,
        'template_logo'  => $logoPath,
        ]);

        $template->questions()->attach($request->questions);

        return response()->json([
        'success' => 'Template created successfully for ' . $company->name,
        'template_id' => $templateId,
        'redirect_url' => route('templates.list_templates'),
        ]);
        
    }

    protected function generateCompanyCode(string $companyName): string
    {
    $code = strtoupper($companyName);
    $code = preg_replace('/[^A-Z0-9]/', '_', $code); // Replace non-alphanumerics with _
    $code = preg_replace('/_+/', '_', $code);        // Collapse multiple underscores
    return trim($code, '_');
    }

    
   public function store_question(Request $request)
   {

    $validated = $request->validate([
        'question' => 'required|string|max:255',
        'input_type' => 'required|in:text,textarea,select,file,date',
        'data_category' => 'required|in:garage_data,spot_data,owner_data,driver_data,accident_person_data',
        'file_type' => 'required_if:input_type,file|in:image,audio|nullable|string',
    ]);

    $question = $validated['question'];
    $inputType = $validated['input_type'];
    $dataCategory = $validated['data_category'];
    $fileType = $request->file_type ?? null;

    $tableName = $dataCategory;
    $oldTableName = $tableName . '_old';

    if (!Schema::hasTable($tableName)) 
    {
    Schema::create($tableName, function (Blueprint $table) {
    $table->id();
    $table->timestamps();
    });
    }

    if (!Schema::hasTable($oldTableName)) {
    Schema::create($oldTableName, function (Blueprint $table) {
    $table->id();
    $table->unsignedBigInteger('assign_work_id')->nullable();
    $table->unsignedBigInteger('executive_id')->nullable();
    $table->timestamps();
    });
    }

    $columnName = Str::slug($question, '_');


    foreach ([$tableName, $oldTableName] as $table) 
    {
    if (!Schema::hasColumn($table, $columnName)) 
    {
    Schema::table($table, function (Blueprint $tableBlueprint) use ($columnName, $inputType, $dataCategory) 
    {
    switch ($inputType) 
    {
    case 'text':
    case 'select':
    case 'file':
    if ($dataCategory === 'accident_person_data') {
        $tableBlueprint->text($columnName)->nullable(); // prevent row size error
    } else {
        $tableBlueprint->string($columnName)->nullable();
    }
    break;

    case 'textarea':
    $tableBlueprint->text($columnName)->nullable();
    break;

    case 'date':
    $tableBlueprint->date($columnName)->nullable();
    break;
    }
    });
    }
    }

    do 
    {
    $uniqueKey = '#' . strtoupper(Str::random(5)) . rand(10, 99);
    } 

    while (Question::where('unique_key', $uniqueKey)->exists());

    // Store question
    Question::create([
        'question'      => $question,
        'input_type'    => $inputType,
        'data_category' => $dataCategory,
        'column_name'   => $columnName,
        'unique_key'    => $uniqueKey,
        'file_type'     => $fileType,
    ]);

    // return response()->json(['success' => 'Questionnaire added successfully']);
    
    return response()->json([
    'success' => 'Questionnaire added successfully',
    'redirect_url' => route('questions.index_question') // pass the redirect URL too
    ]);

    }



    public function edit_question($id)
    {
        $question = Question::findOrFail($id);
        return view('dashboard.company.edit_question', compact('question'));
    }

    public function update_question(Request $request, $id)
    {
        $validated = $request->validate([
        'question' => 'required|string|max:255',
        'input_type' => 'required|in:text,textarea,select,file,date',
        'data_category' => 'required|in:garage_data,spot_data,owner_data,driver_data',
        ]);

        $question = Question::findOrFail($id);

        $oldColumn = $question->column_name;
        $newColumn = Str::slug($validated['question'], '_');
        $tableName = $validated['data_category'];

        if ($oldColumn !== $newColumn && Schema::hasColumn($tableName, $oldColumn)) {
        // Get the column type and nullability
        $column = DB::selectOne("
        SELECT COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_NAME = ? AND COLUMN_NAME = ? AND TABLE_SCHEMA = DATABASE()
        ", [$tableName, $oldColumn]);

        if ($column) {
        $columnType = $column->COLUMN_TYPE;
        $nullable = $column->IS_NULLABLE === 'YES' ? 'NULL' : 'NOT NULL';
        $default = $column->COLUMN_DEFAULT !== null ? "DEFAULT '" . addslashes($column->COLUMN_DEFAULT) . "'" : '';

        // Use raw SQL with full column definition
        DB::statement("
            ALTER TABLE `$tableName` CHANGE `$oldColumn` `$newColumn` $columnType $nullable $default
        ");
        } 
        else 
        {
        // Fail gracefully
        return back()->with('error', 'Failed to retrieve column info for renaming.');
        }
    }

    // Continue updating question record
    $question->update([
    'question' => $validated['question'],
    'input_type' => $validated['input_type'],
    'data_category' => $validated['data_category'],
    'column_name' => $newColumn,
    ]);
   return response()->json([
    'success' => 'Questionnaire updated successfully',
    'redirect_url' => route('questions.index_question') // pass the redirect URL too
]);


    // return redirect()->route('questions.index_question')->with('success', 'Questionnaire updated successfully.');

    }

    public function destroy_question($id)
    {
    $question = Question::findOrFail($id);
    $tableName = $question->data_category;
    $column = $question->column_name;

    if (Schema::hasColumn($tableName, $column)) {
    Schema::table($tableName, function (Blueprint $table) use ($column) {
        $table->dropColumn($column);
    });
    }

    $question->delete();

    return redirect()->route('questions.index_question')->with('success', 'Questionnaire deleted successfully.');
    }


        public function store(Request $request)
    {

        $request->validate([
        'name'            => 'required|string|max:255',
        'contact_person'  => 'required|string|max:255',
        'phone'           => 'required|unique:insurance_companies,phone',
        'email'           => 'required|email|unique:insurance_companies,email',
        'address'         => 'required|string',
        'template'        => 'required',
    ]);

    $finalQuestionnaire = [];
    $selectedTabs = [];
    $selectedQuestions = $request->input('selected_questions', []);

    // Define tab name mapping
    $tabNameMap = [
    'owner'           => 'meeting',
    'accident_person' => 'accident',
    ];

    if (is_array($selectedQuestions)) 
    {
    foreach ($selectedQuestions as $tab => $fields) 
    {
    if (!empty($fields)) 
    {
    $cleanTab = $tab;
    if (str_ends_with($tab, '_data')) 
    {
    $cleanTab = substr($tab, 0, -strlen('_data'));
    }

    $mappedTab = $tabNameMap[$cleanTab] ?? $cleanTab;

    $selectedTabs[] = $mappedTab;

    foreach ($fields as $field) 
    {
    $type = $request->input("question_types.$tab.$field", 'select');
    $label = ucwords(str_replace('_', ' ', $field));
    $label = strlen($label) > 20 ? substr($label, 0, 17) . '...' : $label;

    $fieldData = [
    'name'     => $field,
    'label'    => $label,
    'type'     => $type,
    'required' => false,
    ];

    if ($type === 'file') 
    {
    $fileType = $request->input("file_types.$tab.$field", null);
    $fieldData['file_type'] = $fileType;
    }

    if ($type === 'select') 
    {
    $fieldData['options'] = [
    ['label' => 'Yes', 'value' => 1],
    ['label' => 'No', 'value' => 0],
    ['label' => 'Other', 'value' => 2],
    ];
    }

    $finalQuestionnaire[$mappedTab][$field] = $fieldData;
    }
    }
    }
    }


    $company = InsuranceCompany::create([
        'name'            => $request->name,
        'contact_person'  => $request->contact_person,
        'phone'           => $request->phone,
        'email'           => $request->email,
        'address'         => $request->address,
        'template'        => $request->template,
        'country_code'    => $request->country_code,
        'status'          => 1,
        'create_by'       => Auth::id(),
        'update_by'       => Auth::id(),
        'selected_tabs'   => $selectedTabs,
        'questionnaires'  => $finalQuestionnaire,
    ]);

        // return response()->json(['success' => 'Company added and table "' . $tableName . '" created successfully.']);

        // return response()->json(['success' => 'Company added successfully']);
          return response()->json([
        'success' => 'Company added successfully',
        'redirect_url' => route('company.list') // pass the redirect URL too
        ]);
    

    // $request->validate([
    //     'name'            => 'required|string|max:255',
    //     'contact_person'  => 'required|string|max:255',
    //     'phone'           => 'required|unique:insurance_companies,phone',
    //     'email'           => 'required|email|unique:insurance_companies,email',
    //     'address'         => 'required|string',
    //     'template'        => 'required',
    // ]);


    // $selectedQuestions = $request->input('selected_questions', []);
    // $hasAtLeastOneCheckbox = false;

    // foreach ($selectedQuestions as $fields) {
    //     if (!empty($fields)) {
    //         $hasAtLeastOneCheckbox = true;
    //         break;
    //     }
    // }

    // if (!$hasAtLeastOneCheckbox) {
    //     return response()->json([
    //         'errors' => ['selected_questions' => ['Please select at least one checkbox in any category.']],
    //     ], 422);
    // }

    // $finalQuestionnaire = [];
    // $selectedTabs = [];

    // foreach ($selectedQuestions as $tab => $fields) {
    //     if (!empty($fields)) {
    //         $selectedTabs[] = $tab;
    //         foreach ($fields as $field) {
    //             $type = $request->input("question_types.$tab.$field", 'select');

    //             $fieldData = [
    //                 'name'     => $field,
    //                 'label'    => ucwords(str_replace('_', ' ', $field)),
    //                 'type'     => $type,
    //                 'required' => false,
    //             ];

    //             if ($type === 'file') {
    //                 $fileType = $request->input("file_types.$tab.$field", null);
    //                 $fieldData['file_type'] = $fileType;
    //             }

    //             if ($type === 'select') {
    //                 $fieldData['options'] = [
    //                     ['label' => 'Yes', 'value' => 1],
    //                     ['label' => 'No', 'value' => 0],
    //                     ['label' => 'Other', 'value' => 2],
    //                 ];
    //             }

    //             $finalQuestionnaire[$tab][$field] = $fieldData;
    //         }
    //     }
    // }

  
    // $company = InsuranceCompany::create([
    //     'name'            => $request->name,
    //     'contact_person'  => $request->contact_person,
    //     'phone'           => $request->phone,
    //     'email'           => $request->email,
    //     'address'         => $request->address,
    //     'template'        => $request->template,
    //     'status'          => 1,
    //     'create_by'       => Auth::id(),
    //     'update_by'       => Auth::id(),
    //     'selected_tabs'   => json_encode(array_keys($selectedQuestions)),
    //     'questionnaires'  => json_encode($finalQuestionnaire),
    // ]);

    // return response()->json([
    //     'success' => 'Company added successfully',
    //     'redirect_url' => route('company.list'),
    // ]);

    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
   
       public function edit(string $id)
{
    $company = InsuranceCompany::findOrFail($id);

    $selectedTabs = is_string($company->selected_tabs) ? json_decode($company->selected_tabs, true) : $company->selected_tabs;
    $questionnairesRaw = is_string($company->questionnaires) ? json_decode($company->questionnaires, true) : $company->questionnaires;

    $questionnaires = [];
    if (is_array($questionnairesRaw)) {
        foreach ($questionnairesRaw as $tab => $questions) {
            $questionnaires[$tab] = array_keys((array)$questions);
        }
    }

    $templates = Template::all();

    return view('dashboard.company.edit')->with([
        'company' => $company,
        'selectedTabs' => $selectedTabs,
        'templates' => $templates,
        'questionnaires' => $questionnaires,
    ]);
}
    

    /**
     * Update the specified resource in storage.
     */



    public function update(Request $request)
    {
        $request->validate([
        "id"             => "required",
        "name"           => "required",
        "contact_person" => "required",
        "email"          => "required",
        "phone"          => "required",
        "address"        => "required",
        "template"       => "required",
        "status2"         => "required",
    ]);

    $company = InsuranceCompany::findOrFail($request->id);

   $finalQuestionnaire = [];

    if ($request->has('selected_questions') && is_array($request->selected_questions)) {
    foreach ($request->input('selected_questions') as $tab => $fields) {
    foreach ($fields as $field) {
    $type = $request->input("question_types.$tab.$field", 'select');

    $fieldData = [
    'name'     => $field,
    'label'    => ucwords(str_replace('_', ' ', $field)),
    'type'     => $type,
    'required' => false,
    ];

    // Handle file type
    if ($type === 'file') {
    $fileType = $request->input("file_types.$tab.$field", null);
    $fieldData['file_type'] = $fileType;
    }

    // Handle select type with Yes/No options
    if ($type === 'select') {
    $fieldData['options'] = [
    ['label' => 'Yes', 'value' => 1],
    ['label' => 'No', 'value' => 0],
    ['label' => 'Other', 'value' => 2],

    ];
    }

    $finalQuestionnaire[$tab][$field] = $fieldData;
    }
    }
    }


    $company->update([
        "name"            => $request->name,
        "contact_person"  => $request->contact_person,
        "email"           => $request->email,
        "phone"           => $request->phone,
        "address"         => $request->address,
        "template"        => $request->template,
        "status"          => $request->status2,
        'country_code'    => $request->country_code,
        "update_by"       => auth()->id(),
        // "selected_tabs"   => json_encode(array_keys($request->input('selected_questions', []))),
        // "questionnaires"  => json_encode($finalQuestionnaire),
        "selected_tabs"   => $request->input('selected_questions'),
        "questionnaires"  => $finalQuestionnaire,
        
    ]);

    // return response()->json(['success' => 'Company updated successfully']);

     return response()->json([
        'success' => 'Company updated successfully',
        'redirect_url' => route('company.list') // pass the redirect URL too
        ]);

    }

    /**
     * Remove the specified resource from storage.
     */

    public function destroy(InsuranceCompany $company)
    {
    $company->delete();

    return redirect()->route('company.list')->with('success', 'Company deleted successfully.');
    }

    

}

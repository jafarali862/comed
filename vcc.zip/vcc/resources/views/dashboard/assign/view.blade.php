<div class="container-fluid">
    <div class="row">
        <!-- Left Column -->
        <div class="col-md-6">
            <h5>Customer Name:</h5>
            <p>{{ $case->customer->name }}</p>

            <h5>Company:</h5>
            <p>{{ $case->company->
                name }}</p>

            <h5>Crime Number:</h5>
            <p>{{ $case->customer->crime_number }}</p>

            <h5>Police Station:</h5>
            <p>{{ $case->customer->police_station }}</p>

              <h5>Executive Name:</h5>
            <p><b>Driver</b>: {{  $case->driver->name }} </p>
            <p><b>Garage</b>: {{  $case->garage->name }} </p>
            <p><b>Spot</b>: {{  $case->spot->name }} </p>
            <p><b>Meeting</b>: {{  $case->meeting->name }} </p>
            <p><b>Accident</b>: {{  $case->accidentPerson->name }} </p>
        </div>

        <!-- Right Column -->
        <div class="col-md-6">
            <h5>Assign Date:</h5>
            <p>{{ \Carbon\Carbon::parse($case->created_at)->format('d-m-Y') }}</p>

            <h5>Status:</h5>
            <p>
                @if ($case->case_status == 1)
                    <span class="badge bg-danger">Pending</span>
                @elseif ($case->case_status == 0)
                    <span class="badge bg-success">Complete</span>
                @elseif ($case->case_status == 2)
                    <span class="badge bg-warning">Assigned</span>
                @else
                    <span class="badge bg-secondary">Unknown</span>
                @endif
            </p>

             <h5>Investigation Date:</h5>
            <p>{{ \Carbon\Carbon::parse($case->case_date)->format('d-m-Y') }}</p>


             <h5>Case Type:</h5>
            <p>{{  $case->type }} </p>


           


            {{-- Add more details if needed --}}
        </div>
    </div>
</div>

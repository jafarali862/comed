<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="css/custome.css"> -->
</head>
<body>
    <div class="report-container">
    <div class="logo">

     @if($template->template_logo)
                <img src="{{ public_path('storage/' . $template->template_logo) }}" 
                     alt="ERG Logo" 
                     style="max-width: 200px; height: auto; margin-top: 10px;">
            @endif
      <!-- <img src="images/image.png" alt="ERG Logo"> -->
    </div>
    <h2>OD INVESTIGATION REPORT - RELIANCE</h2>
    
    <style>

      body {
      font-family: Arial, sans-serif;
      padding: 40px;
      background-color: #f9f9f9;
    }

    .report-container {
      max-width: 1378px;
      margin: auto;
      /* background-color: white; */
      padding: 30px;
      /* border: 1px solid #ccc;
      box-shadow: 0 0 10px rgba(0,0,0,0.1); */
      font-size: 18px;
    }

    .logo {
      text-align: right;
    }

    .logo img {
      height: 50px;
    }

    h2 {
      text-align: center;
      text-decoration: underline;
      margin-bottom: 30px;
      font-size:24px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    td {
      border: 1px solid #000;
      padding: 15px;
      /* font-weight: bold; */
      vertical-align: top;
    }

    td:first-child {
      /* font-weight: bold; */
      width: 40%;
      background-color: #f0f0f0;
    }
    .report-content{
      max-width: 1378px;
      margin: auto;
      /* background-color: white; */
      padding: 30px;
      border: 1px solid #000;
      /* box-shadow: 0 0 10px rgba(0,0,0,0.1); */
    }
      .report-content h2{
        text-align: left;
        text-decoration: underline;
        margin-bottom: 30px;
      }


      .date {
      text-align: left;
      margin-top: 10px;
      font-size: 18px;
    }

    .signature {
      text-align: right;
      font-weight: bold;
      font-size: 16px;
      margin-top: 50px;
    }
    .ERG {
      text-align: right;
      font-weight: bold;
      font-size: 16px;
      margin-top: 20px;
     
    }
    .sign{
      text-align: right;
      margin-top: 20px;
    }

    .sign img {
      height: 50px;
    }

      /* @media (max-width: 600px) {
      .statement-box {
        padding: 15px;
      }

      .signature {
        font-size: 14px;
      }

      .date {
        font-size: 12px;
      }
    } */

    </style>

    <table>
      <tr>
        <td>Claim no</td>
        <td>3125311391</td>
      </tr>
      <tr>
        <td>Name of insured</td>
        <td>MR. ADARSH T</td>
      </tr>
      <tr>
        <td>Insured’s Address & contact No:</td>
        <td>HARINANDANAM, PALNIRAPPU, NALLLA P.O, VTC NEDUMPANA.</td>
      </tr>
      <tr>
        <td>Vehicle No</td>
        <td>KL02BX2070</td>
      </tr>
      <tr>
        <td>Vehicle make & model</td>
        <td>MARUTI SUZUKI INDIA LTD & BREZZA SMART BYBRID</td>
      </tr>
      <tr>
        <td>Date of Loss</td>
        <td>15.09.2025</td>
      </tr>
      <tr>
        <td>Claim intimation to Call centre, if any delay specify the no. of days</td>
        <td>19.09.2025, 4 days delay in intimation to the company.</td>
      </tr>
      <tr>
        <td>Investigator Name</td>
        <td>ERG ASSOCIATES.</td>
      </tr>
      <tr>
        <td>Report Submitting date</td>
        <td>07.10.2025</td>
      </tr>

      <tr>
        <td>Policy details </td>
        <td>991792523090160011</td>
      </tr>
      <tr>
        <td>Policy period </td>
        <td>09.09.2025  TO 08.09.2026 </td>
      </tr>
      <tr>
        <td>Policy type</td>
        <td>RELIANCE PRIVATE CAR POLICY OWN DAMAGE </td>
      </tr>
      <tr>
        <td>FIR &Panchanama Details</td>
        <td>A GD entry registered at Ezhukone Police station vide GD No: 6-24.09.2025 dated 24.09.2025. </td>
      </tr>
      <tr>
        <td>Injury & Hospital Details </td>
        <td>Insured  sustained minor injuries.</td>
      </tr>
      <tr>
        <td>No of passengers at the time of loss with ages </td>
        <td>1. Adarsh</td>
      </tr>
      <tr>
        <td>Gate entry  date</td>
        <td>NIL</td>
      </tr>
      <tr>
        <td>Job card Date </td>
        <td>15.09.2025</td>
      </tr>
      <tr>
        <td>Google timeline    of insured and driver </td>
        <td>GTL of insured cum IV driver attached with it. It shows no visit. </td>
      </tr>
      <tr>
        <td>TOWING RECEIPT</td>
        <td>Towing bill Gpay screen shot attached.</td>
      </tr>

    </table>
        <div class="report-content">
            <h2>CONCLUSION </h2>
            <p>
                 As per intimation, the accident had happened on 15.09.2025.  On inquiry with insured  Mr.  Adarsh T   he confirms the accident.  We have collected a written  statement from him.  As per his statement, the IV bearing Reg.No: KL02BX2070 MARUTI SUZUKI Brezza Smart  motorcar owned by  himself met with an accident on 15.09.2025 at 12:30am, while it was driven by insured    himself   from  Kundara to Kuzhimathikkadu when reached at Chekkalamukku,  the IV went out of control and hit on nearby compound wall.    By this accident,   insured  sustained minor injuries but the IV sustained some damages.The IV was taken to   Indus Motors  Pvt Ltd, Kottarakkara.  On enquiry with garage,  we have collected the vehicle photos and Job card of the vehicle .  The Job card date is 15.09.2025.    The intimation   to the company was made 19.09.2025.The current policy starting date is 09.09.2025 and The loss date is 15.09.2025.  Hence,   there is 6 days closed proximity in this case.  Further we verified the pre policy and   it shows the validity from  09.09.2024 TO 08.09.2025.  Hence there is no break in policy(pre policy attached). A GD entry registered  at  Ezhukone Police station vide GD No: 6-24.09.2025 dated 24.09.2025.  AS per GD entry, ‘an  application given by   Mr. Adarsh T, s/o Thulaseedharan, Harinandanam, Pala Nirappu, Kannanalloor, Kollam  vide application number 15293047-2025-15-00180.  The enquiry has  been done by CPO7452 Aneesh and found that the vehicle bearing Reg.No; KL 02 BX 2070 owned and  driven by the applicant (Licence No: 24/8749/2016)  met with an accident while it was driven from Aarumaurikkada Kuzhimathikkadu road south to North   the and when reached at Chekkalamukku  the vehicle went out of control and hit on  left side compound wall.  By this accident, the car bearing Reg.No: KL 02 BX 2070  front side , left and right side and top portion got damges.  The passengers had no injuries hence no other cases registered. (A copy of GD entry attached.) The vehicle damages are  tally with accident description.  We have collected  the  vehicle damage  photos and 
                 attached  with it.On spot enquiry, we confirm the accident.  We have collected the spot  photos and attached with it. We enquired with the said compound wall owner Mr. Johnson G Varghese  (ph: 9447484950)and  he confirms the accident .  He said that there was only one person  in the IV at the time of accident  and it was vehicle owner.   No intoxication suspected.  He also said that the IV went out  of control  by some other means and accident happened  which caused   compound wall collapsed.  He also said that  Mr. Adarsh   paid compensation for the reconstruction of the said compound wall.Insured shared the accident time photos and its properties, while verifying the same, it validates insured statement. (Accident time photos and   its properties attached with it). Insured went to Kundara Hospital, Kollam for a check up after the accident  and provided  a medical bill  and attached with it. Insured cum  IV driver  Mr.Shyju had  valid DL at the time of accident and a copy of the same attached.  No other suspected trigger observed in addition. Considering the  above  facts and findings we come to the conclusion that the case is genuine. 
            </p>
        </div>
        
        <div class="date">08.10.2025</div>
        <div class="signature">For ANOOP NG,</div>
        <div class="ERG">ERG ASSOCIATES</div>
        <div class="sign">
             <img src="" alt="sign img">
        </div>

  </div>
</body>
</html>
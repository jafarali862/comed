<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\CaseAssignment;
use App\Models\AssignWorkData;
use App\Models\InsuranceCustomer;
use App\Models\InsuranceCase;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Exception;

class CaseAssignmentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */

    public function create($id)
    {
    // Eager load related models in one go
    $insuranceCustomer = InsuranceCustomer::with([
        'company',
        'caseAssignment',
        'insuranceCase'
    ])->findOrFail($id);

    // Get active, non-admin users
    $users = User::where('role', '!=', 1)
                ->where('status', '!=', 0)
                ->get();

    return view("dashboard.assign.create")->with([
        "insuranceCustomer" => $insuranceCustomer,
        "users" => $users,
        "insuranceCompany" => $insuranceCustomer->company,
        "caseId" => $insuranceCustomer->insuranceCase,
        "caseAssignment" => $insuranceCustomer->caseAssignment
    ]);
    }


    /**
     * Store a newly created resource in storage.
     */
   
public function store(Request $request)
{
    $request->validate([
        "company_id" => "required|integer",
        "customer_id" => "required|integer",
        "Default_Executive" => "required", // Optional: validate further if needed
        "executive_driver" => "required|integer",
        "executive_garage" => "required|integer",
        "executive_spot" => "required|integer",
        "executive_meeting" => "required|integer",
        "date" => "required|date",
        "investigation_type" => "required|string",
    ]);

    try {
        DB::beginTransaction();

        // ✅ Check for existing CaseAssignment using Eloquent
        $existing = CaseAssignment::where([
            ['case_id', '=', $request->case_id],
            ['company_id', '=', $request->company_id],
            ['customer_id', '=', $request->customer_id],
            ['executive_driver', '=', $request->executive_driver],
            ['executive_garage', '=', $request->executive_garage],
            ['executive_spot', '=', $request->executive_spot],
            ['executive_meeting', '=', $request->executive_meeting],
            ['executive_accident_person', '=', $request->executive_accident_person],
            ['date', '=', $request->date],
            ['type', '=', $request->investigation_type],
            ['other', '=', $request->other],
            ['status', '=', 1],
            ['case_status', '=', 1],
            ['create_by', '=', auth()->id()],
        ])->first();

        if ($existing) {
            return response()->json([
                'success' => false,
                'message' => 'This exact case assignment already exists.',
            ], 409); // 409 Conflict
        }

        // ✅ Create the CaseAssignment
        $caseAssignment = CaseAssignment::create([
            "case_id" => $request->case_id,
            "company_id" => $request->company_id,
            "customer_id" => $request->customer_id,
            "executive_driver" => $request->executive_driver,
            "executive_garage" => $request->executive_garage,
            "executive_spot" => $request->executive_spot,
            "executive_meeting" => $request->executive_meeting,
            "executive_accident_person" => $request->executive_accident_person,
            "date" => $request->date,
            "type" => $request->investigation_type,
            "other" => $request->other,
            "status" => 1,
            "case_status" => 1,
            "create_by" => auth()->id(),
            "update_by" => auth()->id(),
        ]);

        // ✅ Create related AssignWorkData
        AssignWorkData::create([
            "case_id" => $caseAssignment->id,
        ]);

        // ✅ Update related InsuranceCase
        InsuranceCase::where('customer_id', $request->customer_id)->update([
            'case_status' => 2
        ]);

        DB::commit();

        return response()->json([
            'success' => 'Case Assigned Successfully',
            'redirect_url' => route('case.index'),
        ]);

    } catch (\Exception $e) {
        DB::rollBack();

        \Log::error('Case assignment creation failed', [
            'error' => $e->getMessage(),
            'request_data' => $request->all()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'An error occurred while assigning the case.',
        ], 500);
    }
}


    // public function view(string $id)
    // {
    //     $cases = DB::table('case_assignments')
    //             ->leftJoin('insurance_companies', 'case_assignments.company_id', '=', 'insurance_companies.id')
    //             ->leftJoin('insurance_customers', 'case_assignments.customer_id', '=', 'insurance_customers.id')
    //             ->leftJoin('users as driver', 'case_assignments.executive_driver', '=', 'driver.id')
    //             ->leftJoin('users as garage', 'case_assignments.executive_garage', '=', 'garage.id')
    //             ->leftJoin('users as spot', 'case_assignments.executive_spot', '=', 'spot.id')
    //             ->leftJoin('users as accident', 'case_assignments.executive_accident_person', '=', 'accident.id')
    //             ->leftJoin('users as meeting', 'case_assignments.executive_meeting', '=', second: 'meeting.id')
    //             ->select('case_assignments.*',
    //             'insurance_companies.name as company_name',
    //             'insurance_customers.name as customer_name',
    //             'insurance_customers.phone',
    //             'driver.name as driver_name',
    //             'garage.name as garage_name',
    //             'spot.name as spot_name',
    //             'meeting.name as meeting_name','accident.name as accident_name','case_assignments.date as case_date','insurance_customers.crime_number','insurance_customers.police_station'
    //             )
    //             ->where('case_assignments.id',$id)
    //              ->orderBy('case_assignments.id', 'desc')

    //             ->first(); 
            
    //     return view('dashboard.assign.view')->with(['cases' => $cases]);
    // }


    public function view(string $id)
    {
    $case = CaseAssignment::with([
        'company',
        'customer',
        'driver',
        'garage',
        'spot',
        'accidentPerson',
        'meeting'
    ])->findOrFail($id);

    return view('dashboard.assign.view', compact('case'));
    }


    public function showUploadForm($id)
    {
        $user = User::findOrFail($id);

        return view('dashboard.upload-form', compact('id','user'));
    }

    public function upload(Request $request, $id)
    {
        $request->validate([
            'image' => 'required|image|max:2048'
        ]);

        $user = User::findOrFail($id);

        // Delete old image
        if ($user->profile_image && Storage::disk('public')->exists($user->profile_image)) {
            Storage::disk('public')->delete($user->profile_image);
        }

        $path = $request->file('image')->store('profile_images', 'public');

        $user->profile_image = $path;
        $user->save();

        return redirect()->route('profile.upload.form', ['id' => $id])
                    ->with('success', 'Profile image updated successfully');
        
    }

    public function show($id)
    {
        $user = User::findOrFail($id);

        if (!$user->profile_image) {
            return response()->json(['message' => 'No image found'], 404);
        }

        return response()->json([
            'image_url' => asset('storage/' . $user->profile_image)
        ]);
    }


  
    public function assignedCase(Request $request)
    {
    $from = $request->input('from_date');
    $to = $request->input('to_date');

    $query = CaseAssignment::with([
        'company:id,name',
        'customer:id,name,phone,crime_number,police_station',
        'driver:id,name',
        'garage:id,name',
        'spot:id,name',
        'meeting:id,name'
    ]);

    if ($from && $to) {
        try {
            $fromFormatted = Carbon::parse($from)->startOfDay();
            $toFormatted = Carbon::parse($to)->endOfDay();

            $query->whereBetween('created_at', [$fromFormatted, $toFormatted]);
        } catch (\Exception $e) {
            \Log::warning('Invalid date range provided.', ['from' => $from, 'to' => $to]);
        }
    }

    $cases = $query->orderBy('created_at', 'desc')->paginate(10);

    return view('dashboard.assign.assigned-case', [
        'cases' => $cases,
        'from' => $from,
        'to' => $to,
    ]);
    }



 public function fakeCase(Request $request)
{
    $cases = CaseAssignment::with([
        'company:id,name',
        'customer:id,name,phone,crime_number,police_station',
        'driver:id,name',
        'garage:id,name',
        'spot:id,name',
        'meeting:id,name'
    ])
    ->where('is_fake', 1)
    ->paginate(10);

    return view('dashboard.assign.fake-case')->with(['cases' => $cases]);
}



    // public function reAssign($id)
    // {
    //     $cases = DB::table('case_assignments')->where('id', '=', $id)->first();
    //     $customer = DB::table('insurance_customers')->where('id', '=', $cases->customer_id)->first();
    //     $insuranceCompany = DB::table('insurance_companies')->where('id', '=', $cases->company_id)->first();
    //     $executives = User::where('role', '!=', 1)->where('role', '!=', 2)->where('status', '!=', 0)->get();
    //     return view('dashboard.assign.re-assign')
    //         ->with([
    //             'company' => $insuranceCompany,
    //             'customer' => $customer,
    //             'executives' => $executives,
    //             'cases' => $cases,
    //         ]);
    // }


    public function reAssign($id)
    {
    $case = CaseAssignment::with(['customer', 'company'])->findOrFail($id);

    $executives = User::whereNotIn('role', [1, 2])
                        ->where('status', '!=', 0)
                        ->get();

    return view('dashboard.assign.re-assign')->with([
        'cases' => $case,
        'customer' => $case->customer,
        'company' => $case->company,
        'executives' => $executives,
    ]);
    }

    public function reAssignUpdate(Request $request)
    {
        $request->validate([
        'id' => 'required|exists:case_assignments,id',
        ]);

       try {
        $case = CaseAssignment::findOrFail($request->id);

        $case->executive_driver = $request->driver;
        $case->executive_garage = $request->garage;
        $case->executive_spot = $request->spot;
        $case->executive_meeting = $request->meeting;
        $case->executive_accident_person = $request->accident_person;
        $case->date = $request->date;

        $case->save();

        return response()->json(['success' => 'Case updated successfully']);
    } catch (Exception $e) {
        Log::error('Reassignment update failed', ['error' => $e->getMessage()]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while updating the case.',
            'error' => $e->getMessage()
        ], 500);
    }
    }

    /**
     * Display the specified resource.
     */
    // public function show(string $id)
    // {
       
    // }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investigation Report</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;

        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        ul {
            line-height: 1.8;
            text-align: justify;
        }

        li {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div id="container" style="display: flex; justify-content: center;">
        <div>
            <div style="display: flex; justify-content: end;">
                <div style="border: 1px solid; border-radius: 10px; width: 150px; height: 70px;">
                    <p style="font-size: 20px; margin-top: 10px;"><BR>
                        {{$finalReport->insurance_com_name}}</P>
                </div>
            </div>

            <hr>
            <h2 style="text-align: center;"> INVESTIGATION REPORT:</h2>
            <h3>1. INTRODUCTION</h3>


            <table>

                <tr>
                    <td>1</td>
                    <td>Name of Customer</td>
                    <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Contact of Customer</td>
                    <td>{{ $finalReport->customer_phone ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Policy Start Date</td>
                    <td>{{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }}</td>
                </tr>
                <tr>
                    <td>4</td>
                     <td>Policy Start Date</td>
                    <td>{{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Policy No</td>
                    <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>6</td>
                    <td>Crime Number</td>
                    <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
                </tr>

                 <tr>
                    <td>7</td>
                    <td>Police Station</td>
                    <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>8</td>
                    <td>Investigation Date</td>
                    <td>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
                </tr>

                  <tr>
                    <td>9</td>
                    <td>Father Name</td>
                    <td>{{ $finalReport->customer_father_name ?? 'N/A' }}</td>
                </tr>

                      <tr>
                    <td>10</td>
                    <td>Case Type</td>
                    <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
                </tr>


            </table>

        
           
        

            <!-- <h3>CASE DETAILS</h3> -->

           

      
           


            <table>

                <tbody>
                    <tr>
                        <td>A</td>
                        <td>Result on verification of Medical Records</td>
                        <td>We have collected the wound certificate of injured Sunitha and Sreekala. While verifying the
                            same it is mentioned that “A/H/o RTA (Car vs Bike) at around 02:25am at Gramam on
                            09/11/2023”. A Copy of each attached with it.</td>
                    </tr>
                    <tr>
                        <td>B</td>
                        <td>Result of discussion with the Injured/deceased family & neighbours</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>C</td>
                        <td>Discuss on what capacity the Injured/deceased was travelling in the Vehicle</td>
                        <td>The injured was the pillion rider of motor cycle.</td>
                    </tr>
                    <tr>
                        <td>D</td>
                        <td>Result of discussion with the insured</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>E</td>
                        <td>Result of discussion with the employer for confirming the occupation & income of the
                            injured/deceased</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>F</td>
                        <td>Result of discussion with the rider of the IV</td>
                        <td>NA</td>
                    </tr>
                    <tr>
                        <td>G</td>
                        <td>Discussion on the Financial Investigation on the Insured with regard to his employment,
                            employer, salary, movable & immovable property, total monthly income, etc.</td>
                        <td>NA</td>
                    </tr>
                </tbody>
            </table>

            <h3>FACTS AND FINDINGS:</h3>

            <ul>
                <li>On 09.11.2023 at about 02:30 hrs, the complainant’s husband Santhosh Kumar was the driver of motor
                    car bearing Reg.No. KL-19-D-1801 in the which complainant and his colleague Sreekala were the
                    passengers and drove through Parassala-Neyyattinkara road from Parassala side to Neyyattinkara side
                    and reached near Gramam Toll gate, Kadavattaram, Neyyattinkara village and vehicle unexpectedly skid
                    and hit the back side of KL-44-C-2882 tourist bus which was on the north side of the said road. Due
                    to the impact of the hit, complainant and others had sustained severe injuries and fractures. </li>

                <li>The accident was happened unexpectedly hence it is registered under motor occurrence.</li>

                <li>Immediately after the accident, the injured Sunitha, Sreekala and Santhosh Kumar was taken to NIMS
                    Hospital, Aaralummoodu and treated there. We have collected the wound certificate of injured Sunitha
                    and Sreekala. While verifying the same it is mentioned that “A/H/o RTA (Car vs Bike) at around
                    02:25am at Gramam on 09/11/2023”. A Copy of each attached with it.</li>

                <li>We have collected the discharge summary of injured Mrs. Sreekala from NIMS Hospital, Aaralummoodu
                    and a copy of the same enclosed with it.</li>

                <li>IV Details: The IV is bus bearing Reg.No. KL-44-C-2882 owned by Mr. Subin</li>
                <li>Policy Details: The IV is insured with UNITED INDIA INSURANCE COMPANY LIMITED</li>


                <li>Policy No: 1004003123P100594371 and the period of validity cover from 14.04.2023 to13.04.2024</li>
                <li>IV driver: The IV driver Mr. Subin who has valid DL at the time of accident.</li>
            </ul>

            <h3>CONCLUSION</h3>
            <p style="font-size: 20px;"> On the course of investigation, meeting with concerned parties and verifying
                the medical documents, we come to the conclusion that the accident is genuine. The accident was happened
                unexpectedly hence the case is registered under motor occurrence (306 (1) (c)).</p>
            <br>
            <br>

            <div style="display: flex; justify-content: space-between;">
                <div>10.09.2024<br>Trivandrum</div>
                <div>ANOOP N G </div>
            </div>

            <h3>Photo of injured Anagha</h3>
            <img src="picture1.png" alt="">
            <br>
            <h3>Adhaar Card Of Injured sunitha</h3>
            <img src="picture2.png" alt="">
            <img src="picture3.png" alt="">
            <br>
            <h3>Photo of injured Sreekala</h3>
            <img src="picture4.png" alt="">
            <br>
            <h3>Ration Card Of Injured Sreekala</h3>
            <img src="picture5.png" alt="">
            <img src="picture6.png" alt="">
            <br>
            <h3>Adhar Card Of Injured Sreekala</h3>
            <img src="picture7.png" alt="">
            <img src="picture8.png" alt="">
            <br>
            <h3>Spot</h3>
            <img src="picture9.png" alt="">
            <img src="picture10.png" alt="">




        </div>
    </div>

</body>

</html>
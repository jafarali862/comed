@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Pharmacy Prescription</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('pharmacy-prescriptions.index') }}">Pharmacy Prescriptions</a></li>
                        <li class="breadcrumb-item active">Edit Prescription</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 offset-md-1">
                    <div class="card">
                        @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        <div class="card-header">
                            <h3 class="card-title">Update Prescription</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('pharmacy-prescriptions.update', $pharmacyPrescription->id) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')

                                <div class="form-group">
                                    <label for="user_id">User</label>
                                    <input type="text" class="form-control" id="prescription" name="prescription" value="{{$pharmacyPrescription->user->name }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="pharmacy_id">Pharmacy</label>
                                    <input type="text" class="form-control" id="prescription" name="prescription" value="{{ $pharmacyPrescription->pharmacy->pharmacy_name }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="prescription">Prescription (Images)</label>

                                    @if($pharmacyPrescription->prescription)
                                    <div class="mt-2">
                                        @foreach(json_decode($pharmacyPrescription->prescription, true) as $image)
                                        <div class="d-inline-block text-center mr-2">
                                            <img src="{{ asset('storage/'.$image) }}" alt="Prescription Image" width="100" class="mb-1">
                                            <br>
                                            <button type="button" class="btn btn-info btn-sm" onclick="showImage('{{ asset('storage/'.$image) }}')">View</button>
                                        </div>
                                        @endforeach
                                    </div>
                                    @endif
                                </div>


                                <div class="form-group">
                                    <label for="delivery_address">Delivery Address</label>
                                    <textarea class="form-control" id="delivery_address" name="delivery_address" rows="2" required>{{ old('delivery_address', $pharmacyPrescription->delivery_address) }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label for="lat_long">Latitude & Longitude</label>
                                    <input type="text" class="form-control" id="lat_long" name="lat_long" value="{{ old('lat_long', $pharmacyPrescription->lat_long) }}" readonly>
                                </div>


                                <button type="submit" class="btn btn-primary">Update Address</button>
                                <a href="{{ route('pharmacy-prescriptions.index') }}" class="btn btn-secondary">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <img id="large-prescription" src="" class="img-fluid d-none" alt="Prescription Image">
                </div>
                @if(count($medicines)<1)
                    <div class="col-md-6 offset-md-1">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title">Add Medicine</h3>
                            <button type="button" class="btn btn-success btn-sm" onclick="addMedicineField()">+ Add Medicine</button>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('pharmacy-medicines.store') }}" method="POST">
                                @csrf
                                <input type="hidden" name="pharmacy_prescription_id" value="{{ $pharmacyPrescription->id }}">

                                <div id="medicine-container">

                                </div>

                                <button type="submit" id='submit' style="display:none;" class="btn btn-primary mt-3">Save Medicines</button>
                            </form>
                        </div>
                    </div>
            </div>
            @else
            <div class="col-md-6 offset-md-1">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Medicine Name</th>
                            <th>Quantity</th>
                            <th>Amount ($)</th>
                            <th>Total ($)</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach($medicines as $medicine)
                        <tr>
                            <td>{{$medicine->medicine_name}}</td>
                            <td>{{$medicine->quantity}}</td>
                            <td>{{$medicine->amount}}</td>
                            <td>{{$medicine->total}}</td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-right">Grand Total ($)</th>
                            <th>{{ $medicines->sum('total') }}</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            @endif
        </div>
</div>
</section>
</div>
<script>
    function showImage(imageUrl) {
        let imgElement = document.getElementById('large-prescription');
        imgElement.src = imageUrl;
        imgElement.classList.remove('d-none');
    }

    function addMedicineField() {
        let container = document.getElementById('medicine-container');

        let submit = document.getElementById('submit');
        submit.style.display = 'block';

        let div = document.createElement('div');
        div.classList.add('medicine-row', 'mb-3', 'd-flex', 'align-items-center');

        div.innerHTML = `
            <input type="text" class="form-control mr-2" name="medicines[]" placeholder="Medicine Name" required>
            <input type="number" class="form-control mr-2 quantity" name="quantities[]" placeholder="Quantity" required oninput="calculateTotal(this)">
            <input type="number" class="form-control mr-2 amount" name="amounts[]" placeholder="Price per Unit" required oninput="calculateTotal(this)">
            <input type="number" class="form-control mr-2 total" name="total[]" placeholder="Total" >
            <button type="button" class="btn btn-danger btn-sm" onclick="removeMedicineField(this)">X</button>
        `;

        container.appendChild(div);
    }

    function calculateTotal(element) {
        let row = element.parentElement;
        let quantity = row.querySelector('.quantity').value;
        let amount = row.querySelector('.amount').value;
        let totalField = row.querySelector('.total');
        let total = (quantity && amount) ? (quantity * amount) : 0;
        totalField.value = total;
    }


    function removeMedicineField(button) {
        button.parentElement.remove();
    }
</script>
@endsection
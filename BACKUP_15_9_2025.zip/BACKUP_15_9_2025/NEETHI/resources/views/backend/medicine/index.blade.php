@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Medicines</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
            <li class="breadcrumb-item active">Medicines</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex justify-content-end">
              <a class="btn btn-success" href="{{ route('medicines.create') }}">
                <i class="fas fa-plus"></i> Add Medicine
              </a>

              <form action="{{ route('medicines.import') }}" method="POST" enctype="multipart/form-data" class="ml-2">
                @csrf
                <div class="input-group">
                  <input type="file" name="file" class="form-control" accept=".xls,.xlsx" required>
                  <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">
                      <i class="fas fa-upload"></i> Upload XL
                    </button>
                  </div>
                </div>
              </form>
            </div>
            <div class="card-body">
              <table id="medicinesTable" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Quantity</th>
                    <th>Amount</th>
                    <th>Description</th>
                    <th>Created At</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($medicines as $medicine)
                  <tr>
                    <td>{{ $medicine->medicine_name }}</td>
                    <td>{{ $medicine->quantity }}</td>
                    <td>${{ number_format($medicine->amount, 2) }}</td>
                    <td>{{ $medicine->description}}</td>
                    <td>{{ $medicine->created_at->format('Y-m-d H:i') }}</td>
                    <td>
                      <a href="{{ route('medicines.edit', $medicine->id) }}" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                      </a>
                      <form action="{{ route('medicines.destroy', $medicine->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this medicine?');">
                          <i class="fas fa-trash"></i> Delete
                        </button>
                      </form>
                    </td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- jQuery -->
<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<!-- DataTables Script -->
<script>
  $(function() {
    $("#medicinesTable").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#medicinesTable_wrapper .col-md-6:eq(0)');
  });
</script>
@endsection

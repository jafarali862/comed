@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit Pharmacy</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item"><a href="{{ route('pharmacies.index') }}">Pharmacies</a></li>
            <li class="breadcrumb-item active">Edit Pharmacy</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Pharmacy Details</h3>
            </div>
            <div class="card-body">
              <!-- Edit Pharmacy Form -->
              <form action="{{ route('pharmacies.update', $pharmacy->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="form-group">
                  <label for="pharmacy_name">Pharmacy Name</label>
                  <input type="text" class="form-control" id="pharmacy_name" name="pharmacy_name" value="{{ $pharmacy->pharmacy_name }}" required>
                </div>

                <div class="form-group">
                  <label for="pharmacy_address">Pharmacy Address</label>
                  <input type="text" class="form-control" id="pharmacy_address" name="pharmacy_address" value="{{ $pharmacy->pharmacy_address }}" required>
                </div>

                <div class="form-group">
                  <label for="city">City</label>
                  <input type="text" class="form-control" id="city" name="city" value="{{ $pharmacy->city }}" required>
                </div>

                <div class="form-group">
                  <label for="phone_number">Phone Number</label>
                  <input type="text" class="form-control" id="phone_number" name="phone_number" value="{{ $pharmacy->phone_number }}" required>
                </div>

                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" id="email" name="email" value="{{ $pharmacy->email }}" required>
                </div>

                <button type="submit" class="btn btn-primary">Update Pharmacy</button>
                <a href="{{ route('pharmacies.index') }}" class="btn btn-secondary">Cancel</a>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
@endsection

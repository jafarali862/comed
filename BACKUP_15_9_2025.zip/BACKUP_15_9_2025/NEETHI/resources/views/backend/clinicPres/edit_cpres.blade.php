@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Pharmacy Prescription</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('pharmacy-prescriptions.index') }}">Pharmacy Prescriptions</a></li>
                        <li class="breadcrumb-item active">Edit Prescription</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6 offset-md-1">
                    <div class="card">
                        @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif
                        <div class="card-header">
                            <h3 class="card-title">Update Prescription</h3>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('clinic-prescriptions.update', $clinicPrescription->id) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')

                                <div class="form-group">
                                    <label for="user_id">User</label>
                                    <input type="text" class="form-control" id="prescription" name="prescription" value="{{$clinicPrescription->user->name }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="pharmacy_id">Pharmacy</label>
                                    <input type="text" class="form-control" id="prescription" name="prescription" value="{{ $clinicPrescription->clinic->clinic_name }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="prescription">Prescription (Image)</label>

                                    @if($clinicPrescription->prescription)
                                    <div class="mt-2">
                                        <img src="{{ asset('storage/'.$clinicPrescription->prescription) }}" id="small-prescription" alt="Current Prescription Image" width="100" class="mr-2">
                                        <button type="button" class="btn btn-info btn-sm" onclick="showImage('{{ asset('storage/'.$clinicPrescription->prescription) }}')">View Prescription</button>
                                    </div>
                                    @endif
                                </div>

                                <div class="form-group">
                                    <label for="delivery_address">Delivery Address</label>
                                    <textarea class="form-control" id="delivery_address" name="delivery_address" rows="2" required>{{ old('delivery_address', $pharmacyPrescription->delivery_address) }}</textarea>
                                </div>

                                <div class="form-group">
                                    <label for="lat_long">Latitude & Longitude</label>
                                    <input type="text" class="form-control" id="lat_long" name="lat_long" value="{{ old('lat_long', $clinicPrescription->lat_long) }}" readonly>
                                </div>


                                <button type="submit" class="btn btn-primary">Update Address</button>
                                <a href="{{ route('pharmacy-prescriptions.index') }}" class="btn btn-secondary">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <img id="large-prescription" src="" class="img-fluid d-none" alt="Prescription Image">
                </div>
               
            </div>
        </div>
    </section>
</div>
<script>
    function showImage(imageUrl) {
        let imgElement = document.getElementById('large-prescription');
        imgElement.src = imageUrl;
        imgElement.classList.remove('d-none');
    }

</script>
@endsection
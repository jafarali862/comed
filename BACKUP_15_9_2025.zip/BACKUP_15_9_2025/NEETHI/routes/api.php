<?php

use App\Http\Controllers\API\CommonController;
use App\Http\Controllers\API\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('/register', [UserController::class, 'register']);

Route::post('/login', [UserController::class, 'login']);

Route::middleware('auth:api')->group(function () {
    Route::get('/pharmacies', [CommonController::class, 'pharmacyLister']);
    Route::post('/pharmacy_prescription', [CommonController::class, 'pPrescription']);
    Route::post('/pharmacy_medicine', [CommonController::class, 'pMedicines']);
});

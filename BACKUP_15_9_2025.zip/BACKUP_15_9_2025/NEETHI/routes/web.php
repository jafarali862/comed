<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ClinicController;
use App\Http\Controllers\MedicineController;
use App\Http\Controllers\PharmacyController;
use App\Http\Controllers\PharmacyPrescription;
use App\Http\Controllers\PharmacyMedicineController;
use App\Http\Controllers\ClinicPrescriptionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');



Route::get('/users', [UserController::class, 'index'])->name('users.index');
Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
Route::post('/users', [UserController::class, 'store'])->name('users.store');
Route::get('/users/{id}/edit', [UserController::class, 'edit'])->name('users.edit');
Route::put('/users/{id}', [UserController::class, 'update'])->name('users.update');
Route::delete('/users/{id}', [UserController::class, 'destroy'])->name('users.destroy');

Route::get('/clinic', [ClinicController::class, 'index'])->name('clinic');
Route::get('/add_clinic', [ClinicController::class, 'createClinic'])->name('add-new-clinics');
Route::post('/clinics/store', [ClinicController::class, 'store'])->name('clinics.store');
Route::get('/clinics/{id}/edit', [ClinicController::class, 'edit'])->name('clinics.edit');
Route::put('/clinics/{id}', [ClinicController::class, 'update'])->name('clinics.update');

Route::get('/clinic-prescriptions', [ClinicPrescriptionController::class, 'index'])->name('clinic-prescriptions.index');
Route::get('/clinic-prescriptions/{clinicPrescription}/edit', [ClinicPrescriptionController::class, 'edit'])->name('clinic-prescriptions.edit');
Route::put('/clinic-prescriptions/{clinicPrescription}', [ClinicPrescriptionController::class, 'update'])->name('clinic-prescriptions.update');

Route::get('pharmacies', [PharmacyController::class, 'index'])->name('pharmacies.index');
Route::get('pharmacies/create', [PharmacyController::class, 'create'])->name('pharmacies.create');
Route::post('pharmacies', [PharmacyController::class, 'store'])->name('pharmacies.store');
Route::get('pharmacies/{id}/edit', [PharmacyController::class, 'edit'])->name('pharmacies.edit');
Route::put('pharmacies/{id}', [PharmacyController::class, 'update'])->name('pharmacies.update');
Route::delete('pharmacies/{id}', [PharmacyController::class, 'destroy'])->name('pharmacies.destroy');

Route::get('/pharmacy-prescriptions', [PharmacyPrescription::class, 'index'])->name('pharmacy-prescriptions.index');
Route::get('/pharmacy-prescriptions/{pharmacyPrescription}/edit', [PharmacyPrescription::class, 'edit'])->name('pharmacy-prescriptions.edit');
Route::put('/pharmacy-prescriptions/{pharmacyPrescription}', [PharmacyPrescription::class, 'update'])->name('pharmacy-prescriptions.update');

Route::get('/medicines', [MedicineController::class,'index'])->name('medicines.index');
Route::get('/medicines-create', [MedicineController::class,'create'])->name('medicines.create');
Route::post('/medicines-store', [MedicineController::class,'store'])->name('medicines.store');
Route::get('/medicines-edit/{id}', [MedicineController::class,'edit'])->name('medicines.edit');
Route::put('/medicines-update/{id}', [MedicineController::class,'update'])->name('medicines.update');
Route::delete('/medicines-distroy/{id}', [MedicineController::class,'destroy'])->name('medicines.destroy');
Route::post('medicines/import', [MedicineController::class, 'import'])->name('medicines.import');

Route::post('/pharmacy-medicines/store', [PharmacyMedicineController::class, 'addMedicine'])->name('pharmacy-medicines.store');

Route::delete('/clinics/{id}', [ClinicController::class, 'destroy'])->name('clinics.destroy');

Route::get('/pharmacy', [PharmacyController::class, 'index'])->name('pharmacy');
<?php

namespace App\Imports;

use App\Models\Medicine;
use Maatwebsite\Excel\Concerns\ToModel;

class MedicinesImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Medicine([
            'medicine_name' => $row[0],
            'amount' => $row[1],
            'quantity' => $row[2],
            'expiry_date'=>$row[3],
            'manufacturer'=>$row[4],
            'description'=>$row[5]
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Clinic;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\ClinicPrescription;

class ClinicPrescriptionController extends Controller
{
    public function index()
    {
        $clinicPrescriptions = ClinicPrescription::all();
        return view('backend.clinicpres.index', compact('clinicPrescriptions'));
    }

    public function edit($id)
    {
        $clinicPrescriptions = ClinicPrescription::findOrFail($id);
        $users = User::all();
        $clinic = Clinic::all();
        return view('backend.clinicPres.edit_cpres', compact('pharmacyPrescription', 'users', 'pharmacies'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([

            'delivery_address' => 'required|string',
        ]);

        $ClinicPrescriptions = ClinicPrescription::findOrFail($id);
        $ClinicPrescriptions->delivery_address = $request->delivery_address;
        $ClinicPrescriptions->save();

        return redirect()->route('clinic-prescriptions.index')->with('success', 'Prescription updated successfully.');
    }
}

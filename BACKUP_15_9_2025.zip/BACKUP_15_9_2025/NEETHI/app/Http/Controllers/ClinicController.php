<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Clinic;
use Illuminate\Http\Request;

class ClinicController extends Controller
{
    public function index()
    {
        $clinics = Clinic::all();
        return view('backend.clinic.clinic', compact('clinics'));
    }

    public function createClinic()
    {

        return view('backend.clinic.clinic-add');
    }

    public function store(Request $request)
    {
        $request->validate([
            'clinic_name' => 'required|string|max:255',
            'clinic_address' => 'required|string',
            'city' => 'required|string|max:100',
            'phone_number' => 'required|string|max:20',
            'email' => 'required|email',
        ]);

        Clinic::create($request->all());

        return redirect()->route('clinic')->with('success', 'Clinic added successfully!');
    }

    public function edit($id)
    {
        $clinic = Clinic::findOrFail($id);
        return view('backend.clinic.clinic-edit', compact('clinic'));
    }


    public function update(Request $request, $id)
    {
        $request->validate([
            'clinic_name' => 'required|string|max:255',
            'clinic_address' => 'required|string',
            'city' => 'required|string|max:100',
            'phone_number' => 'required|string|max:20',
            'email' => 'required|email|max:255'
        ]);

        $clinic = Clinic::findOrFail($id);
        $clinic->update([
            'clinic_name' => $request->clinic_name,
            'clinic_address' => $request->clinic_address,
            'city' => $request->city,
            'phone_number' => $request->phone_number,
            'email' => $request->email
        ]);

        return redirect()->route('clinic')->with('success', 'Clinic updated successfully.');
    }

    public function destroy($id)
    {
        $clinic = Clinic::findOrFail($id);
        $clinic->delete();

        return redirect()->route('clinic')->with('success', 'Clinic deleted successfully.');
    }
}

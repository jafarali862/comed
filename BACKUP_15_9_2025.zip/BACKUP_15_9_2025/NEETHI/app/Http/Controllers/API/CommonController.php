<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\PharmacyMedicine;
use App\Models\PharmacyPrescription;

class CommonController extends Controller
{
    public function pharmacyLister()
    {
        try {
            $pharmacies = Pharmacy::all();
            return response()->json(['pharmacys' => $pharmacies]);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function pPrescription(Request $request)
    {
        
        // try {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'pharmacy_id' => 'required',
                'prescription.*' => 'required|image',
                'delivery_address' => 'required|string',
                'lat_long' => 'required|string',
            ]);

            $prescriptionPaths = [];
            foreach ($request->file('prescription') as $file) {
                $prescriptionPaths[] = $file->store('prescriptions', 'public');
            }

            PharmacyPrescription::create([
                'user_id' => $request->user_id,
                'pharmacy_id' => $request->pharmacy_id,
                'prescription' => json_encode($prescriptionPaths),
                'delivery_address' => $request->delivery_address,
                'lat_long' => $request->lat_long,
            ]);
            return response()->json(['success' => 'Prescription added successfully.'], 200);
        // } catch (Exception $e) {
        //     Log::error($e);
        //     return response()->json([
        //         'message' => 'Something went wrong, please try again later.',
        //         'error' => $e->getMessage()
        //     ], 500);
        // }
    }

    public function pMedicines(Request $request)
    {
        try {
            $request->validate([
                'user_id' => 'required',
                'pharmacy_id' => 'required'
            ]);
            $pharMeds = PharmacyMedicine::leftJoin('pharmacy_prescriptions as pp', 'pp.id', 'pharmacy_medicines.pharmacy_prescription_id')
                ->where('pp.user_id', $request->user_id)
                ->where('pp.pharmacy_id', $request->pharmacy_id)
                ->select('pharmacy_medicines.medicine_name', 'pharmacy_medicines.quantity', 'pharmacy_medicines.total')
                ->get();
            return response()->json(['medicines' => $pharMeds], 200);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

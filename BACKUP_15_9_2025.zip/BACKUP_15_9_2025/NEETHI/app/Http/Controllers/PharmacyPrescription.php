<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Pharmacy;
use App\Models\PharmacyMedicine;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\PharmacyPrescription as pprescription;

class PharmacyPrescription extends Controller
{
    public function index()
    {
        $pharmacyPrescriptions = pprescription::all();
        return view('backend.pharmacypres.index', compact('pharmacyPrescriptions'));
    }

    public function edit($id)
    {
        $pharmacyPrescription = pprescription::findOrFail($id);
        $users = User::all();
        $pharmacies = Pharmacy::all();
        $medicines = PharmacyMedicine::withTrashed()->where('pharmacy_prescription_id', $id)->get();
        return view('backend.pharmacyPres.edit_ppres', compact('pharmacyPrescription', 'users', 'pharmacies','medicines'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([

            'delivery_address' => 'required|string',
        ]);

        $pharmacyPrescription = pprescription::findOrFail($id);
        $pharmacyPrescription->delivery_address = $request->delivery_address;
        $pharmacyPrescription->save();

        return redirect()->route('pharmacy-prescriptions.index')->with('success', 'Prescription updated successfully.');
    }
}

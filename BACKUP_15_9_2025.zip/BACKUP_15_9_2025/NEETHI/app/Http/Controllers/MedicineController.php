<?php

namespace App\Http\Controllers;

use App\Models\Medicine;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\MedicinesImport;


class MedicineController extends Controller
{


    public function index()
    {
        $medicines = Medicine::all();
        return view('backend.medicine.index', compact('medicines'));
    }

    public function create()
    {
        return view('backend.medicine.create');
    }

    public function store(Request $request)
    {
       
        
        $request->validate([
            'medicine_name' => 'required',
            'amount' => 'required|numeric|min:1',
            'quantity'=>'required',
            'expiry_date'=>'required',
            'manufacturer'=>'required',
            'description'=>'required'
        ]);

        Medicine::create([
            'medicine_name' => $request->medicine_name,
            'amount' => $request->amount,
            'quantity' => $request->quantity,
            'expiry_date' => $request->expiry_date,
            'manufacturer' => $request->manufacturer,
            'description' => $request->description,
        ]);

        return redirect()->route('medicines.index')->with('success', 'Medicine added successfully!');
    }


    public function edit($id)
    {
        $medicine = Medicine::findOrFail($id);
        return view('backend.medicine.edit', compact('medicine'));
    }

    public function update(Request $request, $id)
    {
        
        $request->validate([
            'medicine_name' => 'required',
            'amount' => 'required|string',
            'quantity'=>'required',
            'description'=>'required',
            'expiry_date'=>'required',
            'manufacturer'=>'required',
            'description'=>'required'
            
        ]);

        
        $medicine = Medicine::findOrFail($id);
        $medicine->update([
            'medicine_name' => $request->input('medicine_name'),
            'amount' => $request->input('amount'),
            'description' => $request->input('description'),
            'quantity' => $request->input('quantity', $medicine->quantity),  
            'expiry_date' => $request->input('expiry_date', $medicine->expiry_date),  
            'manufacturer' => $request->input('manufacturer', $medicine->manufacturer), 
        ]);

        
        return redirect()->route('medicines.index')->with('success', 'Medicine updated successfully.');
    }

    public function import(Request $request)
{
    
    $request->validate([
        'file' => 'required|mimes:xls,xlsx'
    ]);

    
    Excel::import(new MedicinesImport, $request->file('file'));

    
    return redirect()->route('medicines.index')->with('success', 'Medicines imported successfully.');
}

    public function destroy($id)
    {
        $medicine = Medicine::findOrFail($id);
        $medicine->delete();
        return redirect()->route('medicines.index')->with('success', 'Medicine deleted successfully');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Pharmacy;
use Illuminate\Http\Request;

class PharmacyController extends Controller
{
    public function index()
    {
        $pharmacies = Pharmacy::all(); 
        return view('backend.pharmacy.index', compact('pharmacies')); 
    }

    
    public function create()
    {
        return view('backend.pharmacy.add_pharmacy'); 
    }

    
    public function store(Request $request)
    {
        $request->validate([
            'pharmacy_name' => 'required|string|max:255',
            'pharmacy_address' => 'required|string',
            'city' => 'required|string|max:255',
            'phone_number' => 'required|string|max:20',
            'email' => 'required|email|unique:pharmacies,email',
        ]);

        Pharmacy::create([
            'pharmacy_name' => $request->pharmacy_name,
            'pharmacy_address' => $request->pharmacy_address,
            'city' => $request->city,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
        ]);

        return redirect()->route('pharmacies.index')->with('success', 'Pharmacy added successfully.');
    }

    
    public function edit($id)
    {
        $pharmacy = Pharmacy::findOrFail($id); 
        return view('backend.pharmacy.edit_pharmacy', compact('pharmacy')); 
    }

   
    public function update(Request $request, $id)
    {
        $pharmacy = Pharmacy::findOrFail($id);

        $request->validate([
            'pharmacy_name' => 'required|string|max:255',
            'pharmacy_address' => 'required|string',
            'city' => 'required|string|max:255',
            'phone_number' => 'required|string|max:20',
            'email' => 'required|email|unique:pharmacies,email,' . $pharmacy->id,
        ]);

        $pharmacy->update([
            'pharmacy_name' => $request->pharmacy_name,
            'pharmacy_address' => $request->pharmacy_address,
            'city' => $request->city,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
        ]);

        return redirect()->route('pharmacies.index')->with('success', 'Pharmacy updated successfully.');
    }

    
    public function destroy($id)
    {
        $pharmacy = Pharmacy::findOrFail($id);
        $pharmacy->delete(); 

        return redirect()->route('pharmacies.index')->with('success', 'Pharmacy deleted successfully.');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PharmacyMedicine;

class PharmacyMedicineController extends Controller
{
    public function addMedicine(Request $request)
    {
        $request->validate([
            'pharmacy_prescription_id' => 'required',
            'medicines.*' => 'required|string|max:255',
            'quantities.*' => 'required|integer|min:1',
            'amounts.*' => 'required|numeric|min:1',
            'total.*' => 'required|numeric'
        ]);

        if ($request->medicines) {
            foreach ($request->medicines as $index => $medicineName) {
                if (isset($request->quantities[$index]) && isset($request->amounts[$index]) && isset($request->total[$index])) {
                    PharmacyMedicine::create([
                        'pharmacy_prescription_id' => $request->pharmacy_prescription_id,
                        'medicine_name' => $medicineName,
                        'quantity' => $request->quantities[$index],
                        'amount' => $request->amounts[$index],
                        'total' => $request->total[$index],
                    ]);
                }
            }
        } else {
            return back()->with(['error' => 'please add medicine']);
        }

        return redirect()->route('pharmacy-prescriptions.index');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PharmacyMedicine extends Model
{
    use HasFactory,SoftDeletes;
    protected $fillable = [
        'pharmacy_prescription_id',
        'medicine_name',
        'quantity',
        'amount',
        'total'
    ];

    public function prescription()
    {
        return $this->belongsTo(PharmacyPrescription::class, 'pharmacy_prescription_id');
    }
}

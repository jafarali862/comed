@extends('dashboard.layout.app')
@section('title', 'Questionnaire List')


@section('content')
<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fas fa-clipboard me-2 text-primary"></i> Questionnaire List
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item active">Questionnaires</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-sync-alt me-1"></i> Reload
            </button>
            <a href="{{ route('company.create_question') }}" class="btn btn-primary">
                <i class="fas fa-clipboard me-1"></i> Add Questionnaire
            </a>
        </div>

        <!-- Card -->
        <div class="card shadow-sm border-0">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Questionnaires</h5>
                <!-- <small class="text-white-50">Total: {{ $questions->count() }}</small> -->
            </div>

            <div class="card-body p-0">
                @if($questions->isEmpty())
                    <div class="p-4 text-center text-muted fst-italic">
                        No questions found.
                    </div>
                @else
                    <div class="table-responsive p-3 mb-3">
                        <table id="questionsTable" class="table table-bordered table-hover text-center align-middle mb-0" style="width:100%">
                            <thead class="table-dark">
                                <tr>
                                    <th style="width: 50px;">#</th>
                                    <th>Question</th>
                                    <th>Input Type</th>
                                    <th>Data Category</th>
                                    <th>Templates</th>
                                    <th style="width: 120px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $i = 1; @endphp
                                @foreach($questions as $q)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td>{{ $q->question }}</td>
                                        <td>{{ $q->input_type }}</td>
                                        <td>{{ $q->data_category }}</td>
                                        <td>
                                            @if($q->templates->isNotEmpty())
                                                @foreach($q->templates as $template)
                                                    <span class="badge bg-primary">{{ $template->template_id }}</span>
                                                @endforeach
                                            @else
                                                <span class="text-muted">Not Assigned</span>
                                            @endif
                                        </td>
                                        <td>
                                            <a href="{{ route('questions.edit_question', $q->id) }}" class="btn btn-sm btn-info" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="{{ route('questions.destroy_question', $q->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger" title="Delete">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>

    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">


<style>
@media (max-width: 576px) {
    /* Hide only the Action column header */
    #questionsTable th:nth-child(6) {
        display: none !important;
    }

    /* Hide only the "Action" title in responsive child rows, keep the data visible */
    li[data-dtr-index="5"] > span.dtr-title {
        display: none !important;
    }
}


</style>

  <script>
    $(document).ready(function () {
        const table = $('#questionsTable');
        if (table.length) {
            table.DataTable({
                paging: true,
                lengthChange: true,
                searching: true,
                ordering: true,
                info: true,
                responsive: true,
                pageLength: 10,
                language: {
                    search: "_INPUT_",
                    searchPlaceholder: "Search companies..."
                },
                columnDefs: [
                    { orderable: false, targets: [5] } // Disable sorting on the "Action" column
                ],
                dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
            });
        }
    });
</script>

  

@endsection
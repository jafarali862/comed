-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: neethi_medicals
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clinic_prescriptions`
--

DROP TABLE IF EXISTS `clinic_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinic_prescriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_time` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prescription` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `test` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_id` bigint unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `clinic_id` bigint unsigned NOT NULL,
  `lat_long` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pres_upload` varchar(600) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '0000',
  `status` int NOT NULL DEFAULT '0',
  `delivery_coordinates` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `test_total` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clinic_prescriptions_user_id_foreign` (`user_id`),
  KEY `clinic_prescriptions_clinic_id_foreign` (`clinic_id`),
  CONSTRAINT `clinic_prescriptions_clinic_id_foreign` FOREIGN KEY (`clinic_id`) REFERENCES `clinics` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_prescriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `clinic_prescriptions_chk_1` CHECK (json_valid(`prescription`)),
  CONSTRAINT `clinic_prescriptions_chk_2` CHECK (json_valid(`test`))
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinic_prescriptions`
--

LOCK TABLES `clinic_prescriptions` WRITE;
/*!40000 ALTER TABLE `clinic_prescriptions` DISABLE KEYS */;
INSERT INTO `clinic_prescriptions` VALUES (73,'test clinic',56,'male',NULL,NULL,'[\"clinic_prescriptions\\/P4mHUrWhQZRE6VjcE0NqqeZilwE0KIiR4SjLYwdx.jpg\"]','[\"Lipid Profile\"]',1,'kondotty',9,'11.180747,75.854546','33',NULL,'2848',2,'11.180754,75.8545757','2025-08-24','2025-08-23 09:48:42','2025-08-24 10:20:55',NULL),(74,'final test',36,'male',NULL,NULL,'[\"clinic_prescriptions\\/46g03mXpXXvtAmbqLoS0AsJZXso7tU1vR7BJMDoO.jpg\"]','[\"Lipid Profile,Liver Function Tests\"]',1,'test',9,'11.1807571,75.8545779','33',NULL,'6743',2,'11.1807577,75.8545744','2025-08-25','2025-08-24 10:24:44','2025-08-24 10:26:27',NULL),(75,'mishal',26,'male',NULL,NULL,'[\"clinic_prescriptions\\/Vmezfszbmd90KP1ObcuODbflFeNfcIJCW11uuecV.jpg\"]','[\"Complete Blood Count (CBC),Lipid Profile,Liver Function Tests\"]',1,'qwrtt',9,'11.1812247,75.848988','33',NULL,'9899',4,NULL,'2025-08-25','2025-08-24 12:49:57','2025-08-24 12:52:51',NULL),(76,'udith',21,'male',NULL,NULL,'[\"clinic_prescriptions\\/jZX6XqdyTx7PXtTiemn4XP9ENPQBVvgjLx26EMLn.jpg\"]','[\"Kidney Function Tests (RFT),Liver Function Tests,Lipid Profile\"]',1,'kondotty',9,'11.1813513,75.8488016','33',NULL,'1035',4,NULL,'2025-08-25','2025-08-24 12:55:17','2025-08-24 12:56:10',NULL),(77,'jafar',23,'male',NULL,NULL,'[]','[\"Lipid Profile\"]',1,'vga',9,'11.1807584,75.854578','33',NULL,'7814',2,'11.1807392,75.8545717','2025-08-26','2025-08-26 04:08:51','2025-09-08 11:00:52',NULL),(78,'udith clinic',23,'male',NULL,NULL,'[\"clinic_prescriptions\\/94KHtTAXboOxnGq461ZoxNVVWmtXa0xyjpsPDdGI.jpg\"]','[\"Complete Blood Count (CBC),Lipid Profile,Liver Function Tests\"]',1,'areakode road kondotty',9,'11.180743,75.854582','33','prescriptions/1756872460_Screenshot (1).png','9554',4,'11.1807375,75.8545803','2025-09-04','2025-09-03 03:47:46','2025-09-03 04:07:40',NULL),(79,'udith clinic',23,'male',NULL,NULL,'[\"clinic_prescriptions\\/Ivj5Kfe6q5jUXvM8mCM4Vl3EEDj8GdOMz7agY05q.jpg\"]','[\"Liver Function Tests\"]',1,'areakode road kondotty',9,'11.1807359,75.8545847',NULL,NULL,'0000',5,NULL,'2025-09-04','2025-09-03 04:09:54','2025-09-04 07:41:32',NULL),(80,'Sulochana',58,'female','9:29 PM','10:29 PM','[\"clinic_prescriptions\\/opeowiqJZW6YYch1MMpeqwHNBWdwAAPi2mCmxlli.jpg\"]','[\"Kidney Function Tests (RFT),Liver Function Tests\"]',1,'area',9,'11.1807374,75.8545817','33','prescriptions/1756890443_insurance.pdf','7897',4,'11.1807521,75.8545665','2025-09-04','2025-09-03 08:59:29','2025-09-03 09:07:23',NULL),(81,'admin',23,'male',NULL,NULL,'[\"clinic_prescriptions\\/SuZqwTKab19w5OPkUGnfwfofsVWBS74up5vLrGsu.jpg\"]','[\"Blood Test,CBC (Complete Blood Count)\"]',1,'dubai',9,'11.180741,75.854581','33',NULL,'5484',2,'11.1807388,75.8545789','2025-09-05','2025-09-04 07:43:37','2025-09-09 03:51:42',NULL),(82,'ghj',23,'female',NULL,NULL,'[\"clinic_prescriptions\\/WyR5k24ilMj0Z2EJPabI5YBi7gxGNDC45FGYQRv1.jpg\"]','[\"Thyroid Profile,Lipid Profile\"]',1,'efhj',9,'11.1807361,75.8545818',NULL,NULL,'0000',0,NULL,'2025-09-05','2025-09-04 07:49:42','2025-09-04 07:49:42','580.0'),(83,'sanu',23,'male',NULL,NULL,'[]','[\"Blood Test,CBC (Complete Blood Count)\"]',1,'hshshjqj',9,'11.1807313,75.8545797','33','prescriptions/1757390100_insurance (14).pdf','6550',4,'11.1807422,75.8545763','2025-09-09','2025-09-08 11:41:52','2025-09-09 03:55:00','320.0'),(84,'ryvvh',33,'male',NULL,NULL,'[]','[null]',1,'vgfhu',9,'11.1807386,75.8545798',NULL,NULL,'0000',0,NULL,'2025-09-09','2025-09-08 11:47:13','2025-09-08 11:47:13','0.0'),(85,'nandana',22,'female',NULL,NULL,'[\"clinic_prescriptions\\/f6g6gv58HCgC0PnODSeQkO1ckjZyZQpePlcfhofd.jpg\"]','[\"Blood Test\"]',45,'vengara',9,'11.1807326,75.8545815',NULL,NULL,'0000',0,NULL,'2025-09-10','2025-09-09 04:55:30','2025-09-09 04:55:30','120.0'),(86,'JAHFAR',53,'male',NULL,NULL,'[]','[\"CBC (Complete Blood Count)\"]',49,'Areekode',9,'11.2352669,76.0522168',NULL,NULL,'0000',0,NULL,'2025-09-09','2025-09-09 08:20:24','2025-09-09 08:20:24','200.0'),(87,'afreena',30,'male',NULL,NULL,'[\"clinic_prescriptions\\/avTnzrw7MdHJODQgwbg8vR7u0g02zGBWCLPyf35V.jpg\"]','[null]',48,'areekode',9,'11.2352591,76.0522152','33','prescriptions/1757406623_6.pdf','4503',4,'11.2352681,76.0522064','2025-09-09','2025-09-09 08:22:41','2025-09-09 08:30:23','0.0'),(88,'suparna',27,'female',NULL,NULL,'[]','[null]',46,'puthukkudy vazhappatta house mundambra \nUgrappuram \nAREEKODE',9,'11.2352641,76.052216',NULL,NULL,'0000',0,NULL,'2025-09-09','2025-09-09 08:23:05','2025-09-09 08:23:05','0.0'),(89,'noushaja',39,'female',NULL,NULL,'[]','[null]',51,'noonjimmal',9,'0.0,0.0',NULL,NULL,'0000',0,NULL,'2025-09-09','2025-09-09 08:24:54','2025-09-09 08:24:54','0.0'),(90,'JAHFAR',53,'male','1:54 PM','4:54 PM','[\"clinic_prescriptions\\/lG19uVl6Iv89cR7HnHiMV9BEAt4VGzli5wT5v9VV.jpg\"]','[null]',49,'Areekode',9,'11.2352661,76.0522134',NULL,NULL,'0000',0,NULL,'2025-09-09','2025-09-09 08:25:12','2025-09-09 08:25:12','0.0');
/*!40000 ALTER TABLE `clinic_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clinics`
--

DROP TABLE IF EXISTS `clinics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clinics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `clinic_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `clinic_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `clinic_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clinics_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinics`
--

LOCK TABLES `clinics` WRITE;
/*!40000 ALTER TABLE `clinics` DISABLE KEYS */;
INSERT INTO `clinics` VALUES (9,'Neethi Lab','Near Rajadhani Furniture & Vazhayil Masjid in Areekode','clinic_photos/qlWiT5BNBpAwpINXr2ldZlsa3FyCxkBgVq6KEeF6.png','Areekode','75010895815','neethilab@gmail.com','2025-08-20 09:18:37','2025-08-20 09:18:37');
/*!40000 ALTER TABLE `clinics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_agents`
--

DROP TABLE IF EXISTS `delivery_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_agents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `delivery_agent_id` bigint unsigned NOT NULL,
  `pres_id` bigint unsigned DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coordinates` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `customer_mob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_coordinates` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `delivery_agents_delivery_agent_id_foreign` (`delivery_agent_id`),
  KEY `delivery_agents_customer_id_foreign` (`customer_id`),
  KEY `delivery_agents_pres_id_foreign` (`pres_id`),
  CONSTRAINT `delivery_agents_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_agents_delivery_agent_id_foreign` FOREIGN KEY (`delivery_agent_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_agents_pres_id_foreign` FOREIGN KEY (`pres_id`) REFERENCES `pharmacy_prescriptions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_agents`
--

LOCK TABLES `delivery_agents` WRITE;
/*!40000 ALTER TABLE `delivery_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `log_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `logs_user_id_foreign` (`user_id`),
  CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=555 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (1,1,'medicine Imported','Medicine xls uploaded by: Admin','2025-02-28 05:34:05','2025-02-28 05:34:05'),(2,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-02-28 05:39:18','2025-02-28 05:39:18'),(3,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-02-28 05:39:43','2025-02-28 05:39:43'),(4,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-02-28 05:41:31','2025-02-28 05:41:31'),(5,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-02-28 05:41:46','2025-02-28 05:41:46'),(6,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-02-28 05:42:03','2025-02-28 05:42:03'),(7,1,'clinic Prescription Processed','clinic Prescription user:john processed by: Admin','2025-02-28 05:42:10','2025-02-28 05:42:10'),(8,1,'Pharmacy Medicine created','Pharmacy Medicine: Paraxin Cap. 500mg created by: Admin','2025-03-01 00:54:19','2025-03-01 00:54:19'),(9,1,'Pharmacy Medicine created','Pharmacy Medicine: AB Flo SR created by: Admin','2025-03-01 00:59:25','2025-03-01 00:59:25'),(10,1,'Pharmacy Medicine created','Pharmacy Medicine: AB Phylline Cap. created by: Admin','2025-03-01 01:09:58','2025-03-01 01:09:58'),(11,1,'Pharmacy Medicine created','Pharmacy Medicine: AB Flo SR created by: Admin','2025-03-01 01:09:58','2025-03-01 01:09:58'),(12,1,'Pharmacy Medicine created','Pharmacy Medicine: Ab Phylline N created by: Admin','2025-03-01 01:09:58','2025-03-01 01:09:58'),(13,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-03-01 01:25:40','2025-03-01 01:25:40'),(14,1,'Pharmacy Medicine created','Pharmacy Medicine: Abvida  SR 100 TAB created by: Admin','2025-03-01 04:42:28','2025-03-01 04:42:28'),(15,1,'Pharmacy Medicine created','Pharmacy Medicine: Abendol Tab created by: Admin','2025-03-01 04:42:28','2025-03-01 04:42:28'),(16,1,'Pharmacy Medicine created','Pharmacy Medicine: Abvida  SR 100 TAB created by: Admin','2025-03-01 04:44:07','2025-03-01 04:44:07'),(17,1,'Pharmacy Medicine created','Pharmacy Medicine: Abzorb Powder 50gm created by: Admin','2025-03-01 06:14:28','2025-03-01 06:14:28'),(18,1,'Pharmacy Medicine created','Pharmacy Medicine: Ab Phylline N created by: Admin','2025-03-03 23:22:43','2025-03-03 23:22:43'),(19,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-03-14 04:54:02','2025-03-14 04:54:02'),(20,1,'Pharmacy Medicine created','Pharmacy Medicine: AB Phylline Cap. created by: Admin','2025-04-21 06:31:11','2025-04-21 06:31:11'),(21,1,'Pharmacy Medicine created','Pharmacy Medicine: Paraxin Cap. 500mg created by: Admin','2025-04-21 06:33:12','2025-04-21 06:33:12'),(22,1,'Pharmacy Medicine created','Pharmacy Medicine: Ab Flo Cap created by: Admin','2025-04-25 04:40:30','2025-04-25 04:40:30'),(23,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-04-26 01:37:34','2025-04-26 01:37:34'),(24,1,'New User Created','New User: udithcreated by Admin','2025-05-05 23:55:44','2025-05-05 23:55:44'),(25,1,'Pharmacy Medicine created','Pharmacy Medicine: AB DAY PLUS created by: Admin','2025-05-07 02:32:28','2025-05-07 02:32:28'),(26,1,'Pharmacy Medicine created','Pharmacy Medicine: Ab Flo Cap created by: Admin','2025-05-07 02:58:19','2025-05-07 02:58:19'),(27,1,'Pharmacy Medicine created','Pharmacy Medicine: Ab Flo Cap created by: Admin','2025-05-07 03:35:39','2025-05-07 03:35:39'),(28,1,'New User Created','New User: testcreated by Admin','2025-05-07 03:38:42','2025-05-07 03:38:42'),(29,1,'Pharmacy Medicine created','Pharmacy Medicine: AB DAY SR 200 TAB created by: Admin','2025-05-07 03:40:29','2025-05-07 03:40:29'),(30,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-05-08 00:11:18','2025-05-08 00:11:18'),(31,1,'Pharmacy Medicine created','Pharmacy Medicine: Aciloc 150 Tab. created by: Admin','2025-05-08 00:16:36','2025-05-08 00:16:36'),(32,1,'clinic Prescription Processed','clinic Prescription user:john processed by: Admin','2025-05-08 22:29:23','2025-05-08 22:29:23'),(33,1,'clinic Prescription Processed','clinic Prescription user:john processed by: Admin','2025-05-08 22:30:32','2025-05-08 22:30:32'),(34,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-05-08 22:31:45','2025-05-08 22:31:45'),(35,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-05-08 22:31:55','2025-05-08 22:31:55'),(36,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-05-08 22:32:04','2025-05-08 22:32:04'),(37,1,'clinic Prescription Processed','clinic Prescription user:ghhgg processed by: Admin','2025-05-08 22:32:22','2025-05-08 22:32:22'),(38,1,'Pharmacy Medicine created','Pharmacy Medicine: AF 200 MG created by: Admin','2025-05-09 04:53:04','2025-05-09 04:53:04'),(39,1,'Pharmacy Medicine created','Pharmacy Medicine: 8X SHAMPOO created by: Admin','2025-05-17 01:27:51','2025-05-17 01:27:51'),(40,1,'New User Created','New User: Test usercreated by Admin','2025-05-19 04:32:38','2025-05-19 04:32:38'),(41,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-05-25 22:53:45','2025-05-25 22:53:45'),(42,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-05-25 22:55:25','2025-05-25 22:55:25'),(43,1,'clinic Prescription updated','clinic address:vengaraand status:2 updated by: Admin','2025-05-25 22:55:29','2025-05-25 22:55:29'),(44,1,'clinic Prescription Processed','clinic Prescription user:john processed by: Admin','2025-05-25 23:15:18','2025-05-25 23:15:18'),(45,1,'Pharmacy Medicine created','Pharmacy Medicine: AB Flo SR created by: Admin','2025-05-25 23:26:33','2025-05-25 23:26:33'),(46,1,'Pharmacy Medicine created','Pharmacy Medicine: Acitrom Tab. 3mg created by: Admin','2025-05-25 23:26:33','2025-05-25 23:26:33'),(47,1,'User updated','User: user55 , user Id: 4 , User updated by Admin','2025-05-25 23:41:12','2025-05-25 23:41:12'),(48,1,'User updated','User: arun , user Id: 5 , User updated by Admin','2025-05-25 23:43:08','2025-05-25 23:43:08'),(49,1,'User updated','User: arun , user Id: 5 , User updated by Admin','2025-05-26 00:04:52','2025-05-26 00:04:52'),(50,1,'User Deleted','User: abraham , user Id: 6 , User deleted by Admin','2025-05-26 01:07:18','2025-05-26 01:07:18'),(51,1,'User Deleted','User: abraham , user Id: 7 , User deleted by Admin','2025-05-26 01:07:26','2025-05-26 01:07:26'),(52,1,'User Deleted','User: check , user Id: 2 , User deleted by Admin','2025-05-26 01:08:27','2025-05-26 01:08:27'),(53,1,'User Deleted','User: john 123 , user Id: 12 , User deleted by Admin','2025-05-26 01:08:51','2025-05-26 01:08:51'),(54,1,'User Deleted','User: teatuser , user Id: 8 , User deleted by Admin','2025-05-26 01:08:56','2025-05-26 01:08:56'),(55,1,'User Deleted','User: test , user Id: 14 , User deleted by Admin','2025-05-26 01:09:01','2025-05-26 01:09:01'),(56,1,'User Deleted','User: Test user , user Id: 15 , User deleted by Admin','2025-05-26 01:09:06','2025-05-26 01:09:06'),(57,1,'User Deleted','User: udith , user Id: 13 , User deleted by Admin','2025-05-26 01:09:41','2025-05-26 01:09:41'),(58,1,'User Deleted','User: user , user Id: 9 , User deleted by Admin','2025-05-26 01:09:45','2025-05-26 01:09:45'),(59,1,'User updated','User: user55 , user Id: 4 , User updated by Admin','2025-05-26 01:11:58','2025-05-26 01:11:58'),(60,1,'User updated','User: user55hhgfh , user Id: 4 , User updated by Admin','2025-05-26 01:12:20','2025-05-26 01:12:20'),(61,1,'User updated','User: user55hhgfh , user Id: 4 , User updated by Admin','2025-05-26 01:12:34','2025-05-26 01:12:34'),(62,1,'User updated','User: johntyrtyrty , user Id: 10 , User updated by Admin','2025-05-26 01:13:42','2025-05-26 01:13:42'),(63,1,'User updated','User: arun , user Id: 5 , User updated by Admin','2025-05-26 01:14:17','2025-05-26 01:14:17'),(64,1,'New User Created','New User: Testcreated by Admin','2025-05-26 01:17:57','2025-05-26 01:17:57'),(65,1,'clinic created','clinic: Fathimas Clinic created by Admin','2025-05-26 01:22:58','2025-05-26 01:22:58'),(66,1,'clinic Deleted','Clinic: Kameko Lambert deleted by: Admin','2025-05-26 01:23:25','2025-05-26 01:23:25'),(67,1,'clinic Deleted','Clinic: Tad Moreno deleted by: Admin','2025-05-26 01:23:30','2025-05-26 01:23:30'),(68,1,'clinic Deleted','Clinic: Ryder Wiley deleted by: Admin','2025-05-26 01:23:40','2025-05-26 01:23:40'),(69,1,'clinic Updated','clinic: Fathimas Clinic updated by: Admin','2025-05-26 01:24:30','2025-05-26 01:24:30'),(70,1,'Pharmacy created','Pharmacy: Neethi kondotty updated by Admin','2025-05-26 01:29:22','2025-05-26 01:29:22'),(71,1,'Pharmacy created','Pharmacy: Maxwell uioui updated by Admin','2025-05-26 01:30:00','2025-05-26 01:30:00'),(72,1,'New User Created','New User: Jafaralicreated by Admin','2025-05-26 01:32:14','2025-05-26 01:32:14'),(73,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 01:39:26','2025-05-26 01:39:26'),(74,1,'clinic Prescription updated','clinic address:vengaraand status:2 updated by: Admin','2025-05-26 01:41:04','2025-05-26 01:41:04'),(75,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 01:42:26','2025-05-26 01:42:26'),(76,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 01:43:23','2025-05-26 01:43:23'),(77,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 01:47:34','2025-05-26 01:47:34'),(78,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 03:24:30','2025-05-26 03:24:30'),(79,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 03:55:26','2025-05-26 03:55:26'),(80,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 03:55:55','2025-05-26 03:55:55'),(81,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:07:32','2025-05-26 04:07:32'),(82,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:25:18','2025-05-26 04:25:18'),(83,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:25:24','2025-05-26 04:25:24'),(84,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:26:55','2025-05-26 04:26:55'),(85,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:27:09','2025-05-26 04:27:09'),(86,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 04:27:48','2025-05-26 04:27:48'),(87,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-26 05:09:22','2025-05-26 05:09:22'),(88,1,'Pharmacy created','Pharmacy: Maxwell uioui updated by Admin','2025-05-27 00:22:25','2025-05-27 00:22:25'),(89,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-27 00:31:39','2025-05-27 00:31:39'),(90,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-27 00:34:35','2025-05-27 00:34:35'),(91,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-27 00:37:57','2025-05-27 00:37:57'),(92,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-05-27 00:38:19','2025-05-27 00:38:19'),(93,1,'New User Created','New User: testusercreated by Admin','2025-05-30 00:59:32','2025-05-30 00:59:32'),(94,1,'User Deleted','User: testuser , user Id: 18 , User deleted by Admin','2025-05-31 04:55:14','2025-05-31 04:55:14'),(95,1,'User Deleted','User: Jafarali , user Id: 17 , User deleted by Admin','2025-05-31 04:57:05','2025-05-31 04:57:05'),(96,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-01 23:15:52','2025-06-01 23:15:52'),(97,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-01 23:26:55','2025-06-01 23:26:55'),(98,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-01 23:42:53','2025-06-01 23:42:53'),(99,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 00:43:11','2025-06-02 00:43:11'),(100,1,'clinic Prescription updated','clinic address:vengaraand status:1 updated by: Admin','2025-06-02 00:43:38','2025-06-02 00:43:38'),(101,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 00:44:32','2025-06-02 00:44:32'),(102,1,'clinic Prescription updated','clinic address:areekadand status:2 updated by: Admin','2025-06-02 00:44:39','2025-06-02 00:44:39'),(103,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-06-02 00:45:30','2025-06-02 00:45:30'),(104,1,'clinic Prescription Processed','clinic Prescription user:Test processed by: Admin','2025-06-02 00:45:43','2025-06-02 00:45:43'),(105,1,'New User Created','New User: fgfghfgcreated by Admin','2025-06-02 00:50:06','2025-06-02 00:50:06'),(106,1,'User Deleted','User: fgfghfg , user Id: 19 , User deleted by Admin','2025-06-02 00:50:21','2025-06-02 00:50:21'),(107,1,'User updated','User: dashbb , user Id: 4 , User updated by Admin','2025-06-02 00:53:14','2025-06-02 00:53:14'),(108,1,'User Deleted','User: johntyrtyrty , user Id: 10 , User deleted by Admin','2025-06-02 01:04:02','2025-06-02 01:04:02'),(109,1,'User Deleted','User: dashbb , user Id: 4 , User deleted by Admin','2025-06-02 01:04:11','2025-06-02 01:04:11'),(110,1,'User updated','User: Testgdg , user Id: 16 , User updated by Admin','2025-06-02 01:13:06','2025-06-02 01:13:06'),(111,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 01:16:20','2025-06-02 01:16:20'),(112,1,'clinic Prescription updated','clinic address:cheruvannoorand status:1 updated by: Admin','2025-06-02 01:16:45','2025-06-02 01:16:45'),(113,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 01:18:46','2025-06-02 01:18:46'),(114,1,'New User Created','New User: qqcreated by Admin','2025-06-02 01:49:05','2025-06-02 01:49:05'),(115,1,'User Deleted','User: qq , user Id: 20 , User deleted by Admin','2025-06-02 01:50:02','2025-06-02 01:50:02'),(116,1,'New User Created','New User: deliverycreated by Admin','2025-06-02 02:21:08','2025-06-02 02:21:08'),(117,1,'Pharmacy created','Pharmacy: New Pharmacy created by Admin','2025-06-02 02:42:01','2025-06-02 02:42:01'),(118,1,'Pharmacy created','Pharmacy: New Pharmacy updated by Admin','2025-06-02 02:42:34','2025-06-02 02:42:34'),(119,1,'New User Created','New User: Deliverycreated by Admin','2025-06-02 02:44:59','2025-06-02 02:44:59'),(120,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:16:45','2025-06-02 05:16:45'),(121,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:17:23','2025-06-02 05:17:23'),(122,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:18:09','2025-06-02 05:18:09'),(123,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:27:28','2025-06-02 05:27:28'),(124,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:29:13','2025-06-02 05:29:13'),(125,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 05:31:47','2025-06-02 05:31:47'),(126,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 06:10:41','2025-06-02 06:10:41'),(127,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 06:13:54','2025-06-02 06:13:54'),(128,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 06:14:02','2025-06-02 06:14:02'),(129,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 06:17:09','2025-06-02 06:17:09'),(130,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 06:48:51','2025-06-02 06:48:51'),(131,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 23:37:48','2025-06-02 23:37:48'),(132,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-02 23:37:55','2025-06-02 23:37:55'),(133,1,'medicine Imported','Medicine xls uploaded by: Admin','2025-06-03 00:26:43','2025-06-03 00:26:43'),(134,1,'medicine added','Medicine: vv added by: Admin','2025-06-03 00:48:14','2025-06-03 00:48:14'),(135,1,'medicine added','Medicine: vv added by: Admin','2025-06-03 00:52:20','2025-06-03 00:52:20'),(136,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-03 01:50:43','2025-06-03 01:50:43'),(137,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-03 01:50:54','2025-06-03 01:50:54'),(138,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-03 04:38:04','2025-06-03 04:38:04'),(139,1,'medicine added','Medicine: AB DAY SR 200 TAB added by: Admin','2025-06-03 06:00:58','2025-06-03 06:00:58'),(140,1,'medicine added','Medicine: Ab Flo Cap added by: Admin','2025-06-03 06:02:20','2025-06-03 06:02:20'),(141,1,'medicine added','Medicine: Abvida SR 100 TAB added by: Admin','2025-06-03 06:06:56','2025-06-03 06:06:56'),(142,1,'medicine added','Medicine: Alphagan P Eye Drops 5ml added by: Admin','2025-06-03 06:22:37','2025-06-03 06:22:37'),(143,1,'medicine added','Medicine: Amaryl MV2 added by: Admin','2025-06-03 06:23:32','2025-06-03 06:23:32'),(144,1,'medicine added','Medicine: Amifru 40 Tab added by: Admin','2025-06-03 06:24:33','2025-06-03 06:24:33'),(145,1,'medicine added','Medicine: Angispan TR Cap. 2.5mg added by: Admin','2025-06-03 06:26:07','2025-06-03 06:26:07'),(146,1,'Pharmacy Medicine created','Pharmacy Medicine: Alphagan P Eye Drops 5ml created by: Admin','2025-06-03 22:24:17','2025-06-03 22:24:17'),(147,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-03 22:33:16','2025-06-03 22:33:16'),(148,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-03 23:00:44','2025-06-03 23:00:44'),(149,1,'clinic Prescription updated','clinic address:helloand status:1 updated by: Admin','2025-06-03 23:00:53','2025-06-03 23:00:53'),(150,1,'medicine added','Medicine: Adilip 45 added by: Admin','2025-06-03 23:02:20','2025-06-03 23:02:20'),(151,1,'medicine added','Medicine: AFK LOTION 100ML added by: Admin','2025-06-03 23:03:51','2025-06-03 23:03:51'),(152,1,'New User Created','New User: Customercreated by Admin','2025-06-04 05:09:45','2025-06-04 05:09:45'),(153,1,'clinic created','clinic: Clinics1 created by Admin','2025-06-04 05:14:22','2025-06-04 05:14:22'),(154,1,'Pharmacy created','Pharmacy: Pharmacy1 created by Admin','2025-06-04 05:15:49','2025-06-04 05:15:49'),(155,1,'New User Created','New User: pharamcy usercreated by Admin','2025-06-04 05:19:14','2025-06-04 05:19:14'),(156,1,'New User Created','New User: deliverycreated by Admin','2025-06-04 05:29:17','2025-06-04 05:29:17'),(157,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-04 05:33:21','2025-06-04 05:33:21'),(158,1,'clinic Prescription updated','clinic address:kondottyand status:2 updated by: Admin','2025-06-04 05:33:36','2025-06-04 05:33:36'),(159,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-04 05:35:38','2025-06-04 05:35:38'),(160,1,'clinic Prescription updated','clinic address:vengaraand status:1 updated by: Admin','2025-06-04 05:35:48','2025-06-04 05:35:48'),(161,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-04 05:45:38','2025-06-04 05:45:38'),(162,1,'New User Created','New User: testcreated by Admin','2025-06-04 06:05:22','2025-06-04 06:05:22'),(163,1,'User Deleted','User: test , user Id: 27 , User deleted by Admin','2025-06-04 22:09:36','2025-06-04 22:09:36'),(164,1,'New User Created','New User: Test usercreated by Admin','2025-06-04 22:10:27','2025-06-04 22:10:27'),(165,1,'User Deleted','User: Test user , user Id: 28 , User deleted by Admin','2025-06-04 22:48:35','2025-06-04 22:48:35'),(166,1,'New User Created','New User: Testcreated by Admin','2025-06-04 22:57:31','2025-06-04 22:57:31'),(167,1,'User Deleted','User: Test , user Id: 29 , User deleted by Admin','2025-06-04 22:59:39','2025-06-04 22:59:39'),(168,1,'medicine added','Medicine: Amaryl Tab. 2mg added by: Admin','2025-06-04 23:34:28','2025-06-04 23:34:28'),(169,1,'medicine added','Medicine: AB DAY SR 200 TAB added by: Admin','2025-06-04 23:35:51','2025-06-04 23:35:51'),(170,1,'medicine added','Medicine: Abendol Tab added by: Admin','2025-06-04 23:37:04','2025-06-04 23:37:04'),(171,1,'medicine added','Medicine: ABLUNG N TAB added by: Admin','2025-06-04 23:38:19','2025-06-04 23:38:19'),(172,1,'medicine added','Medicine: Aimet XR 50MG added by: Admin','2025-06-04 23:40:39','2025-06-04 23:40:39'),(173,1,'medicine added','Medicine: ALERID 60 ML added by: Admin','2025-06-04 23:42:03','2025-06-04 23:42:03'),(174,1,'medicine added','Medicine: Alprax Tab. 0.25mg added by: Admin','2025-06-04 23:43:25','2025-06-04 23:43:25'),(175,1,'medicine added','Medicine: ALZIL M FORTE added by: Admin','2025-06-04 23:44:53','2025-06-04 23:44:53'),(176,1,'medicine added','Medicine: AMIDE 200MG added by: Admin','2025-06-04 23:46:00','2025-06-04 23:46:00'),(177,1,'medicine added','Medicine: Amlodac Tab 5mg added by: Admin','2025-06-04 23:47:21','2025-06-04 23:47:21'),(178,1,'medicine added','Medicine: Allercet 10 Tab added by: Admin','2025-06-05 00:39:16','2025-06-05 00:39:16'),(179,1,'medicine added','Medicine: ALZIL M FORTE added by: Admin','2025-06-05 00:40:51','2025-06-05 00:40:51'),(180,1,'medicine added','Medicine: Amlovas 5 Tab added by: Admin','2025-06-05 00:42:01','2025-06-05 00:42:01'),(181,1,'medicine added','Medicine: Aquasoft Cream 60GM added by: Admin','2025-06-05 00:43:20','2025-06-05 00:43:20'),(182,1,'medicine added','Medicine: Argin Plus added by: Admin','2025-06-05 00:44:16','2025-06-05 00:44:16'),(183,1,'medicine added','Medicine: Asthakind Tab added by: Admin','2025-06-05 00:45:24','2025-06-05 00:45:24'),(184,1,'medicine added','Medicine: Atarax Drops 15ml added by: Admin','2025-06-05 00:46:20','2025-06-05 00:46:20'),(185,1,'medicine added','Medicine: Azibest Tab. 500mg added by: Admin','2025-06-05 00:47:59','2025-06-05 00:47:59'),(186,1,'medicine added','Medicine: Wakfree Tab added by: Admin','2025-06-05 01:00:50','2025-06-05 01:00:50'),(187,1,'medicine added','Medicine: Welvida 50 added by: Admin','2025-06-05 01:02:06','2025-06-05 01:02:06'),(188,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-05 01:03:11','2025-06-05 01:03:11'),(189,1,'New User Created','New User: jafarcreated by Admin','2025-06-05 01:36:26','2025-06-05 01:36:26'),(190,1,'New User Created','New User: Test usercreated by Admin','2025-06-05 06:02:15','2025-06-05 06:02:15'),(191,1,'User updated','User: Test user , user Id: 31 , User updated by Admin','2025-06-05 06:04:36','2025-06-05 06:04:36'),(192,1,'User updated','User: pharamcy user , user Id: 25 , User updated by Admin','2025-06-05 22:27:59','2025-06-05 22:27:59'),(193,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:45:11','2025-06-20 23:45:11'),(194,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:45:35','2025-06-20 23:45:35'),(195,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:45:53','2025-06-20 23:45:53'),(196,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:45:57','2025-06-20 23:45:57'),(197,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:46:43','2025-06-20 23:46:43'),(198,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-20 23:47:00','2025-06-20 23:47:00'),(199,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:06:52','2025-06-21 00:06:52'),(200,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:06:58','2025-06-21 00:06:58'),(201,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:07:02','2025-06-21 00:07:02'),(202,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:07:05','2025-06-21 00:07:05'),(203,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:07:11','2025-06-21 00:07:11'),(204,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 00:07:52','2025-06-21 00:07:52'),(205,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 02:57:08','2025-06-21 02:57:08'),(206,1,'Pharmacy created','Pharmacy: Pharamcy late created by Admin','2025-06-21 03:14:36','2025-06-21 03:14:36'),(207,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 03:23:39','2025-06-21 03:23:39'),(208,1,'clinic Prescription updated','clinic address:trissurand status:1 updated by: Admin','2025-06-21 03:23:56','2025-06-21 03:23:56'),(209,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 03:24:14','2025-06-21 03:24:14'),(210,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 03:24:34','2025-06-21 03:24:34'),(211,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 03:24:45','2025-06-21 03:24:45'),(212,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 03:26:34','2025-06-21 03:26:34'),(213,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-21 06:25:00','2025-06-21 06:25:00'),(214,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-23 22:26:58','2025-06-23 22:26:58'),(215,1,'clinic Prescription updated','clinic address:kondottyand status:2 updated by: Admin','2025-06-23 22:27:04','2025-06-23 22:27:04'),(216,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-23 23:39:26','2025-06-23 23:39:26'),(217,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:26','2025-06-23 23:39:26'),(218,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:28','2025-06-23 23:39:28'),(219,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:28','2025-06-23 23:39:28'),(220,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:35','2025-06-23 23:39:35'),(221,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:44','2025-06-23 23:39:44'),(222,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-23 23:39:50','2025-06-23 23:39:50'),(223,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-24 01:48:37','2025-06-24 01:48:37'),(224,1,'clinic Prescription updated','clinic address:ramanattukaraand status:1 updated by: Admin','2025-06-24 01:52:39','2025-06-24 01:52:39'),(225,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 05:23:38','2025-06-26 05:23:38'),(226,1,'clinic Prescription updated','clinic address:kunjaand status:2 updated by: Admin','2025-06-26 05:23:51','2025-06-26 05:23:51'),(227,1,'clinic created','clinic: gggggggggggggf created by Admin','2025-06-26 22:40:58','2025-06-26 22:40:58'),(228,1,'clinic Deleted','Clinic: gggggggggggggf deleted by: Admin','2025-06-26 22:41:03','2025-06-26 22:41:03'),(229,1,'Pharmacy created','Pharmacy: pharamcy4477 created by Admin','2025-06-26 22:41:31','2025-06-26 22:41:31'),(230,1,'New User Created','New User: Veena Pcreated by Admin','2025-06-26 22:42:54','2025-06-26 22:42:54'),(231,1,'User Deleted','User: Veena P , user Id: 32 , User deleted by Admin','2025-06-26 22:42:59','2025-06-26 22:42:59'),(232,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:43:22','2025-06-26 22:43:22'),(233,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-26 22:43:28','2025-06-26 22:43:28'),(234,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-26 22:43:40','2025-06-26 22:43:40'),(235,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-26 22:47:25','2025-06-26 22:47:25'),(236,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:47:38','2025-06-26 22:47:38'),(237,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:47:55','2025-06-26 22:47:55'),(238,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:48:08','2025-06-26 22:48:08'),(239,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:48:43','2025-06-26 22:48:43'),(240,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:49:34','2025-06-26 22:49:34'),(241,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-26 22:50:14','2025-06-26 22:50:14'),(242,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:50:41','2025-06-26 22:50:41'),(243,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-26 22:53:03','2025-06-26 22:53:03'),(244,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:53:23','2025-06-26 22:53:23'),(245,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:54:32','2025-06-26 22:54:32'),(246,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:56:01','2025-06-26 22:56:01'),(247,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:56:18','2025-06-26 22:56:18'),(248,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:56:23','2025-06-26 22:56:23'),(249,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-26 22:58:07','2025-06-26 22:58:07'),(250,1,'New User Created','New User: Dascreated by Admin','2025-06-26 23:33:59','2025-06-26 23:33:59'),(251,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-27 00:06:07','2025-06-27 00:06:07'),(252,1,'clinic Prescription updated','clinic address:areekad and status:1 updated by: Admin','2025-06-27 00:06:15','2025-06-27 00:06:15'),(253,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 00:08:21','2025-06-27 00:08:21'),(254,1,'clinic Prescription updated','clinic address:ramu and status:1 updated by: Admin','2025-06-27 00:08:29','2025-06-27 00:08:29'),(255,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 00:20:36','2025-06-27 00:20:36'),(256,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-27 00:47:42','2025-06-27 00:47:42'),(257,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 01:03:27','2025-06-27 01:03:27'),(258,1,'clinic Prescription updated','clinic address:kondotty and status:1 updated by: Admin','2025-06-27 01:03:34','2025-06-27 01:03:34'),(259,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 01:51:40','2025-06-27 01:51:40'),(260,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-27 03:00:57','2025-06-27 03:00:57'),(261,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 04:11:33','2025-06-27 04:11:33'),(262,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-27 04:19:48','2025-06-27 04:19:48'),(263,1,'clinic Prescription updated','clinic address:vengara and status:1 updated by: Admin','2025-06-27 04:19:55','2025-06-27 04:19:55'),(264,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-06-27 23:34:06','2025-06-27 23:34:06'),(265,1,'clinic Prescription updated','clinic address:malappuram and status:1 updated by: Admin','2025-06-27 23:34:23','2025-06-27 23:34:23'),(266,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-27 23:42:47','2025-06-27 23:42:47'),(267,1,'clinic Prescription updated','clinic address:vengara and status:1 updated by: Admin','2025-06-27 23:42:53','2025-06-27 23:42:53'),(268,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 01:25:28','2025-06-28 01:25:28'),(269,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 01:29:33','2025-06-28 01:29:33'),(270,1,'clinic Prescription updated','clinic address:perinthalmanna and status:1 updated by: Admin','2025-06-28 01:29:43','2025-06-28 01:29:43'),(271,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 09:33:52','2025-06-28 09:33:52'),(272,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 09:34:45','2025-06-28 09:34:45'),(273,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 09:35:00','2025-06-28 09:35:00'),(274,1,'clinic Prescription updated','clinic address:perinthalmanna and status:3 updated by: Admin','2025-06-28 09:35:22','2025-06-28 09:35:22'),(275,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-06-28 09:35:39','2025-06-28 09:35:39'),(276,1,'clinic Prescription updated','clinic address:perinthalmanna and status:4 updated by: Admin','2025-06-28 09:35:59','2025-06-28 09:35:59'),(277,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-04 09:02:47','2025-07-04 09:02:47'),(278,1,'clinic Prescription updated','clinic address:sulthan batheri and status:1 updated by: Admin','2025-07-04 09:03:01','2025-07-04 09:03:01'),(279,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-04 09:03:12','2025-07-04 09:03:12'),(280,1,'clinic Prescription updated','clinic address:sulthan batheri and status:2 updated by: Admin','2025-07-04 09:03:22','2025-07-04 09:03:22'),(281,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-04 09:03:37','2025-07-04 09:03:37'),(282,1,'clinic Prescription updated','clinic address:sulthan batheri and status:3 updated by: Admin','2025-07-04 09:03:44','2025-07-04 09:03:44'),(283,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-04 09:03:56','2025-07-04 09:03:56'),(284,1,'clinic Prescription updated','clinic address:sulthan batheri and status:4 updated by: Admin','2025-07-04 09:04:13','2025-07-04 09:04:13'),(285,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-04 09:04:40','2025-07-04 09:04:40'),(286,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 09:46:58','2025-07-05 09:46:58'),(287,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 09:47:40','2025-07-05 09:47:40'),(288,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 09:57:36','2025-07-05 09:57:36'),(289,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:07:45','2025-07-05 10:07:45'),(290,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:08:30','2025-07-05 10:08:30'),(291,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:08:46','2025-07-05 10:08:46'),(292,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:10:04','2025-07-05 10:10:04'),(293,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:11:18','2025-07-05 10:11:18'),(294,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:44:43','2025-07-05 10:44:43'),(295,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:45:35','2025-07-05 10:45:35'),(296,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:45:50','2025-07-05 10:45:50'),(297,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:48:46','2025-07-05 10:48:46'),(298,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:49:14','2025-07-05 10:49:14'),(299,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:50:19','2025-07-05 10:50:19'),(300,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:50:37','2025-07-05 10:50:37'),(301,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:50:44','2025-07-05 10:50:44'),(302,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:51:39','2025-07-05 10:51:39'),(303,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:52:00','2025-07-05 10:52:00'),(304,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:52:20','2025-07-05 10:52:20'),(305,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:53:22','2025-07-05 10:53:22'),(306,1,'clinic Prescription updated','clinic address:perinthalmanna and status:1 updated by: Admin','2025-07-05 10:53:39','2025-07-05 10:53:39'),(307,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-05 10:54:08','2025-07-05 10:54:08'),(308,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 05:03:46','2025-07-07 05:03:46'),(309,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 06:01:59','2025-07-07 06:01:59'),(310,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 06:10:49','2025-07-07 06:10:49'),(311,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 06:11:07','2025-07-07 06:11:07'),(312,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 06:12:08','2025-07-07 06:12:08'),(313,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-07 06:32:26','2025-07-07 06:32:26'),(314,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 04:11:40','2025-07-18 04:11:40'),(315,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:07:38','2025-07-18 10:07:38'),(316,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:07:58','2025-07-18 10:07:58'),(317,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:08:23','2025-07-18 10:08:23'),(318,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:08:56','2025-07-18 10:08:56'),(319,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:09:09','2025-07-18 10:09:09'),(320,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:10:49','2025-07-18 10:10:49'),(321,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:11:25','2025-07-18 10:11:25'),(322,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:12:40','2025-07-18 10:12:40'),(323,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:15:52','2025-07-18 10:15:52'),(324,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:16:37','2025-07-18 10:16:37'),(325,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:17:22','2025-07-18 10:17:22'),(326,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:20:03','2025-07-18 10:20:03'),(327,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:24:58','2025-07-18 10:24:58'),(328,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:26:37','2025-07-18 10:26:37'),(329,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:31:51','2025-07-18 10:31:51'),(330,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:32:28','2025-07-18 10:32:28'),(331,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 10:33:03','2025-07-18 10:33:03'),(332,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:38:20','2025-07-18 10:38:20'),(333,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:38:41','2025-07-18 10:38:41'),(334,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:42:03','2025-07-18 10:42:03'),(335,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:44:37','2025-07-18 10:44:37'),(336,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:47:21','2025-07-18 10:47:21'),(337,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 10:47:35','2025-07-18 10:47:35'),(338,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:40:18','2025-07-18 11:40:18'),(339,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-18 11:42:41','2025-07-18 11:42:41'),(340,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:44:48','2025-07-18 11:44:48'),(341,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:44:55','2025-07-18 11:44:55'),(342,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:45:05','2025-07-18 11:45:05'),(343,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:45:20','2025-07-18 11:45:20'),(344,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:45:42','2025-07-18 11:45:42'),(345,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 11:47:24','2025-07-18 11:47:24'),(346,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-18 11:55:22','2025-07-18 11:55:22'),(347,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:03:54','2025-07-18 12:03:54'),(348,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:04:03','2025-07-18 12:04:03'),(349,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:04:55','2025-07-18 12:04:55'),(350,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:05:01','2025-07-18 12:05:01'),(351,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:08:53','2025-07-18 12:08:53'),(352,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:09:21','2025-07-18 12:09:21'),(353,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:09:38','2025-07-18 12:09:38'),(354,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:10:12','2025-07-18 12:10:12'),(355,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:15:04','2025-07-18 12:15:04'),(356,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:15:17','2025-07-18 12:15:17'),(357,1,'Payment is done','Pharmacy Prescription Payment is created by: Admin','2025-07-18 12:16:05','2025-07-18 12:16:05'),(358,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-18 12:16:35','2025-07-18 12:16:35'),(359,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 04:36:14','2025-07-19 04:36:14'),(360,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 04:36:22','2025-07-19 04:36:22'),(361,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 04:38:38','2025-07-19 04:38:38'),(362,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 04:44:13','2025-07-19 04:44:13'),(363,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:03:38','2025-07-19 05:03:38'),(364,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:15:54','2025-07-19 05:15:54'),(365,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:16:50','2025-07-19 05:16:50'),(366,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:17:01','2025-07-19 05:17:01'),(367,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:17:13','2025-07-19 05:17:13'),(368,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:24:19','2025-07-19 05:24:19'),(369,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-19 05:27:07','2025-07-19 05:27:07'),(370,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-19 05:28:56','2025-07-19 05:28:56'),(371,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-07-19 05:29:07','2025-07-19 05:29:07'),(372,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-07-19 05:29:17','2025-07-19 05:29:17'),(373,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-19 05:29:26','2025-07-19 05:29:26'),(374,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-19 06:08:49','2025-07-19 06:08:49'),(375,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 03:35:59','2025-07-21 03:35:59'),(376,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:17:58','2025-07-21 04:17:58'),(377,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:19:18','2025-07-21 04:19:18'),(378,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:22:21','2025-07-21 04:22:21'),(379,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:28:09','2025-07-21 04:28:09'),(380,1,'clinic Prescription updated','clinic address:London and status:1 updated by: Admin','2025-07-21 04:28:44','2025-07-21 04:28:44'),(381,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:28:52','2025-07-21 04:28:52'),(382,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:29:26','2025-07-21 04:29:26'),(383,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:29:49','2025-07-21 04:29:49'),(384,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:30:21','2025-07-21 04:30:21'),(385,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:32:49','2025-07-21 04:32:49'),(386,1,'clinic Prescription updated','clinic address:perinthalmanna and status:1 updated by: Admin','2025-07-21 04:32:57','2025-07-21 04:32:57'),(387,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:33:01','2025-07-21 04:33:01'),(388,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-07-21 04:33:08','2025-07-21 04:33:08'),(389,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:33:15','2025-07-21 04:33:15'),(390,1,'clinic Prescription updated','clinic address:sulthan batheri and status:1 updated by: Admin','2025-07-21 04:33:18','2025-07-21 04:33:18'),(391,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:33:23','2025-07-21 04:33:23'),(392,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:33:48','2025-07-21 04:33:48'),(393,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:35:27','2025-07-21 04:35:27'),(394,1,'clinic Prescription updated','clinic address:vengara and status:1 updated by: Admin','2025-07-21 04:35:31','2025-07-21 04:35:31'),(395,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:35:36','2025-07-21 04:35:36'),(396,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:38:31','2025-07-21 04:38:31'),(397,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:38:44','2025-07-21 04:38:44'),(398,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:40:11','2025-07-21 04:40:11'),(399,1,'clinic Prescription updated','clinic address:areekode and status:1 updated by: Admin','2025-07-21 04:40:18','2025-07-21 04:40:18'),(400,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:41:21','2025-07-21 04:41:21'),(401,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:42:37','2025-07-21 04:42:37'),(402,1,'clinic Prescription updated','clinic address:malappuram and status:1 updated by: Admin','2025-07-21 04:42:47','2025-07-21 04:42:47'),(403,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:42:54','2025-07-21 04:42:54'),(404,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:43:04','2025-07-21 04:43:04'),(405,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:43:55','2025-07-21 04:43:55'),(406,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:43:58','2025-07-21 04:43:58'),(407,1,'clinic Prescription updated','clinic address:malappuram and status:3 updated by: Admin','2025-07-21 04:44:03','2025-07-21 04:44:03'),(408,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:44:21','2025-07-21 04:44:21'),(409,1,'clinic Prescription updated','clinic address:malappuram and status:4 updated by: Admin','2025-07-21 04:44:49','2025-07-21 04:44:49'),(410,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:44:56','2025-07-21 04:44:56'),(411,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:46:34','2025-07-21 04:46:34'),(412,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:46:44','2025-07-21 04:46:44'),(413,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:46:52','2025-07-21 04:46:52'),(414,1,'clinic Prescription updated','clinic address:sulthan batheri and status:1 updated by: Admin','2025-07-21 04:46:56','2025-07-21 04:46:56'),(415,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:47:06','2025-07-21 04:47:06'),(416,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:47:14','2025-07-21 04:47:14'),(417,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:47:21','2025-07-21 04:47:21'),(418,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:47:31','2025-07-21 04:47:31'),(419,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:53:04','2025-07-21 04:53:04'),(420,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:54:02','2025-07-21 04:54:02'),(421,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:54:09','2025-07-21 04:54:09'),(422,1,'clinic Prescription updated','clinic address:malappuram and status:1 updated by: Admin','2025-07-21 04:54:14','2025-07-21 04:54:14'),(423,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 04:54:18','2025-07-21 04:54:18'),(424,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 04:55:13','2025-07-21 04:55:13'),(425,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 04:57:35','2025-07-21 04:57:35'),(426,1,'User updated','User: Das , user Id: 33 , User updated by Admin','2025-07-21 05:04:12','2025-07-21 05:04:12'),(427,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 05:07:22','2025-07-21 05:07:22'),(428,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 05:13:08','2025-07-21 05:13:08'),(429,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 05:13:20','2025-07-21 05:13:20'),(430,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 05:13:38','2025-07-21 05:13:38'),(431,1,'clinic Prescription updated','clinic address:kunja and status:3 updated by: Admin','2025-07-21 05:13:42','2025-07-21 05:13:42'),(432,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-21 05:13:46','2025-07-21 05:13:46'),(433,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 05:45:36','2025-07-21 05:45:36'),(434,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 05:46:32','2025-07-21 05:46:32'),(435,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 09:22:27','2025-07-21 09:22:27'),(436,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 09:25:23','2025-07-21 09:25:23'),(437,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 12:21:43','2025-07-21 12:21:43'),(438,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 12:22:44','2025-07-21 12:22:44'),(439,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-21 13:00:20','2025-07-21 13:00:20'),(440,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 05:29:30','2025-07-22 05:29:30'),(441,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 05:43:06','2025-07-22 05:43:06'),(442,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 05:52:38','2025-07-22 05:52:38'),(443,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 06:27:09','2025-07-22 06:27:09'),(444,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 07:03:19','2025-07-22 07:03:19'),(445,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 08:12:51','2025-07-22 08:12:51'),(446,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-22 08:13:20','2025-07-22 08:13:20'),(447,1,'clinic Prescription updated','clinic address:malappuram and status:1 updated by: Admin','2025-07-22 08:13:28','2025-07-22 08:13:28'),(448,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-07-22 08:46:24','2025-07-22 08:46:24'),(449,1,'clinic Prescription updated','clinic address:123 Main Street, Apt 4B \r\nAnytown, CA 91234-5678\r\nUnited States of America and status:1 updated by: Admin','2025-07-22 08:46:35','2025-07-22 08:46:35'),(450,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 08:54:05','2025-07-22 08:54:05'),(451,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 08:54:15','2025-07-22 08:54:15'),(452,1,'New User Created','New User: Niv Usercreated by Admin','2025-07-22 10:18:54','2025-07-22 10:18:54'),(453,1,'New User Created','New User: Niv Deliverycreated by Admin','2025-07-22 10:20:49','2025-07-22 10:20:49'),(454,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 10:36:34','2025-07-22 10:36:34'),(455,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-22 10:38:00','2025-07-22 10:38:00'),(456,1,'clinic Prescription Processed','clinic Prescription user:Niv User processed by: Admin','2025-07-22 10:57:44','2025-07-22 10:57:44'),(457,1,'clinic Prescription updated','clinic address:Ramanattukara and status:1 updated by: Admin','2025-07-22 10:57:53','2025-07-22 10:57:53'),(458,1,'clinic Prescription Processed','clinic Prescription user:Niv User processed by: Admin','2025-07-22 10:58:28','2025-07-22 10:58:28'),(459,1,'clinic Prescription updated','clinic address:Ramanattukara and status:3 updated by: Admin','2025-07-22 10:58:35','2025-07-22 10:58:35'),(460,1,'clinic Prescription Processed','clinic Prescription user:Niv User processed by: Admin','2025-07-22 10:58:43','2025-07-22 10:58:43'),(461,1,'clinic Prescription updated','clinic address:Ramanattukara and status:4 updated by: Admin','2025-07-22 10:58:51','2025-07-22 10:58:51'),(462,1,'clinic Prescription Processed','clinic Prescription user:Customer processed by: Admin','2025-07-22 10:59:40','2025-07-22 10:59:40'),(463,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-07-25 06:09:38','2025-07-25 06:09:38'),(464,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 02:49:07','2025-08-04 02:49:07'),(465,1,'clinic Prescription updated','clinic address:areekode and status:1 updated by: Admin','2025-08-04 02:49:17','2025-08-04 02:49:17'),(466,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 02:50:29','2025-08-04 02:50:29'),(467,1,'clinic Prescription updated','clinic address:areekode and status:3 updated by: Admin','2025-08-04 02:50:36','2025-08-04 02:50:36'),(468,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 02:50:59','2025-08-04 02:50:59'),(469,1,'clinic Prescription updated','clinic address:areekode and status:4 updated by: Admin','2025-08-04 02:51:14','2025-08-04 02:51:14'),(470,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-08-04 02:53:59','2025-08-04 02:53:59'),(471,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-08-04 02:55:12','2025-08-04 02:55:12'),(472,1,'Pharmacy created','Pharmacy: Sudharma created by Admin','2025-08-04 03:05:27','2025-08-04 03:05:27'),(473,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:14:59','2025-08-04 03:14:59'),(474,1,'clinic Prescription updated','clinic address:areekode and status:1 updated by: Admin','2025-08-04 03:15:04','2025-08-04 03:15:04'),(475,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:18:06','2025-08-04 03:18:06'),(476,1,'clinic Prescription updated','clinic address:areekode and status:3 updated by: Admin','2025-08-04 03:18:09','2025-08-04 03:18:09'),(477,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:18:19','2025-08-04 03:18:19'),(478,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:35:17','2025-08-04 03:35:17'),(479,1,'clinic Prescription updated','clinic address:africa and status:1 updated by: Admin','2025-08-04 03:35:24','2025-08-04 03:35:24'),(480,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:36:17','2025-08-04 03:36:17'),(481,1,'clinic Prescription updated','clinic address:africa and status:3 updated by: Admin','2025-08-04 03:36:19','2025-08-04 03:36:19'),(482,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:36:30','2025-08-04 03:36:30'),(483,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:36:56','2025-08-04 03:36:56'),(484,1,'clinic Prescription updated','clinic address:los angelous and status:1 updated by: Admin','2025-08-04 03:37:02','2025-08-04 03:37:02'),(485,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:37:30','2025-08-04 03:37:30'),(486,1,'clinic Prescription updated','clinic address:los angelous and status:3 updated by: Admin','2025-08-04 03:37:35','2025-08-04 03:37:35'),(487,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:40:46','2025-08-04 03:40:46'),(488,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:46:10','2025-08-04 03:46:10'),(489,1,'clinic Prescription updated','clinic address:areekode and status:1 updated by: Admin','2025-08-04 03:46:17','2025-08-04 03:46:17'),(490,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:46:48','2025-08-04 03:46:48'),(491,1,'clinic Prescription updated','clinic address:areekode and status:3 updated by: Admin','2025-08-04 03:46:51','2025-08-04 03:46:51'),(492,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:47:37','2025-08-04 03:47:37'),(493,1,'clinic Prescription updated','clinic address:areekode and status:4 updated by: Admin','2025-08-04 03:47:51','2025-08-04 03:47:51'),(494,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-08-04 03:49:01','2025-08-04 03:49:01'),(495,1,'clinic Prescription Processed','clinic Prescription user:Admin processed by: Admin','2025-08-04 03:49:25','2025-08-04 03:49:25'),(496,1,'clinic Prescription updated','clinic address:areekode and status:4 updated by: Admin','2025-08-04 03:49:37','2025-08-04 03:49:37'),(497,1,'New User Created','New User: Jafarcreated by Admin','2025-08-11 05:16:32','2025-08-11 05:16:32'),(498,1,'New User Created','New User: Mishalcreated by Admin','2025-08-11 05:18:35','2025-08-11 05:18:35'),(499,1,'New User Created','New User: udithcreated by Admin','2025-08-11 05:20:00','2025-08-11 05:20:00'),(500,1,'User Deleted','User: nandana , user Id: 39 , User deleted by Admin','2025-08-11 08:49:24','2025-08-11 08:49:24'),(501,1,'User Deleted','User: pharamcy user , user Id: 25 , User deleted by Admin','2025-08-11 08:49:43','2025-08-11 08:49:43'),(502,1,'User Deleted','User: Test user , user Id: 31 , User deleted by Admin','2025-08-11 08:49:47','2025-08-11 08:49:47'),(503,1,'User Deleted','User: Niv User , user Id: 34 , User deleted by Admin','2025-08-11 08:49:53','2025-08-11 08:49:53'),(504,1,'User Deleted','User: Niv Delivery , user Id: 35 , User deleted by Admin','2025-08-11 08:49:58','2025-08-11 08:49:58'),(505,1,'User Deleted','User: jafar , user Id: 30 , User deleted by Admin','2025-08-11 08:50:11','2025-08-11 08:50:11'),(506,1,'User Deleted','User: delivery , user Id: 26 , User deleted by Admin','2025-08-11 08:50:20','2025-08-11 08:50:20'),(507,1,'User Deleted','User: Customer , user Id: 24 , User deleted by Admin','2025-08-11 08:50:52','2025-08-11 08:50:52'),(508,1,'Payment is done','Pharmacy Prescription Payment iscreated by: Admin','2025-08-11 11:21:46','2025-08-11 11:21:46'),(509,1,'clinic Prescription Processed','clinic Prescription user:Mishal processed by: Admin','2025-08-12 04:02:57','2025-08-12 04:02:57'),(510,1,'clinic Prescription updated','clinic address:aikkarappadi and status:1 updated by: Admin','2025-08-12 04:03:06','2025-08-12 04:03:06'),(511,1,'User updated','User: Das , user Id: 33 , User updated by Admin','2025-08-12 05:07:07','2025-08-12 05:07:07'),(512,1,'clinic Prescription Processed','clinic Prescription user:Mishal processed by: Admin','2025-08-12 05:36:10','2025-08-12 05:36:10'),(513,1,'clinic Prescription updated','clinic address:vengara and status:1 updated by: Admin','2025-08-12 05:36:16','2025-08-12 05:36:16'),(514,1,'User updated','User: Admin , user Id: 1 , User updated by Admin','2025-08-14 06:49:29','2025-08-14 06:49:29'),(515,1,'User Deleted','User: nandana , user Id: 40 , User deleted by Admin','2025-08-14 09:38:50','2025-08-14 09:38:50'),(516,1,'User Deleted','User: nandana , user Id: 41 , User deleted by Admin','2025-08-14 09:42:50','2025-08-14 09:42:50'),(517,1,'User Deleted','User: udith , user Id: 38 , User deleted by Admin','2025-08-14 09:50:46','2025-08-14 09:50:46'),(518,1,'User Deleted','User: usith , user Id: 42 , User deleted by Admin','2025-08-14 09:55:11','2025-08-14 09:55:11'),(519,1,'Pharmacy created','Pharmacy: Pharamcy late updated by Admin','2025-08-16 10:16:51','2025-08-16 10:16:51'),(520,1,'Pharmacy created','Pharmacy: Sudharmaa updated by Admin','2025-08-16 10:17:27','2025-08-16 10:17:27'),(521,1,'Pharmacy created','Pharmacy: pharamcy4477 updated by Admin','2025-08-16 10:18:00','2025-08-16 10:18:00'),(522,1,'Pharmacy created','Pharmacy: Pharmacy1 updated by Admin','2025-08-16 10:18:13','2025-08-16 10:18:13'),(523,1,'Pharmacy created','Pharmacy: pharamcy4477 updated by Admin','2025-08-16 10:20:18','2025-08-16 10:20:18'),(524,1,'Pharmacy created','Pharmacy: Pharamcy late updated by Admin','2025-08-16 10:21:57','2025-08-16 10:21:57'),(525,1,'Pharmacy created','Pharmacy: Pharamcy late updated by Admin','2025-08-16 10:22:52','2025-08-16 10:22:52'),(526,1,'Pharmacy created','Pharmacy: Pharmacy1 updated by Admin','2025-08-16 10:23:18','2025-08-16 10:23:18'),(527,1,'Pharmacy created','Pharmacy: Sudharmaa updated by Admin','2025-08-16 10:23:40','2025-08-16 10:23:40'),(528,1,'clinic created','clinic: Fathimas created by Admin','2025-08-16 12:39:31','2025-08-16 12:39:31'),(529,1,'Pharmacy created','Pharmacy: pharamcy88 created by Admin','2025-08-18 07:05:48','2025-08-18 07:05:48'),(530,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:06:48','2025-08-18 07:06:48'),(531,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:07:50','2025-08-18 07:07:50'),(532,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:08:23','2025-08-18 07:08:23'),(533,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:08:24','2025-08-18 07:08:24'),(534,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:08:57','2025-08-18 07:08:57'),(535,1,'Pharmacy created','Pharmacy: pharamcy88 updated by Admin','2025-08-18 07:09:07','2025-08-18 07:09:07'),(536,1,'Pharmacy created','Pharmacy: pharamcy88 deleted by Admin','2025-08-19 10:24:53','2025-08-19 10:24:53'),(537,1,'Pharmacy created','Pharmacy: pharamcy4477 deleted by Admin','2025-08-19 10:24:59','2025-08-19 10:24:59'),(538,1,'clinic Deleted','Clinic: Fathimas deleted by: Admin','2025-08-19 10:27:27','2025-08-19 10:27:27'),(539,1,'clinic Deleted','Clinic: Clinics1 deleted by: Admin','2025-08-19 10:27:30','2025-08-19 10:27:30'),(540,1,'Pharmacy created','Pharmacy: Sudharmaa deleted by Admin','2025-08-20 05:35:08','2025-08-20 05:35:08'),(541,1,'Pharmacy created','Pharmacy: Pharmacy1 deleted by Admin','2025-08-20 05:35:15','2025-08-20 05:35:15'),(542,1,'clinic created','clinic: Neethi Lab created by Admin','2025-08-20 09:18:37','2025-08-20 09:18:37'),(543,1,'Pharmacy created','Pharmacy: Pharamcy late deleted by Admin','2025-08-20 10:03:48','2025-08-20 10:03:48'),(544,1,'Pharmacy created','Pharmacy: Pharmacy1 deleted by Admin','2025-08-20 10:03:52','2025-08-20 10:03:52'),(545,1,'Pharmacy created','Pharmacy: Sudharmaa deleted by Admin','2025-08-20 10:03:55','2025-08-20 10:03:55'),(546,1,'Pharmacy created','Pharmacy: Neethi Pharmacy created by Admin','2025-08-20 10:12:45','2025-08-20 10:12:45'),(547,1,'User updated','User: Das , user Id: 33 , User updated by Admin','2025-08-21 11:43:45','2025-08-21 11:43:45'),(548,1,'User Deleted','User: Mishal , user Id: 37 , User deleted by Admin','2025-08-22 04:46:13','2025-08-22 04:46:13'),(549,1,'clinic created','clinic: test clcincs created by Admin','2025-09-08 09:01:36','2025-09-08 09:01:36'),(550,1,'clinic Deleted','Clinic: test clcincs deleted by: Admin','2025-09-08 09:02:14','2025-09-08 09:02:14'),(551,1,'Pharmacy Pescription Address Updated','Pharmacy Pescription Address Updated: rgg wwrtewy Sibbycreated by Admin','2025-09-08 19:29:04','2025-09-08 19:29:04'),(552,1,'User updated','User: Shibil Das , user Id: 45 , User updated by Admin','2025-09-09 04:06:42','2025-09-09 04:06:42'),(553,1,'Pharmacy Pescription Address Updated','Pharmacy Pescription Address Updated: rghcreated by Admin','2025-09-09 04:12:25','2025-09-09 04:12:25'),(554,1,'Pharmacy Pescription Address Updated','Pharmacy Pescription Address Updated: kondottycreated by Admin','2025-09-09 04:12:41','2025-09-09 04:12:41');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicines`
--

DROP TABLE IF EXISTS `medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacy_id` bigint unsigned DEFAULT NULL,
  `medicine_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `expiry_date` date DEFAULT NULL,
  `manufacturer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `medicines_pharmacy_id_foreign` (`pharmacy_id`),
  CONSTRAINT `medicines_pharmacy_id_foreign` FOREIGN KEY (`pharmacy_id`) REFERENCES `pharmacies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4072 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicines`
--

LOCK TABLES `medicines` WRITE;
/*!40000 ALTER TABLE `medicines` DISABLE KEYS */;
INSERT INTO `medicines` VALUES (4052,5,'Amaryl Tab. 2mg',7.00,98,'4NG007','2026-12-01','AVENTI','2025-06-04 23:34:28','2025-06-04 23:34:28',NULL),(4053,5,'AB DAY SR 200 TAB',17.00,30,'LGN0110801','2025-12-31','ISIS','2025-06-04 23:35:51','2025-06-04 23:35:51',NULL),(4054,5,'Abendol Tab',35.00,7,'K3GKX005','2025-10-31','LEEFORD','2025-06-04 23:37:04','2025-06-04 23:37:04',NULL),(4055,5,'ABLUNG N TAB',16.00,45,'AFB24756','2025-11-27','CIP','2025-06-04 23:38:19','2025-06-04 23:38:19',NULL),(4056,5,'Aimet XR 50MG',6.00,110,'229TAF006','2025-09-30','ISIS','2025-06-04 23:40:39','2025-06-04 23:40:39',NULL),(4057,5,'ALERID 60 ML',45.00,1,'A330633','2025-12-31','CIPLA','2025-06-04 23:42:03','2025-06-04 23:42:03',NULL),(4058,5,'Alprax Tab. 0.25mg',3.00,70,'2E09L011','2025-09-15','TORRENT','2025-06-04 23:43:25','2025-06-04 23:43:25',NULL),(4059,5,'ALZIL M FORTE',24.00,20,'K2401662','2025-09-25','INTASP','2025-06-04 23:44:53','2025-06-04 23:44:53',NULL),(4060,5,'AMIDE 200MG',30.00,7,'MT23-491','2025-06-30','ICON','2025-06-04 23:46:00','2025-06-04 23:46:00',NULL),(4061,5,'Amlodac Tab 5mg',3.00,270,'I401521','2025-10-05','ZYDUS','2025-06-04 23:47:21','2025-06-04 23:47:21',NULL),(4062,5,'Allercet 10 Tab',5.00,60,'S0025','2025-10-31','BROWN','2025-06-05 00:39:16','2025-06-05 00:39:16',NULL),(4063,5,'ALZIL M FORTE',25.00,20,'K2401662','2025-07-31','INTASP','2025-06-05 00:40:51','2025-06-05 00:40:51',NULL),(4064,5,'Amlovas 5 Tab',3.00,62,'240494A','2025-09-25','MACLEO','2025-06-05 00:42:01','2025-06-05 00:42:01',NULL),(4065,5,'Aquasoft Cream 60GM',239.00,1,'G3422','2025-09-30','AJANTA','2025-06-05 00:43:20','2025-06-05 00:43:20',NULL),(4066,5,'Argin Plus',99.00,15,'3G01','2025-11-25','FOURTS','2025-06-05 00:44:16','2025-06-05 00:44:16',NULL),(4067,5,'Asthakind Tab',5.00,91,'A1ALX002','2025-09-30','MANKIND','2025-06-05 00:45:24','2025-06-05 00:45:24',NULL),(4068,5,'Atarax Drops 15ml',84.00,1,'AT4018','2025-11-30','UCB','2025-06-05 00:46:20','2025-06-05 00:46:20',NULL),(4069,5,'Azibest Tab. 500mg',25.00,14,'AZF2330','2025-10-31','BLUCR','2025-06-05 00:47:59','2025-06-05 00:47:59',NULL),(4070,5,'Wakfree Tab',771.00,3,'WOL465E','2025-10-19','AKESISS','2025-06-05 01:00:50','2025-06-05 01:00:50',NULL),(4071,5,'Welvida 50',9.00,74,'BD240241C','2025-09-30','ISIS','2025-06-05 01:02:06','2025-06-05 01:02:06',NULL);
/*!40000 ALTER TABLE `medicines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (37,'2014_10_12_000000_create_users_table',1),(38,'2014_10_12_100000_create_password_reset_tokens_table',1),(39,'2014_10_12_100000_create_password_resets_table',1),(40,'2016_06_01_000001_create_oauth_auth_codes_table',1),(41,'2016_06_01_000002_create_oauth_access_tokens_table',1),(42,'2016_06_01_000003_create_oauth_refresh_tokens_table',1),(43,'2016_06_01_000004_create_oauth_clients_table',1),(44,'2016_06_01_000005_create_oauth_personal_access_clients_table',1),(45,'2019_08_19_000000_create_failed_jobs_table',1),(46,'2019_12_14_000001_create_personal_access_tokens_table',1),(47,'2025_02_07_042954_alter_users_table_add_patient_fields',1),(48,'2025_02_07_104730_create_clinics_table',1),(49,'2025_02_08_062242_create_pharmacies_table',1),(50,'2025_02_08_070424_create_pharmacy_prescriptions_table',1),(51,'2025_02_08_103055_create_pharmacy_medicines_table',1),(52,'2025_02_10_071122_create_clinic_prescriptions_table',1),(55,'2025_02_10_102644_create_medicines_table',2),(57,'2025_02_13_071019_add_time_fields_to_pharmacy_medicines_table',3),(58,'2025_02_13_103759_add_tests_to_clinics_table',4),(59,'2025_02_14_090608_add_clinic_photo_to_clinics_table',5),(60,'2025_02_15_0145678_add_pharmacies_photo_to_clinics_table',6),(62,'2025_02_15_112649_add_role_to_users_table',7),(63,'2025_02_19_000001_add_pharmacy_id_medicines_table',8),(64,'2025_02_20_071019_add_status_fields_to_pharmacy_medicines_table',8),(65,'2025_02_20_071020_add_status_pharmacy_prescriptions_table',8),(66,'2025_02_20_071021_add_status_to_clinic_prescriptions_table',8),(67,'2025_02_21_064009_create_logs_table',8),(68,'2025_04_30_070141_add_user_type_to_users_table',9),(69,'2025_04_30_101538_create_delivery_agents_table',9),(70,'2025_05_02_040943_add_delivery_status_to_delivery_agents_table',9),(71,'2025_05_03_000001_add_reffrnce_pharmacy_medicines_table ',9),(72,'2025_05_12_062600_create_payments_table',10),(73,'2025_05_13_040943_add_pres_id_to_delivery_agents_table',11),(75,'2025_05_19_062600_add_ref_no _to_payments_table',12),(76,'2025_08_18_142000_add_deleted_at_to_pharmacies_table',13);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('048e7641e366ee1066a59643972862cd995f5ee80e2b3e3cbc0c3718ab36648ca1627997e8e1f66a',33,1,'appToken','[]',0,'2025-09-09 03:26:36','2025-09-09 03:26:36','2026-09-09 08:56:36'),('0ef308530d2effb5b1d525d15def24412374eeb97cd6569c7f39df2015d4b4b89b9a40cabb719d40',33,1,'appToken','[]',0,'2025-08-04 03:08:50','2025-08-04 03:08:50','2026-08-04 08:38:50'),('10d18d8252e1e9ce9d7b61cd443790a9302ec049cb7984097b36680d900da059359a6164eb764e66',46,1,'appToken','[]',0,'2025-09-09 07:32:57','2025-09-09 07:32:57','2026-09-09 13:02:57'),('14071eb631de7ed81aa1b81dc1315f2802dfaa4827d4aab8e85cf47115e541364d21a608d0903b8d',33,1,'appToken','[]',0,'2025-07-23 07:30:53','2025-07-23 07:30:53','2026-07-23 13:00:53'),('19afaef1c506afd889742930d36ef9f810c8a5b131b4005802f5c5dc7d7b73faef67a45fa37a43cb',33,1,'appToken','[]',0,'2025-09-08 10:59:00','2025-09-08 10:59:01','2026-09-08 16:29:00'),('1dec8f8712243d41d4dd21f1dea187b6c10bd692835cbf935ab3eb929d518b1a1faf2dee7e61f2bc',33,1,'appToken','[]',0,'2025-06-26 23:43:45','2025-06-26 23:43:45','2026-06-27 05:13:45'),('21253a1068ccf2cc9e13f845a615dcb1a625a37feba6f7136b7f51e31b3a06fb94709dc7f7d02198',23,1,'appToken','[]',0,'2025-06-04 04:07:08','2025-06-04 04:07:08','2026-06-04 09:37:08'),('3ef0281a04c13e6685cf0db83d510ac6f1a772749939f82eb95bbf5d195a700c632fb51f790d7ae3',47,1,'appToken','[]',0,'2025-09-09 07:35:01','2025-09-09 07:35:02','2026-09-09 13:05:01'),('3f13f8bf8647cd595439269edbae0cf8d4c32cdfc750116b2ff2d8ae0e41d2e61eb7fc5ca6961bdd',33,1,'appToken','[]',0,'2025-08-24 10:00:09','2025-08-24 10:00:10','2026-08-24 15:30:09'),('431e75c9cfd90945e9c5981b4be00290cbd78606548c91cf41e1587efc4ea97c540f22a0ea7b7a03',50,1,'appToken','[]',0,'2025-09-09 07:36:45','2025-09-09 07:36:45','2026-09-09 13:06:45'),('4b08c863264f3fb8660c3cf114985adea58e7edc80309b515ab63461288a4d07b9b730e7da0c1371',33,1,'appToken','[]',0,'2025-08-12 05:26:58','2025-08-12 05:26:59','2026-08-12 10:56:58'),('4f4ffd5f05e7f54a9f25e582e8a2c1c6dfde46a932eab6c2e7723491a3ef042638fbf3eda5d7c971',33,1,'appToken','[]',0,'2025-08-23 03:15:44','2025-08-23 03:15:44','2026-08-23 08:45:44'),('4fbb43954342302cbe7c26d25b2c1649766f086b7f51d17498a807a0e4cbcff80c5c9a269e69a195',33,1,'appToken','[]',0,'2025-06-27 03:32:38','2025-06-27 03:32:38','2026-06-27 09:02:38'),('59bd8f303e686ba245120c00379597907901ed82d13ca924619e36205368b9e6fcfdc3eb56fd7c57',33,1,'appToken','[]',0,'2025-08-12 05:26:20','2025-08-12 05:26:20','2026-08-12 10:56:20'),('70a913c612b736085c0280608a01c6113eb4189ffd685d4beecce69aa742511d847a9b232e863f08',33,1,'appToken','[]',0,'2025-08-04 03:03:21','2025-08-04 03:03:21','2026-08-04 08:33:21'),('710dbb80c34f855cd99d738e6864ba13db92f8320364685b09e3a3435f3008ec14792976c1da8f2a',51,1,'appToken','[]',0,'2025-09-09 07:37:30','2025-09-09 07:37:30','2026-09-09 13:07:30'),('72691d42556fea0d9a07b5e7d9fd1c13b99709c66b2c387dd1fe43df849e0861e2e46f346d3d2491',33,1,'appToken','[]',0,'2025-08-21 11:41:34','2025-08-21 11:41:35','2026-08-21 17:11:34'),('77f305f84608d4b98f76b915095d72f2a3e899f1beb12478c1d6379df6a64d34adff836d59afdbd6',44,1,'appToken','[]',0,'2025-09-06 06:54:21','2025-09-06 06:54:22','2026-09-06 12:24:21'),('7a0e7beafd733663ba303367ad07e6ba977261da5bcba17dc7fd40bfe09a3868b1422d9e620aa4cc',48,1,'appToken','[]',0,'2025-09-09 07:35:25','2025-09-09 07:35:25','2026-09-09 13:05:25'),('836b938b5c37bfe961bdf15e068690c7a4830735738f866c2b6c91fc340151a021bb476ffe4101c9',33,1,'appToken','[]',0,'2025-07-22 08:25:57','2025-07-22 08:25:57','2026-07-22 13:55:57'),('849f1a6008194acd6c55af88e27ee395e3956e82bb436290800fa967ecf694aee87ed20b08edcc34',33,1,'appToken','[]',0,'2025-08-24 11:49:44','2025-08-24 11:49:45','2026-08-24 17:19:44'),('85bdab56246febbd50137467cafced34887106e975cd769d51fbaf2c5135e0cb276f0c99e38619d0',49,1,'appToken','[]',0,'2025-09-09 07:35:09','2025-09-09 07:35:09','2026-09-09 13:05:09'),('87147e5b13ad4243b1d415d72eb3364dbc6d921720e449ca14a5fb7a955a9e61e7a67bda78fc32ea',33,1,'appToken','[]',0,'2025-07-21 05:07:20','2025-07-21 05:07:20','2026-07-21 10:37:20'),('8974f932d970dbbebf1ad2c6ab4d0dafad6b186318e6db6660f5e95c2308fda02c60c5cf71fb3183',33,1,'appToken','[]',0,'2025-07-23 06:26:08','2025-07-23 06:26:08','2026-07-23 11:56:08'),('a6bad84803362094a342c3c4f94bf413532ccdbf0b5956eb1648dfcf7966d71dc1c4ffe03ad4f286',33,1,'appToken','[]',0,'2025-08-24 12:52:29','2025-08-24 12:52:29','2026-08-24 18:22:29'),('b57d6a10dd22f09a07f283119fb67acaf39fe5dc128b148755e3e466ef12603e1901de2917337acf',33,1,'appToken','[]',0,'2025-08-11 04:24:17','2025-08-11 04:24:17','2026-08-11 09:54:17'),('bf4cb724988fd3b1dc31ebb94cffa3cd6efecf6138d3e068d810a2cd339254b29b85a3809c5ffe3c',33,1,'appToken','[]',0,'2025-08-24 11:58:17','2025-08-24 11:58:17','2026-08-24 17:28:17'),('c66c5f2b19584548fa78d1b7f57faf9ace723b25244595592cee56dc7415595e4ea16aaa97d7e19c',33,1,'appToken','[]',0,'2025-07-21 05:26:41','2025-07-21 05:26:41','2026-07-21 10:56:41'),('ce8170ec8689d1511a154bb485a04f4f467e8f48e6e53eba61690abdcc361bc8c818777fac942016',1,1,'appToken','[]',0,'2025-09-09 06:11:07','2025-09-09 06:11:07','2026-09-09 11:41:07'),('e614ea2fa3f6095d0b6b2c4934d9723aae32f57730030d0f536b4a6299b7846c91432417e87bc5e4',33,1,'appToken','[]',0,'2025-08-12 05:18:28','2025-08-12 05:18:28','2026-08-12 10:48:28');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'HEALTH APP Personal Access Client','12iC1YKBNiWUOGc2ECRzypN2madlzdEpGJ0ZTaAe',NULL,'http://localhost',1,0,0,'2025-02-10 04:20:22','2025-02-10 04:20:22'),(2,NULL,'HEALTH APP Password Grant Client','xSm9xgl89d0dBNQbkAF2SZzDDx5uhPHqATiEStNF','users','http://localhost',0,1,0,'2025-02-10 04:20:22','2025-02-10 04:20:22');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2025-02-10 04:20:22','2025-02-10 04:20:22');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('thomas@gmail.com','$2y$12$ARhY1XDM/ctAxqhT7kUh8ub1nCerZDyRDU3dlZIQNihsg5SrG9zgK','2025-02-15 06:30:29');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pres_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_no` text COLLATE utf8mb4_unicode_ci,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `trans_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accno` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_pres_id_foreign` (`pres_id`),
  CONSTRAINT `payments_pres_id_foreign` FOREIGN KEY (`pres_id`) REFERENCES `pharmacy_prescriptions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pharmacies`
--

DROP TABLE IF EXISTS `pharmacies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pharmacies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacy_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pharmacy_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pharmacy_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `types` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upi` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_code` varchar(450) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_holder_name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_no` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pharmacies_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pharmacies`
--

LOCK TABLES `pharmacies` WRITE;
/*!40000 ALTER TABLE `pharmacies` DISABLE KEYS */;
INSERT INTO `pharmacies` VALUES (5,'Pharmacy1','near railway','pharmacy_photo/sG7s7toBHmqRtQYcdwCq3eNSwybmDmMy7bcYY3tq.png','Kozhikode','7510895815','pharmacy786@gmail.com','2025-06-04 05:15:49','2025-08-20 10:03:52','1','7510895815@ybl','pharmacy_photo/Tbwna3lmZSJe8AZ5cY4GOwERC9T36hO5W0Gh5zCp.png',NULL,NULL,NULL,'2025-08-20 10:03:52'),(6,'Pharamcy late','ferkode,clt','pharmacy_photo/Q7NVwkmbGVpE8i5ih5BhZDAfvu9oLUljHpou9pyu.png','Kozhikode','8075056740','phrmcy2@gmail.com','2025-06-21 03:14:36','2025-08-20 10:03:48','1','sudarma@oksbi','pharmacy_photo/7NykYbhEA4KcIb1LppAaFwV8kKqU9cUpPGJ7YNoZ.png',NULL,NULL,NULL,'2025-08-20 10:03:48'),(8,'Sudharmaa','Areekode, near bus stand','pharmacy_photo/CLM9KleL9bhanx5R27l64stn1pxyCjWckpeaVCRq.png','Areekode','123456789','sudharma@gmail.com','2025-08-04 03:05:27','2025-08-20 10:03:55','1','sudarma@oksbi','pharmacy_photo/OFRfuEOez8JQ6wXNEjDmDQUtjFGDhH3KU1CznnCY.png',NULL,NULL,NULL,'2025-08-20 10:03:55'),(10,'Neethi Pharmacy','Pulikkal School Road in Areekode','pharmacy_photo/j70jRftDE8NVBPkPKiS48wykXjl4wvqdWToVWQhx.jpg','Areekode','9048007933','neethi@gmail.com','2025-08-20 10:12:45','2025-08-20 10:12:45','1','9876543210@okicici','pharmacy_photo/Kq90wJybsvVNPK3wV3Mugz5JAjqkb6RMxazPXH4D.png','Areekode Neethi Pharmacy','0987654321','CSBK0000489',NULL);
/*!40000 ALTER TABLE `pharmacies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pharmacy_medicines`
--

DROP TABLE IF EXISTS `pharmacy_medicines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pharmacy_medicines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pharmacy_prescription_id` bigint unsigned NOT NULL,
  `medicine_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time_1` time DEFAULT NULL,
  `end_time_1` time DEFAULT NULL,
  `start_time_2` time DEFAULT NULL,
  `end_time_2` time DEFAULT NULL,
  `start_time_3` time DEFAULT NULL,
  `end_time_3` time DEFAULT NULL,
  `req_unit` int DEFAULT NULL,
  `avail_unit` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `total` decimal(8,2) NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `reffrnce` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pharmacy_medicines_pharmacy_prescription_id_foreign` (`pharmacy_prescription_id`),
  CONSTRAINT `pharmacy_medicines_pharmacy_prescription_id_foreign` FOREIGN KEY (`pharmacy_prescription_id`) REFERENCES `pharmacy_prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pharmacy_medicines`
--

LOCK TABLES `pharmacy_medicines` WRITE;
/*!40000 ALTER TABLE `pharmacy_medicines` DISABLE KEYS */;
/*!40000 ALTER TABLE `pharmacy_medicines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pharmacy_prescriptions`
--

DROP TABLE IF EXISTS `pharmacy_prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pharmacy_prescriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `pharmacy_id` bigint unsigned NOT NULL,
  `prescription` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `delivery_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat_long` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_amount` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expect_date` date DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `delivery_coordinates` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `receipt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `confirm_payment` longtext COLLATE utf8mb4_unicode_ci,
  `payment_type` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pharmacy_prescriptions_user_id_foreign` (`user_id`),
  KEY `pharmacy_prescriptions_pharmacy_id_foreign` (`pharmacy_id`),
  CONSTRAINT `pharmacy_prescriptions_pharmacy_id_foreign` FOREIGN KEY (`pharmacy_id`) REFERENCES `pharmacies` (`id`),
  CONSTRAINT `pharmacy_prescriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `pharmacy_prescriptions_chk_1` CHECK (json_valid(`prescription`))
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pharmacy_prescriptions`
--

LOCK TABLES `pharmacy_prescriptions` WRITE;
/*!40000 ALTER TABLE `pharmacy_prescriptions` DISABLE KEYS */;
INSERT INTO `pharmacy_prescriptions` VALUES (158,'abhijith',1,10,'[\"prescriptions\\/zvSCe6lU8JeniTcYmFnOfsRLGFlHv51mmPAzglEJ.jpg\"]','kondotty','11.145756,75.9634341','1','1.0',NULL,'2025-09-08',1,NULL,'0000','2025-09-08 14:51:16','2025-09-08 14:52:18',NULL,'',NULL,NULL),(159,'nandana',1,10,'[\"prescriptions\\/RVOpSgx0mtd8AfkRREVJCCSr9P1ilT0iUfukjZsI.jpg\"]','vengara','11.1461045,75.9537338','1','1',NULL,'2025-09-09',1,NULL,'0000','2025-09-08 14:59:34','2025-09-08 19:14:57',NULL,'',NULL,NULL),(160,'fgh',1,10,'[\"prescriptions\\/llCGHiwvyiyZlIodqCviAQhMOjjfRArp42WgsSn0.jpg\"]','rgg wwrtewy Sibby','11.1807343,75.8545802','1','1','33','2025-09-10',1,NULL,'0000','2025-09-08 15:47:07','2025-09-08 19:31:11',NULL,'',NULL,NULL),(161,'fgh',1,10,'[\"prescriptions\\/oKbRRItQ8PsgYv9NtuKuX7OoyrDiVfnljh4a4tNs.jpg\"]','rgh','11.1807435,75.8545786','1','1',NULL,'2025-09-08',1,NULL,'0000','2025-09-08 15:54:00','2025-09-08 19:27:52',NULL,'',NULL,NULL),(162,'fgggg',1,10,'[\"prescriptions\\/WoltWhWgs4LpJSSsP0u4lzi9lnIemQ3NiCpMV9jD.jpg\"]','fgh','11.18074,75.8545724','1','1.0',NULL,'2025-09-08',1,NULL,'0000','2025-09-08 15:55:53','2025-09-08 18:58:44',NULL,'',NULL,NULL),(163,'test',1,10,'[\"prescriptions\\/50rH3rhcWwBkJNjm0zpyg4QX5tzb9dSLY5qlFPBJ.jpg\"]','kodungalloor','11.1807318,75.8545866','1','1.0',NULL,'2025-09-10',1,NULL,'0000','2025-09-09 02:44:17','2025-09-09 02:45:59',NULL,'prescriptions/cvaVYPNxdV8Daq51ftqhdJ4RC7UYNITylAMHZePy.jpg',NULL,NULL),(164,'test1',1,10,'[\"prescriptions\\/n9y4YP5SnvjK29ygLYAlVcqu1wvXrNIj78zGFhsn.jpg\"]','kondotty','11.1807389,75.8545801','1','1.0','33','2025-09-10',4,'11.180739,75.8545805','8770','2025-09-09 02:48:14','2025-09-09 03:46:58',NULL,NULL,NULL,'cash'),(165,'test 3',1,10,'[\"prescriptions\\/lBc2llM5R3AJ6nm3FG9iJoCZCEEDQMXKjXJx0nOe.jpg\"]','kondotty','11.1807377,75.8545801','1','1.0','33','2025-09-11',4,'11.1807369,75.8545801','4677','2025-09-09 03:02:03','2025-09-09 03:26:55',NULL,'prescriptions/EtcY5364feInc9V9C0ow4zaGSUyTCQ3l8qf6KBze.jpg',NULL,'cash'),(166,'test 4',1,10,'[\"prescriptions\\/172tssZClX8UMJerhBAxGrttxguyT1rTh2lr4oCS.jpg\"]','weyui','11.1807436,75.8545788','1','1.0','33','2025-09-10',4,NULL,'8012','2025-09-09 03:03:33','2025-09-09 03:45:39',NULL,NULL,NULL,NULL),(167,'suparna',46,10,'[\"prescriptions\\/M5sKHci3jxAyy893QZw5kQYDkOiANMr0dHXOGeOt.jpg\"]','puthukkudy vazhappatta house mundambra 673639','11.2352686,76.0521982','2',NULL,NULL,NULL,0,NULL,'0000','2025-09-09 07:51:14','2025-09-09 07:51:14',NULL,'1',NULL,NULL),(168,'udith',1,10,'[\"prescriptions\\/tjpVmVFjJ4UNd80cesHi4mjUB2dZcnZRIxGnhtfd.jpg\"]','kondotty','11.235262,76.0522225','1','1',NULL,'2025-09-11',1,NULL,'0000','2025-09-09 07:51:19','2025-09-09 08:03:59',NULL,'1',NULL,NULL),(169,'chinnama',48,10,'[\"prescriptions\\/sEAzgfOD6iICrNTPDB1ZERcSIoJlNxBxkjitaDVZ.jpg\"]','thottu mukkam','11.2352589,76.0522153','2','1','33','2025-09-10',3,NULL,'0000','2025-09-09 07:52:20','2025-09-09 08:07:45',NULL,'1',NULL,NULL),(170,'afri',47,10,'[\"prescriptions\\/k7M59lWLrqKqKNYaRnIUieKUALYqsD7YwwEMNJJy.jpg\"]','നാലകത്ത് ഹൗസ്\nഅരീക്കോട്','11.2352648,76.0522042','2',NULL,NULL,NULL,0,NULL,'0000','2025-09-09 07:52:52','2025-09-09 07:52:52',NULL,'1',NULL,NULL),(171,'JAHFAR',49,10,'[\"prescriptions\\/6jWgAW8PThv2JaCiSZtSVIJqRaSorJBCEBDYTXwW.jpg\"]','Areekode','11.2352653,76.0522223','2','1',NULL,'2025-09-10',2,NULL,'0000','2025-09-09 07:55:03','2025-09-09 07:59:41',NULL,'1',NULL,NULL),(172,'babu',47,10,'[\"prescriptions\\/GYENXXjZF5R5F8CG7nNoupI5TcJiXYR7VhvE1QVr.jpg\"]','അരീക്കോട്','11.2352659,76.0522064','1','1',NULL,'2025-09-10',1,NULL,'0000','2025-09-09 08:02:18','2025-09-09 08:03:26',NULL,'1',NULL,NULL),(173,'srutin',44,10,'[\"prescriptions\\/cxM0fL3AOL11k8EHfqBm1i50XRqlkhMyTm2KYhc0.jpg\"]','thiugyh','11.1877431,76.2598342','2',NULL,NULL,NULL,0,NULL,'0000','2025-09-09 16:24:07','2025-09-09 16:24:07',NULL,'1',NULL,NULL);
/*!40000 ALTER TABLE `pharmacy_prescriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `test_name` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `clinic_id` int DEFAULT NULL,
  `description` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `amount` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tests`
--

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
INSERT INTO `tests` VALUES (1,'Blood Test',9,'Sample test','120','2025-09-04 10:18:39','2025-09-04 04:49:12'),(3,'CBC (Complete Blood Count)',9,'A blood test to evaluate your overall health, including the number of red blood cells, white blood cells, and platelets.','200','2025-09-04 11:29:07','2025-09-04 05:59:07'),(4,'Lipid Profile',9,'Measures cholesterol and other fats in your blood to assess your risk for heart disease','180','2025-09-04 11:29:40','2025-09-04 05:59:40'),(5,'Thyroid Profile',9,'Assesses the function of your thyroid gland by measuring levels of thyroid-stimulating hormone (TSH) and other hormones','400','2025-09-04 11:30:13','2025-09-04 06:00:13');
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_contact_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact_phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insurance_policy_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_physician` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medical_history` text COLLATE utf8mb4_unicode_ci,
  `medications` text COLLATE utf8mb4_unicode_ci,
  `allergies` text COLLATE utf8mb4_unicode_ci,
  `blood_type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `status_new` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `login_id` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(70) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_ref_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` timestamp NULL DEFAULT NULL,
  `account_no` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','thomas@gmail.com',NULL,'$2y$12$hVzjfjbbpDFxmF0ZdMeKYePZ1/LTm2ZIxl5VEPYnE8G.MVovtwemK',NULL,'2025-08-07','Male','7510895815','kondotty','0','Jane Doe','9876543211','ABC Insurance','POLICY12345','Dr. Smith','No major illnesses','Vitamin D, Omega 3','Peanuts','O+',1,'0',NULL,'2025-02-10 04:20:42','2025-09-09 06:11:07','admin',NULL,NULL,NULL,NULL,'014366','9656560823'),(33,'Das','das@gmail.com',NULL,'$2y$12$LuXlVWFGlY5Hh/WCQRvdU.EOgTuRm2lWPSqrXOVmnmWdyEUKvi0Zu',NULL,'2001-11-24','Male','9061653693','Kondotty','1','7510895815','9048007933',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'0',NULL,'2025-06-26 23:33:59','2025-08-21 11:43:45','user','3',NULL,NULL,NULL,NULL,NULL),(36,'Jafar','jafar786@gmail.com',NULL,'$2y$12$OAAAiUaYP5KVcPv/RgZIjeI3FOV3A094/9eQvO6b7MhLblG9xv5Te',NULL,'2010-01-11','Male','9656523476','address new','0','Hassan','8075056740','Bajaj','756','Irure sed repellendu','nil','nil','nil','0+',1,'0',NULL,'2025-08-11 05:16:31','2025-08-11 05:16:31','user',NULL,NULL,NULL,NULL,NULL,NULL),(43,'Mishal Mohammed K','mishal@gmail.com',NULL,'$2y$12$n6IJ23oQxAnCG5vpV66q1.rPidiJ2tN8FuUfdBDI0HBwMVeexLmEy',NULL,'2001-05-22','male','1234567890','Ramanattukara','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'B+',1,'0',NULL,'2025-08-22 04:48:27','2025-08-22 04:48:27','user',NULL,NULL,NULL,NULL,NULL,NULL),(44,'sruthin','sruthinvnb@gmail.com',NULL,'$2y$12$l5ugBDbJMJ4DeBhjhXZXF.BERhDCodkKuinhCPwhxRjNW.sPGSnbi',NULL,'1995-10-26','male','7907920728','thiyyadath house','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'A+',1,'0',NULL,'2025-09-06 06:53:57','2025-09-06 06:54:19','user',NULL,NULL,NULL,NULL,NULL,NULL),(45,'Shibil Das','shibildas@gmail.com',NULL,'$2y$12$/bgG.O.KvjjkpPhlQ0lToeGEdHUJFRbPqtSf8UdKtBSCVeczESl.S',NULL,'2000-08-29','Male','7558030197','perinthalmanna','0','shibil','7558030197',NULL,NULL,NULL,NULL,NULL,NULL,'B+',1,'0',NULL,'2025-09-09 04:03:40','2025-09-09 04:07:12','user',NULL,NULL,NULL,NULL,NULL,NULL),(46,'SUPARNA P V','suparnasukumarkannan26@gmail.com',NULL,'$2y$12$ZkuifPVsQpEMVrOU9yqn0eqr7o.T8BN77CXC1ANi1CB7Kxt/Z7Kji',NULL,'1998-02-24','female','8593950703','Puthukkudy vazhappatta house mundambra, Ugrappuram post, Areekode, Malappuram','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'A+',1,'0',NULL,'2025-09-09 07:32:30','2025-09-09 07:32:57','user',NULL,NULL,NULL,NULL,NULL,NULL),(47,'Babu muneer','Babumuneer1@gmail.com',NULL,'$2y$12$YjjpUOMp2NZdHRnGW5q7D./nDFRvm0/7RiWzH4KoQJfVEt0o7VuDi',NULL,'1975-05-31','male','9847013471','kollathodi house','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'B+',1,'0',NULL,'2025-09-09 07:33:22','2025-09-09 07:35:01','user',NULL,NULL,NULL,NULL,NULL,NULL),(48,'sabitha ps','sabitha19361@gmail.com',NULL,'$2y$12$l0YzuBn5s4kp.mrGiCdr1eOH/NsaFy7RjEMI6MrcSAi6dJ32a7hki',NULL,'1980-05-06','female','7736564445','kavungal (H) areekode','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'O+',1,'0',NULL,'2025-09-09 07:34:00','2025-09-09 08:28:15','user',NULL,NULL,NULL,NULL,NULL,NULL),(49,'JAHFAR PP','jafarppyma@gmail.com',NULL,'$2y$12$TOdO/cNQ0wzwbZCO0jJva.Jh0XUWm0drgCjWXzBTAk.XyFkY20gWu',NULL,'1971-05-20','male','9447541157','Areekode','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'B+',1,'0',NULL,'2025-09-09 07:34:34','2025-09-09 07:35:09','user',NULL,NULL,NULL,NULL,NULL,NULL),(50,'Athulya T','athulyat2000@gmail.com',NULL,'$2y$12$aXpx67dnw6UGgnqe3.0/B.YFcXa1.X3maYwmzf.alOVNYPjuCIX8S',NULL,'2000-05-23','female','8606099068','chappangathittathil house','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'B+',1,'0',NULL,'2025-09-09 07:35:25','2025-09-09 07:36:45','user',NULL,NULL,NULL,NULL,NULL,NULL),(51,'Noushaja pt','Noushajapt@gmail.com',NULL,'$2y$12$aG5c0e/n5CExc4Yhq0keKe20yxcGSL6wC4seJpdRevlBDzqyZFIEm',NULL,'1985-09-11','female','9633693221','noonjimmal (ho)','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'0',NULL,'2025-09-09 07:36:58','2025-09-11 09:59:09','user',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-18 13:46:52

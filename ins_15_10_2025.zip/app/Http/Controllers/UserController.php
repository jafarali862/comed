<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\PasswordResetRequest;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

    $search = strtolower($request->input('search', ''));
    $status = $request->input('status', 1);
    $role = null;

    if ($search === 'executive') {
    $role = 3;
    } elseif ($search === 'sub admin') {
    $role = 2;
    }

    $users = User::query()
    ->when($search, function ($query) use ($search, $role) {
        $query->where(function ($q) use ($search, $role) {
            $q->where('name', 'like', '%' . $search . '%')
                ->orWhere('email', 'like', '%' . $search . '%');

            if (!is_null($role)) {
                $q->orWhere('role', $role);
            }
        });
    })
    ->where('status', $status)
    ->where('role', '!=', 1)
    ->orderBy('id', 'desc') // 👈 Add this line

    ->get(); 

    return view("dashboard.user.index")->with([
    "users" => $users,
    "status" => $status,
    ]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("dashboard.user.create");
    }

    /**
     * Store a newly created resource in storage.
     */
     public function store(Request $request)
    {
    // Validate the request
    $validated = $request->validate([
        "name" => "required|string|max:255",
        // "email" => "required|email|unique:users,email",
        'email' => 'required|email:rfc,dns|unique:users,email',
        "password" => "required|string|min:6",
        "phone" => "required|unique:users,phone",
        "place" => "required|string|max:255",
        "role" => "required",
        "blood" => "required|string|max:10",
        "address" => "required|string|max:1000",
         "date_of_birth" => "required|string",
        "join_date" => "required|string",
         "country_code" => "required|string",
        "profile_picture" => "nullable|image|mimes:jpeg,png,jpg", // max 2MB
    ]);

    $profilePicturePath = null;
    if ($request->hasFile('profile_picture')) 
    {
        $profilePicturePath = $request->file('profile_picture')->store('uploads', 'public');
    }

    // Create the user
    User::create([
        "name" => $request->name,
        "email" => $request->email,
        "phone" => $request->phone,
        "place" => $request->place,
        "password" => Hash::make($request->password),
        "role" => $request->role,
        "status" => 1,
        "create_by" => Auth::user()->id,
        "update_by" => Auth::user()->id,
        "blood" => $request->blood,
        "address" => $request->address,
        "country_code" => $request->country_code,
        "date_of_birth" => $request->date_of_birth,
        "join_date" => $request->join_date,
        "profile_image" => $profilePicturePath,
    ]);

    // Return success with redirect
    return response()->json([
        'success' => 'User added successfully',
        'redirect_url' => route('user.list')
    ]);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $user = User::where('id', $id)->first();
        return view("dashboard.user.edit")->with("user", $user);
    }

    public function userActiveChange(Request $request)
    {
        $request->validate([
            'id' => 'required|integer|exists:users,id',
            'action' => 'required|string|in:activate,deactivate',
        ]);

        $user = User::findOrFail($request->id);
        $status = $request->action === 'activate' ? 1 : 0;
        $user->update(['status' =>$status]);

        return response()->json(['message' => 'User status updated successfully']);
    }


    public function approval(Request $request)
    {
        $users = User::where('login_request', 1)->get();
        return view('dashboard.user.approval')->with('users', $users);
    }

  

    public function approve($id)
    {
        $user = User::where('id', $id)->update(['login_request' => 0]);
        // return response()->json(['message' => 'Approved Successfully']);
            return redirect()->back()->with('success', 'Approved Successfully');

    }


    /**
     * Update the specified resource in storage.
     */
     public function update(Request $request)
    {
   

        // $request->validate([
        // "id" => "required|exists:users,id",
        // "name" => "required|string|max:255",
        // "phone" => "required|string|max:20",
        // "email" => "required|email",
        // "password" => "nullable|string|min:6",
        // "role" => "required|string",
        // "status2" => "required",
        // "blood" => "nullable|string|max:10",
        // "address" => "nullable|string|max:1000",    
        // "date_of_birth" => "required|string",
        // "join_date" => "required|string",
        // "country_code" => "nullable|string",
        // "profile_picture" => "nullable|image|mimes:jpeg,png,jpg",
        // ]);


        $request->validate([
        "id" => "required|exists:users,id", // Ensure the user exists
        "name" => "required|string|max:255",
        "phone" => "required|string|max:20",
        'email' => 'required|email',
        "password" => "nullable|string|min:6",
        "role" => "required|string",
        "status2" => "required",
        "blood" => "required|string|max:10",
        "address" => "required|string|max:1000",    
        "date_of_birth" => "required|string",
        "join_date" => "required|string",
        "country_code" => "nullable|string",
        "profile_picture" => "nullable|image|mimes:jpeg,png,jpg",


        ], [

        'blood.max' => 'The blood group is required',
        ]);



    // Prepare data
    $data = [
    "name" => $request->name,
    "phone" => $request->phone,
    "email" => $request->email,
    "role" => $request->role,
    "status" => $request->status2,
    "blood" => $request->blood,
    "address" => $request->address,
    "country_code" => $request->country_code,
    "date_of_birth" => $request->date_of_birth,
    "join_date" => $request->join_date,
    // "update_by" => auth()->id(),
    ];

    // Update password only if provided
    if (!empty($request->password)) {
    $data['password'] = Hash::make($request->password);
    }

    // Handle profile picture upload
    if ($request->hasFile('profile_picture')) {
    $profilePicturePath = $request->file('profile_picture')->store('uploads', 'public');
    $data['profile_image'] = $profilePicturePath;
    }

    // Update the user
    User::where('id', $request->id)->update($data);

    return response()->json([
    'success' => 'User updated successfully',
    'redirect_url' => route('user.list'),
    ]);
    }


    // public function block($id)
    // {

    // DB::transaction(function () use ($id) 
    // {
    // DB::table('users')->where('id', $id)->update([
    // 'status' => 0, 
    // ]);

    // DB::table('oauth_access_tokens')->where('user_id', $id)->update([
    // 'revoked' => 1,
    // ]);
    // });

    // return redirect()->back()->with('success', 'User has been blocked successfully');
    // }

    public function block(Request $request, $id)
    {
    $request->validate([
        'block_reason' => 'required|string|max:500',
    ]);

    DB::transaction(function () use ($id, $request) {
        // 1. Update users table with status, reason & timestamp
        DB::table('users')->where('id', $id)->update([
            'status' => 0,
            'block_reason' => $request->input('block_reason'),
            'updated_at' => now(),
        ]);

        // 2. Revoke all access tokens for this user
        DB::table('oauth_access_tokens')->where('user_id', $id)->update([
            'revoked' => 1,
        ]);
    });

    return redirect()->back()->with('success', 'User has been blocked successfully.');
    }


    public function update_profile(Request $request)
    {
    $admin = \App\Models\User::where('role', 1)->first(); // Or use auth()->user()

    $request->validate([
        'name' => 'nullable',
        'email' => 'nullable',
        'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:2048', // validate image
    ]);

    $admin->name = $request->name;
    $admin->email = $request->email;


    if ($request->hasFile('profile_image')) {
        $file = $request->file('profile_image');
        $path = $file->store('profile_images', 'public'); // saved in /storage/app/public/profile_images

        // Optionally delete old image:
        if ($admin->profile_image && \Storage::disk('public')->exists($admin->profile_image)) {
            \Storage::disk('public')->delete($admin->profile_image);
        }

        $admin->profile_image = $path;
    }

    $admin->save();

    return back()->with('success', 'Admin profile updated.');
    }

    public function unblock($id)
    {
    // Optional: Use a transaction to ensure both updates succeed
    DB::transaction(function () use ($id) {
    // 1. Update users table (e.g., set 'imei_blocked' to 1)
    DB::table('users')->where('id', $id)->update([
    'status' => 1, // assuming 'imei' column is used to indicate block status
    ]);

    // 2. Revoke all access tokens for this user
    DB::table('oauth_access_tokens')->where('user_id', $id)->update([
    'revoked' => 0,
    ]);
    });

    return redirect()->back()->with('success', 'User has been un blocked successfully');
    }




    public function passwordResetRequest(Request $request)
    {
        $requests = DB::table('password_reset_requests')
            ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
            ->select('password_reset_requests.*', 'users.name as user_name')
            ->where('password_reset_requests.status', 1)
            ->orderBy('password_reset_requests.created_at', 'desc')
            ->paginate(10);

        return view('dashboard.password-reset.index')->with(['requests' => $requests]);
    }


    public function passwordResetEdit(Request $request, $id)
    {
        $requestData = DB::table('password_reset_requests')
            ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
            ->select('password_reset_requests.*', 'users.name as user_name')
            ->where('password_reset_requests.id', $id)
            ->first();

        if (!$requestData) {
            return redirect()->route('dashboard.password-reset.index')->with('error', 'Request not found.');
        }

        return view('dashboard.password-reset.edit', ['request' => $requestData]);
    }

    public function passwordResetUpdate(Request $request, $id)
    {
        $request->validate([
            'user_id' => 'required',
            'new_password' => 'required|confirmed',
        ]);

        $user = User::find($request->user_id);

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'User not found.'
            ], 404);
        }

        $user->password = Hash::make($request->new_password);
        $user->save();

        PasswordResetRequest::where('id', $id)->update(['status' => 0]);

        foreach ($user->tokens as $token) {
            $token->revoke();
        }

        return response()->json([
            'success' => true,
            'message' => 'Password updated successfully.'
        ]);
    }

    public function passwordResetReject(Request $request, $id)
    {
        PasswordResetRequest::where('id', $id)->update(['status' => 2]);

        return response()->json([
            'success' => true,
            'message' => 'Request reject success'
        ]);
    }

    public function allPasswordRestRequest()
    {
        $all_request = DB::table('password_reset_requests')
            ->leftJoin('users', 'users.id', '=', 'password_reset_requests.user_id')
            ->select('password_reset_requests.*', 'users.name as user_name')
            ->orderBy('password_reset_requests.created_at', 'desc')
            ->paginate(10);
        return view('dashboard.password-reset.all')->with(['data' => $all_request]);
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}

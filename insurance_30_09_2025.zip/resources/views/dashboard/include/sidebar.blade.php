
  <div class="sidenav-menu">

  <button class="button-on-hover">
                <i class="ti ti-menu-4 fs-22 align-middle"></i>
            </button>

            <!-- Full Sidebar Menu Close Button -->
            <button class="button-close-offcanvas">
                <i class="ti ti-x align-middle"></i>
            </button>



            <div class="scrollbar" data-simplebar>
            <!-- User -->

            <!-- <div class="sidenav-user" style="margin-left: 20px;margin-right:20px;margin-top: 10px;margin-bottom: 10px;">
            <div class="d-flex justify-content-center align-items-center text-center">
            <div>
            <a href="{{ route('dashboard') }}" class="link-reset text-center d-block">
            @if($companyLogo && $companyLogo->logo)
            <img src="{{ asset('storage/' . $companyLogo->logo) }}" alt="user-image" class="rounded-circle mb-2 avatar-md d-block mx-auto" style="height: 3.50rem;
                width: 3.50rem;">
            <span class="sidenav-user-name fw-bold d-block">Dashboard</span>
            @endif
            </a>
            </div>
            </div>
            </div> -->


          



        <div class="sidenav-user my-3 px-3">
        <a href="{{ route('dashboard') }}" class="d-flex align-items-center link-reset text-decoration-none text-dark" style="margin-left: -10px;margin-top: -7px;">

        @if($companyLogo && $companyLogo->logo)
        <img src="{{ asset('storage/' . $companyLogo->logo) }}"
        alt="user-image"
        class="rounded-circle avatar-md me-3" style="height: 3.50rem;
        width: 3.50rem;">
        @endif
        <div class="d-flex flex-column ms-2 me-2"> 
     
        </div>
        </a>

        <div>
        <a href="{{ route('dashboard') }}" class="link-reset">
        <div class="d-flex flex-column flex-grow-1">
        <span class="sidenav-user-name fw-bold"
        style="font-size: 16px; line-height: 1.2;margin-top:5px; white-space: normal; word-break: break-word;">

        {{ $companyLogo->name ?? 'Company Name' }}
        </span>
        </div>

 
        </a>
        </div>
        </div>



            

        <ul class="side-nav">
        <a href="{{ route('dashboard') }}" style="margin-top: -17px;margin-bottom: 10px;">
        <li class="side-nav-title" data-lang="menu-title">Dashboard</li>
        </a>
        <!-- <li class="side-nav-title" data-lang="apps-title">Apps</li> -->


        <li class="side-nav-item {{ Request::is('add-user') || Request::is('user-list') || Request::is('edit-user/*') 
        ? 'active' : '' }}">

        <a data-bs-toggle="collapse"
        href="#sidebarUsers"
        aria-expanded="{{
        Request::is('add-user') || 
        Request::is('user-list') || 
        Request::is('edit-user/*') 
        ? 'true' : 'false' }}"
        aria-controls="sidebarUsers"
        class="side-nav-link {{
        Request::is('add-user') || 
        Request::is('user-list') || 
        Request::is('edit-user/*') 
        ? '' : 'collapsed' }}">

        <span class="menu-icon"><i class="ti ti-users"></i></span>
        <span class="menu-text" data-lang="users"> Users </span>
        <span class="menu-arrow"></span>
        </a>

        <div class="collapse {{
        Request::is('add-user') || 
        Request::is('user-list') || 
        Request::is('edit-user/*') 
        ? 'show' : '' }}" id="sidebarUsers">

        <ul class="sub-menu">
        <li class="side-nav-item">
        <a href="{{ route('user.create') }}"
        class="side-nav-link {{
        Request::is('add-user') || Request::is('edit-user/*') ? 'active' : '' }}">
        <span class="menu-text" data-lang="contacts">Add User</span>
        </a>
        </li>

        <li class="side-nav-item">
        <a href="{{ route('user.list') }}"
        class="side-nav-link {{
        Request::is('user-list') ? 'active' : '' }}">
        <span class="menu-text" data-lang="roles">User List</span>
        </a>
        </li>
        </ul>
        </div>
        </li>

        <li class="side-nav-item {{ 
        Request::is('add-company') || 
        Request::is('company-list') || 
        Request::is('edit-company/*') || 
        Request::is('questions') || 
        Request::is('questions/*/edit') || 
        Request::is('templates') || 
        Request::is('templates/*/edit')
        ? 'active' : '' 
        }}">
        <a data-bs-toggle="collapse"
        href="#sidebarProjects"
        aria-expanded="{{ 
        Request::is('add-company') || 
        Request::is('company-list') || 
        Request::is('edit-company/*') || 
        Request::is('questions') || 
        Request::is('questions/*/edit') || 
        Request::is('templates') || 
        Request::is('templates/*/edit') 
        ? 'true' : 'false' }}"
        aria-controls="sidebarProjects"
        class="side-nav-link {{ 
        Request::is('add-company') || 
        Request::is('company-list') || 
        Request::is('edit-company/*') || 
        Request::is('questions') || 
        Request::is('questions/*/edit') || 
        Request::is('templates') || 
        Request::is('templates/*/edit') 
        ? '' : 'collapsed' }}">

        <span class="menu-icon"><i class="ti ti-briefcase"></i></span>
        <span class="menu-text" data-lang="projects">Insurance Company</span>
        <span class="menu-arrow"></span>
        </a>

        <div class="collapse {{
        Request::is('add-company') || 
        Request::is('company-list') || 
        Request::is('edit-company/*') || 
        Request::is('questions') || 
        Request::is('questions/*/edit') || 
        Request::is('templates') || 
        Request::is('templates/*/edit')
        ? 'show' : '' }}" id="sidebarProjects">

        <ul class="sub-menu">
        <li class="side-nav-item">
        <a href="{{ route('company.create') }}"
        class="side-nav-link {{ Request::is('add-company') || Request::is('edit-company/*') ? 'active' : '' }}">
        <span class="menu-text" data-lang="projects">Add Company</span>
        </a>
        </li>
        <li class="side-nav-item">
        <a href="{{ route('company.list') }}"
        class="side-nav-link {{ Request::is('company-list') ? 'active' : '' }}">
        <span class="menu-text" data-lang="projects-list">Company List</span>
        </a>
        </li>
        <li class="side-nav-item">
        <a href="{{ route('questions.index_question') }}"
        class="side-nav-link {{ Request::is('questions') || Request::is('questions/*/edit') ? 'active' : '' }}">
        <span class="menu-text" data-lang="project-details">Questionnaire List</span>
        </a>
        </li>
        <li class="side-nav-item">
        <a href="{{ route('templates.list_templates') }}"
        class="side-nav-link {{ Request::is('templates') || Request::is('templates/*/edit') ? 'active' : '' }}">
        <span class="menu-text" data-lang="project-kanban">Templates</span>
        </a>
        </li>
        </ul>
        </div>
        </li>




        <li class="side-nav-item {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'active' : '' }}">
        <a data-bs-toggle="collapse"
        href="#sidebarInvoice"
        aria-expanded="{{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'true' : 'false' }}"
        aria-controls="sidebarInvoice"
        class="side-nav-link {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? '' : 'collapsed' }}">

        <span class="menu-icon"><i class="ti ti-invoice"></i></span>
        <span class="menu-text">Case Management</span>
        <span class="menu-arrow"></span>
        </a>

        <div class="collapse {{ Request::is('insurance/create') || Request::is('case-list') || Request::is('assigned-case') || Request::is('case-edit/*') ? 'show' : '' }}" id="sidebarInvoice">
        <ul class="sub-menu">
        <li class="side-nav-item">
        <a href="{{ route('insurance.create') }}"
        class="side-nav-link {{ Request::is('insurance/create') ? 'active' : '' }}">
        <span class="menu-text">Add Case</span>
        </a>
        </li>
        <li class="side-nav-item">
        <a href="{{ route('case.index') }}"
        class="side-nav-link {{ Request::is('case-list') || Request::is('case-edit/*') ? 'active' : '' }}">
        <span class="menu-text">Case List</span>
        </a>
        </li>
        <li class="side-nav-item">
        <a href="{{ route('assigned.case') }}"
        class="side-nav-link {{ Request::is('assigned-case') ? 'active' : '' }}">
        <span class="menu-text">Assigned Case</span>
        </a>
        </li>
        </ul>
        </div>
        </li>




        <li class="side-nav-item">
        <a href="{{ route('request.report') }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-chart-histogram"></i></span>
        <span class="menu-text" data-lang="metrics"> Report Management </span>
        </a>
        </li>


        <li class="side-nav-item">
        <a href="{{ route('odometer.list') }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-folder"></i></span>
        <span class="menu-text" data-lang="file-manager"> Odometer Reading </span>
        </a>
        </li>


        <li class="side-nav-item">
        <a href="{{ route('approval.request') }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-message-dots"></i></span>
        <span class="menu-text" data-lang="chat"> Approvel Request </span>
        </a>
        </li>

        <li class="side-nav-item">
        <a href="{{ route('password.reset.request') }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-calendar"></i></span>
        <span class="menu-text" data-lang="calendar"> Password Reset </span>
        </a>
        </li>

        <li class="side-nav-item">
        <a href="{{ route('logo.edit', 1) }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-category"></i></span>
        <span class="menu-text" data-lang="widgets"> Company Management </span>
        </a>
        </li>


        <li class="side-nav-item">
        <a href="{{ route('final.report.create') }}" class="side-nav-link">
        <span class="menu-icon"><i class="ti ti-chart-histogram"></i></span>
        <span class="menu-text" data-lang="metrics"> Make Final Report </span>
        </a>
        </li>

        </ul>


  </div>
  </div>

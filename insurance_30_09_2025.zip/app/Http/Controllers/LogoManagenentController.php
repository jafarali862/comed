<?php

namespace App\Http\Controllers;

use App\Models\CompanyLogo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;


class LogoManagenentController extends Controller
{

    public function index()
    {
        $logos = CompanyLogo::paginate(10);
        return view('dashboard.logo.index', compact('logos'));
    }

    public function getLogo()
    {
        return view('dashboard.logo.create');
    }

     public function index2()
    {
        $logoPath = DB::table('company_logos')->where('id', 1)->value('logo_path');
        return view('dashboard.logo.company_logo', compact('logoPath'));
    }


    public function store(Request $request)
    {

    $request->validate([
    'logo' => 'required|image|mimes:jpeg,jpg,png,webp|max:150',  // KB
    ]);

    $file = $request->file('logo');
    $extension = $file->getClientOriginalExtension();
    $filename = 'company_logo_' . time() . '_' . Str::random(5) . '.' . $extension;

    $manager = new ImageManager(new Driver());
    $image = $manager->read($file->getRealPath());

    $width = $image->width();
    $height = $image->height();
    $size = min($width, $height);

    $image->crop($size, $size, intval(($width - $size) / 2), intval(($height - $size) / 2))
        ->resize(256, 256);

    $path = 'logos/' . $filename;

    $encoded = $image->toJpeg(75); 
    Storage::disk('public')->put($path, (string) $encoded);

    // Update the DB
    DB::table('company_logos')->where('id', 1)->update([
    'logo_path' => $path
    ]);

    return redirect()->route('company.logo.form')->with('success', 'Logo uploaded successfully');

    }


    public function storeLogo(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:company_logos,email',
            'phone' => 'required|string|max:15',
            'place' => 'required|string|max:255',
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            
        ]);

        
        if ($request->hasFile('logo')) {
           
            $logoPath = $request->file('logo')->store('logos', 'public');
        }

        CompanyLogo::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'place' => $request->place,
            'logo' => $logoPath,
            
        ]);

        return redirect()->route('logos')->with('success', 'Company logo added successfully!');
    }

    public function editLogo($id)
    {
        
    $logo = CompanyLogo::findOrFail($id);
    return view('dashboard.logo.edit', compact('logo'));
    }

    public function updateLogo(Request $request, $id)
    {
        
        // $request->validate([
        //     'name'      => 'required|string|max:255',
        //     'email'     => 'required|email|unique:company_logos,email,' . $id,  
        //     'phone'     => 'required|string|max:15',
        //     'place'     => 'required|string|max:255',
        //     'logo'      => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',       
        //     'logo_path' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:150',         
        // ]);

        // $logo = CompanyLogo::findOrFail($id);       
        // $logo->name = $request->name;
        // $logo->email = $request->email;
        // $logo->phone = $request->phone;
        // $logo->place = $request->place;

        // if ($request->hasFile('logo')) 
        // {        
        // if (file_exists(public_path('storage/' . $logo->logo))) 
        // {
        // unlink(public_path('storage/' . $logo->logo));
        // }

        // $logoPath = $request->file('logo')->store('logos', 'public');
        // $logo->logo = $logoPath;
        // }

        // $logo->save();

        // session()->flash('success', 'Company logo updated successfully!');
        // return redirect()->route('logo.edit',['id'=>1]);

    $request->validate([
        'name'      => 'required|string|max:255',
        'email'     => 'required|email|unique:company_logos,email,' . $id,
        'phone'     => 'required|string|max:15',
        'place'     => 'required|string|max:255',
        'logo'      => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        'logo_path' => 'nullable|image|mimes:jpeg,jpg,png,webp|max:150', // 150 KB max
    ]);

    $logo = CompanyLogo::findOrFail($id);
    $logo->name = $request->name;
    $logo->email = $request->email;
    $logo->phone = $request->phone;
    $logo->place = $request->place;

    // Upload plain logo
    if ($request->hasFile('logo')) {
        if ($logo->logo && Storage::disk('public')->exists($logo->logo)) {
            Storage::disk('public')->delete($logo->logo);
        }

        $path = $request->file('logo')->store('logos', 'public');
        $logo->logo = $path;
    }

    // Upload processed logo (logo_path)
    if ($request->hasFile('logo_path')) {
        if ($logo->logo_path && Storage::disk('public')->exists($logo->logo_path)) {
            Storage::disk('public')->delete($logo->logo_path);
        }

        $file = $request->file('logo_path');
        $extension = $file->getClientOriginalExtension();
        $filename = 'company_logo_' . time() . '_' . Str::random(5) . '.' . $extension;

        $manager = new ImageManager(new Driver()); // use Imagick if needed
        $image = $manager->read($file->getRealPath());

        $width = $image->width();
        $height = $image->height();
        $size = min($width, $height);

        $image->crop($size, $size, intval(($width - $size) / 2), intval(($height - $size) / 2))
              ->resize(256, 256);

        $path = 'logos/' . $filename;
        $encoded = $image->toJpeg(75); // quality 75

        Storage::disk('public')->put($path, (string) $encoded);

        $logo->logo_path = $path;
    }

    $logo->save();

    session()->flash('success', 'Company logo updated successfully!');
    return redirect()->route('logo.edit', ['id' => $id]);

    }
}

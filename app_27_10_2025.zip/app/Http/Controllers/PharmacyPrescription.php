<?php

namespace App\Http\Controllers;

// use App\Models\Log;
use Illuminate\Support\Facades\Log;
use App\Models\User;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use App\Models\PharmacyMedicine;
use App\Models\Medicine;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Models\PharmacyPrescription as pprescription;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Exception;


class PharmacyPrescription extends Controller
{
    public function index()
    {   
        $val=0;
       $medicines = Medicine::all();
        $pharmacyPrescriptions = pprescription::with(['user', 'pharmacy'])
        ->where('status', 0)
        ->orderBy('created_at', 'desc')
        ->paginate(10);

        $pharmacies = Pharmacy::all(); // or ->orderBy('name')->get();
       $deliveryAgents=User::where('user_type',1)->get();
        return view('backend.pharmacypres.index', compact('pharmacyPrescriptions','medicines','val','pharmacies','deliveryAgents'));
    }

     public function index2()
    {   
           $medicines = Medicine::all();
        $val=0;
        $loginId = auth()->user()->login_id2;
        $pharmacyPrescriptions = pprescription::with(['user', 'pharmacy'])
        ->where('status', 0)
        ->where('pharmacy_id', $loginId) // filter by login_id

        ->orderBy('created_at', 'desc')
        ->paginate(10);

        return view('backend.pharmacypres2.index', compact('pharmacyPrescriptions', 'medicines','val'));
    }

    // public function checkNew()
    // {
    // $latest = pprescription::orderBy('id', 'desc')->first();

    // return response()->json([
    // 'latest_id' => $latest ? $latest->id : 0
    // ]);
    // }

    // public function checkNew2()
    // {
    // $latest = ClinicPrescription::orderBy('id', 'desc')->first();

    // return response()->json([
    // 'latest_id' => $latest ? $latest->id : 0
    // ]);
    // }


    public function completeAuth(Request $request)
    {
    try {
        // Validate input
        $request->validate([
            'auth_password' => 'required',
            'id2'            => 'required|integer|exists:pharmacy_prescriptions,id',
        ]);

        $prescription = Pprescription::findOrFail($request->id2);
        $user = auth()->user();

        Log::info('Attempting to complete prescription.', [
            'user_id' => $user->id ?? null,
            'prescription_id' => $request->id2,
        ]);

        // Check password match
        if (!Hash::check($request->auth_password, $user->password)) {
            Log::warning('Authentication failed for prescription completion.', [
                'user_id' => $user->id,
                'prescription_id' => $request->id2,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Password does not match the authenticated user.',
                'errors'  => ['auth_password' => ['Password is incorrect.']],
            ], 422);
        }

        // Update prescription
        $prescription->status = 4;
        $prescription->login_id_new = $user->id;
        $prescription->save();

        Log::info('Prescription marked as completed successfully.', [
            'prescription_id' => $prescription->id,
            'updated_by'      => $user->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Prescription marked as completed successfully.',
        ]);

    } catch (Exception $e) {
        // Log detailed error info
        Log::error('Error during completeAuth process.', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
            'user_id' => auth()->id(),
            'request_data' => $request->all(),
        ]);

        // Return error response
        return response()->json([
            'success' => false,
            'message' => 'An unexpected error occurred. Please try again later.',
            'error_details' => $e->getMessage(),
        ], 500);
    }
}


public function store(Request $request)
{
    try 
    {
        $request->validate([
            'name'             => 'required|string|max:255', 
            'pharmacy_id'      => 'required|exists:pharmacies,id',
            'payment_method'   => 'required|string',
            'amount'           => 'required|numeric',
            'prescription'     => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'assigned_user'    => 'required|exists:users,id',
            'delivery_date'    => 'required|date',
            'delivery_address' => 'required|string',
        ]);

        Log::info('Pharmacy Prescription Store request received.', [
            'user_id' => auth()->id(),
            'request_data' => $request->except(['prescription']), // avoid large file logs
        ]);

        $prescriptionPaths = [];

        if ($request->hasFile('prescription')) {
            $file = $request->file('prescription');
            $path = $file->store('prescriptions', 'public');
            $prescriptionPaths[] = $path;

            Log::info('Prescription file uploaded successfully.', [
                'file_path' => $path,
            ]);
        }

        $prescription = Pprescription::create([
            'name'             => $request->name,
            'pharmacy_id'      => $request->pharmacy_id,
            'user_id'          => auth()->id() ?? 1,
            'payment_method'   => $request->payment_method,
            'total_amount'     => $request->amount,
            'prescription'     => json_encode($prescriptionPaths),
            'delivery_id'      => $request->assigned_user,
            'expect_date'      => $request->delivery_date,
            'delivery_address' => $request->delivery_address,
            'status'           => 3,
            'lat_long'         => '11.2352648,76.0522042',
        ]);

        Log::info('Pharmacy prescription stored successfully.', [
            'prescription_id' => $prescription->id,
            'created_by' => auth()->id(),
        ]);

        return redirect()
            ->route('pharmacy-prescriptions.index')
            ->with('success', 'Pharmacy prescription saved successfully!')
            ->with('status_filter', 3);

    } 
    catch (Exception $e) {

        Log::error('Error while storing pharmacy prescription.', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
            'user_id' => auth()->id(),
            'request_data' => $request->all(),
        ]);

        if (!empty($prescriptionPaths)) {
            foreach ($prescriptionPaths as $path) {
                if (Storage::disk('public')->exists($path)) {
                    Storage::disk('public')->delete($path);
                    Log::warning('Rolled back uploaded file after error.', ['file' => $path]);
                }
            }
        }
        return redirect()
            ->back()
            ->with('error', 'Failed to save pharmacy prescription. Please try again.')
            ->withInput();
    }
}




public function edit($id)
{
    try {
        $medicines = Medicine::all();
        $pharmacyPrescription = pprescription::with('deliveryAgent')->findOrFail($id);
        $users = User::all();
        $deliveryAgents = User::where('user_type', 1)->get();
        $pharmacies = Pharmacy::all();
        $medicinesPhar = PharmacyMedicine::with('medicine')
            ->withTrashed()
            ->where('pharmacy_prescription_id', $id)
            ->distinct()
            ->get();

        return view('backend.pharmacyPres.edit_ppres', compact(
            'pharmacyPrescription',
            'users',
            'pharmacies',
            'medicinesPhar',
            'medicines',
            'deliveryAgents'
        ));

    } catch (ModelNotFoundException $e) {
        // Log model not found errors
        Log::error('Prescription not found for ID: ' . $id, [
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);

        return redirect()->back()->with('error', 'Prescription not found.');

    } catch (\Exception $e) {
        // Log any other errors
        Log::error('Error in PharmacyPrescriptionController@edit', [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()->back()->with('error', 'Something went wrong while loading the prescription.');
    }
}


  

public function edit2($id)
{
    try {
        // Fetch related data
        $medicines = Medicine::all();
        $pharmacyPrescription = pprescription::findOrFail($id);
        $users = User::all();
        $deliveryAgents = User::where('user_type', 1)->get();
        $pharmacies = Pharmacy::all();
        $medicinesPhar = PharmacyMedicine::with('medicine')
            ->withTrashed()
            ->where('pharmacy_prescription_id', $id)
            ->distinct()
            ->get();

        // Return the edit view
        return view('backend.pharmacyPres2.edit_ppres', compact(
            'pharmacyPrescription',
            'users',
            'pharmacies',
            'medicinesPhar',
            'medicines',
            'deliveryAgents'
        ));

    } catch (ModelNotFoundException $e) {
        // Log specific "not found" errors
        Log::error('Pharmacy Prescription not found in edit2()', [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);

        // Redirect back with user-friendly message
        return redirect()->back()->with('error', 'Pharmacy Prescription not found.');

    } catch (\Exception $e) {
        // Log all other errors with detailed trace
        Log::error('Unexpected error in PharmacyPrescriptionController@edit2', [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        // Redirect back with a general error message
        return redirect()->back()->with('error', 'An unexpected error occurred while loading the prescription.');
    }
}



public function update(Request $request, $id)
{
    try {
        // Validate request input
        $request->validate([
            'delivery_address' => 'required|string',
        ]);

        // Try to find the record
        $pharmacyPrescription = pprescription::findOrFail($id);

        // Update the record
        $pharmacyPrescription->delivery_address = $request->delivery_address;
        $pharmacyPrescription->save();

       

        // Also log in Laravel’s storage logs
        Log::info('Pharmacy Prescription address updated successfully.', [
            'user_id' => Auth::id(),
            'prescription_id' => $id,
            'new_address' => $request->delivery_address,
        ]);

        return redirect()
            ->route('pharmacy-prescriptions.index')
            ->with('success', 'Prescription updated successfully.');

    } catch (ModelNotFoundException $e) {
        // Log not found errors
        Log::error('Pharmacy Prescription not found during update.', [
            'prescription_id' => $id,
            'error' => $e->getMessage(),
        ]);

        return redirect()
            ->back()
            ->with('error', 'Pharmacy Prescription not found.');

    } catch (\Exception $e) {
        // Catch any unexpected error
        Log::error('Unexpected error while updating Pharmacy Prescription.', [
            'prescription_id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()
            ->back()
            ->with('error', 'An unexpected error occurred while updating the prescription.');
    }
}


public function update2(Request $request, $id)
{
    try {
        // Validate request input
        $request->validate([
            'delivery_address' => 'required|string',
        ]);

        // Try to find the record
        $pharmacyPrescription = pprescription::findOrFail($id);

        // Update the record
        $pharmacyPrescription->delivery_address = $request->delivery_address;
        $pharmacyPrescription->save();

       

        // Also log in Laravel’s storage logs
        Log::info('Pharmacy Prescription address updated successfully.', [
            'user_id' => Auth::id(),
            'prescription_id' => $id,
            'new_address' => $request->delivery_address,
        ]);

        return redirect()
            ->route('pharmacy-prescriptions2.index')
            ->with('success', 'Prescription updated successfully.');

    } catch (ModelNotFoundException $e) {
        // Log not found errors
        Log::error('Pharmacy Prescription not found during update.', [
            'prescription_id' => $id,
            'error' => $e->getMessage(),
        ]);

        return redirect()
            ->back()
            ->with('error', 'Pharmacy Prescription not found.');

    } catch (\Exception $e) {
        // Catch any unexpected error
        Log::error('Unexpected error while updating Pharmacy Prescription.', [
            'prescription_id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()
            ->back()
            ->with('error', 'An unexpected error occurred while updating the prescription.');
    }
}



public function store2(Request $request)
{
    try {

        $request->validate([
            'name'             => 'required|string|max:255',
            'payment_method'   => 'required|string',
            'amount'           => 'required|numeric',
            'prescription'     => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'assigned_user'    => 'required|exists:users,id',
            'delivery_date'    => 'required|date',
            'delivery_address' => 'required|string',
        ]);


        $prescriptionPaths = [];

        if ($request->hasFile('prescription')) {
            $file = $request->file('prescription');
            $path = $file->store('prescriptions', 'public');
            $prescriptionPaths[] = $path;
        }


        $prescription = pprescription::create([
            'name'             => $request->name,
            'pharmacy_id'      => Auth::user()->login_id2,
            'user_id'          => Auth::id() ?? 1,
            'payment_method'   => $request->payment_method,
            'total_amount'     => $request->amount,
            'prescription'     => json_encode($prescriptionPaths),
            'delivery_id'      => $request->assigned_user,
            'expect_date'      => $request->delivery_date,
            'delivery_address' => $request->delivery_address,
            'status'           => 3,
            'lat_long'         => '11.2352648,76.0522042',
        ]);

       
        Log::info('Pharmacy prescription created successfully.', [
            'prescription_id' => $prescription->id,
            'user_id' => Auth::id(),
            'pharmacy_id' => Auth::user()->login_id2,
            'data' => $request->all(),
        ]);

        return redirect()
            ->route('pharmacy-prescriptions2.index')
            ->with('success', 'Pharmacy prescription saved successfully!')
            ->with('status_filter', 3);

    } catch (Exception $e) {

        Log::error('Database error while creating pharmacy prescription.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()
            ->back()
            ->withInput()
            ->with('error', 'Database error occurred while saving the prescription.');

    } catch (\Illuminate\Validation\ValidationException $e) {
        // Validation errors already handled automatically, but log them
        Log::warning('Validation failed while creating pharmacy prescription.', [
            'errors' => $e->errors(),
            'input' => $request->all(),
        ]);

        throw $e; // rethrow to show validation messages on UI

    } catch (\Exception $e) {
        // Any other unexpected errors
        Log::error('Unexpected error while creating pharmacy prescription.', [
            'user_id' => Auth::id(),
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()
            ->back()
            ->withInput()
            ->with('error', 'An unexpected error occurred while saving the prescription.');
    }
}



public function pharmacyPresStatus(Request $request)
{
    try {
        $query = $request->input('status');

        Log::info('Fetching pharmacy prescriptions by status.', [
            'status' => $query,
            'user_id' => Auth::id(),
        ]);

        $pPrescriptions = pprescription::where('status', '=', $query)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        $output = '';

        foreach ($pPrescriptions as $prescription) {
            $prescriptionImages = '';

            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);
                $imageUrls = array_map(function ($img) {
                    return asset('storage/' . $img);
                }, $images);

                $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                if (count($images) > 1) {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                    <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
                } else {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                    <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }

            $style = '';
            if ($prescription->payment_method == 1) {
                $style = 'background-color: lightgreen;';
            } elseif ($prescription->payment_method == 2) {
                $style = 'background-color: #fcff42;';
            }

            $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';

            $output .= '
            <td>' . htmlspecialchars($prescription->user->name ?? '-') . '</td>
            <td>' . htmlspecialchars($prescription->name ?? '-') . '</td> 
            <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name ?? '-') . '</td>
            <td>' . htmlspecialchars($prescription->user->phone_number ?? '-') . '</td>
            <td>' . $prescriptionImages . '</td>
            <td>' . htmlspecialchars($prescription->delivery_address ?? '-') . '</td>
            <td>' . htmlspecialchars($prescription->lat_long ?? '-') . '</td> 
            <td class="payment-method-th">' 
            . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
            . '</td>
            <td>' . $prescription->created_at . '</td> 
            <td>
                <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
            </tr>';
        }
    
        Log::info('Pharmacy prescriptions fetched successfully.', [
            'status' => $query,
            'count' => $pPrescriptions->count(),
        ]);

        return response()->json([
            'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);

    } catch (Exception $e) {

        Log::error('Database error while fetching pharmacy prescriptions by status.', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => 'Database error occurred while fetching prescriptions.',
        ], 500);

    } catch (\Exception $e) {
        Log::error('Unexpected error while fetching pharmacy prescriptions by status.', [
            'user_id' => Auth::id(),
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => 'An unexpected error occurred. Please try again later.',
        ], 500);
    }
}



public function pharmacyPresStatus2(Request $request)
{
    try {
        $loginId = auth()->user()->login_id2 ?? null;
        $query = $request->input('status');

        Log::info('Fetching pharmacy prescriptions (pharmacyPresStatus2) started.', [
            'pharmacy_id' => $loginId,
            'status' => $query,
            'user_id' => Auth::id(),
        ]);

        if (!$loginId) {
            Log::warning('User does not have a valid pharmacy login_id2.', ['user_id' => Auth::id()]);
            return response()->json(['error' => 'Unauthorized access.'], 403);
        }

        $pPrescriptions = pprescription::where('status', '=', $query)
            ->where('pharmacy_id', $loginId)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        $output = '';

        foreach ($pPrescriptions as $prescription) {
            $prescriptionImages = '';

            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);
                $imageUrls = array_map(function ($img) {
                    return asset('storage/' . $img);
                }, $images);

                $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                if (count($images) > 1) {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                    <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i></a>';
                } else {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                    <i class="fas fa-images" style="color: green; font-size: 20px;"></i></a>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }

            $style = '';
            if ($prescription->payment_method == 1) {
                $style = 'background-color: lightgreen;';
            } elseif ($prescription->payment_method == 2) {
                $style = 'background-color: #fcff42;';
            }

            $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';

            $output .= '
                <td>' . htmlspecialchars($prescription->user->name ?? '-') . '</td>
                <td>' . htmlspecialchars($prescription->name ?? '-') . '</td> 
                <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name ?? '-') . '</td>
                <td>' . htmlspecialchars($prescription->user->phone_number ?? '-') . '</td>
                <td>' . $prescriptionImages . '</td>
                <td>' . htmlspecialchars($prescription->delivery_address ?? '-') . '</td>
                <td>' . htmlspecialchars($prescription->lat_long ?? '-') . '</td> 
                <td class="payment-method-th">'
                . (($prescription->payment_method == 1)
                    ? 'Online Payment'
                    : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-'))
                . '</td>
                <td>' . $prescription->created_at . '</td> 
                <td>
                    <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>';
        }


        Log::info('Pharmacy prescriptions fetched successfully (pharmacyPresStatus2).', [
            'status' => $query,
            'pharmacy_id' => $loginId,
            'count' => $pPrescriptions->count(),
        ]);

        return response()->json([
            'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);

    } catch (Exception $e) {
        Log::error('Database error while fetching pharmacy prescriptions (pharmacyPresStatus2).', [
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => 'Database error occurred while fetching prescriptions.',
        ], 500);

    } catch (\Exception $e) {
        Log::error('Unexpected error in pharmacyPresStatus2.', [
            'user_id' => Auth::id(),
            'pharmacy_id' => $loginId,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => 'An unexpected error occurred. Please try again later.',
        ], 500);
    }
}


public function pharmacyPresDate(Request $request)
{
    try {
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');

        // Log the incoming request for traceability
        Log::info('Pharmacy Prescription Date Filter - Request Received', [
            'start_date' => $startDate,
            'end_date'   => $endDate,
            'user_id'    => auth()->id()
        ]);

        // Ensure dates are valid
        if (!$startDate || !$endDate) {
            throw new Exception('Start date or end date is missing.');
        }

        $pPrescriptions = pprescription::whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        $output = '';

        foreach ($pPrescriptions as $prescription) {
            $prescriptionImages = '';

            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);
                $imageUrls = array_map(fn($img) => asset('storage/' . $img), $images);
                $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                if (count($images) > 1) {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i>
                    </a>';
                } else {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;"></i>
                    </a>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }

            $style = '';
            if ($prescription->payment_method == 1) {
                $style = 'background-color: lightgreen;';
            } elseif ($prescription->payment_method == 2) {
                $style = 'background-color: #fcff42;';
            }

            $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';
            $output .= '
                <td>' . htmlspecialchars($prescription->user->name) . '</td>
                <td>' . htmlspecialchars($prescription->name) . '</td> 
                <td>' . htmlspecialchars($prescription->pharmacy->pharmacy_name) . '</td>
                <td>' . htmlspecialchars($prescription->user->phone_number) . '</td>
                <td>' . $prescriptionImages . '</td>
                <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
                <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
                <td class="payment-method-th">' 
                    . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
                . '</td>
                <td>' . $prescription->created_at . '</td> 
                <td>
                    <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>';
        }

        // Log the success
        Log::info('Pharmacy Prescription Date Filter - Success', [
            'count' => $pPrescriptions->count(),
            'user_id' => auth()->id()
        ]);

        return response()->json([
            'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);

    } catch (Exception $e) {
        // Log error details in laravel.log
        Log::error('Error in pharmacyPresDate', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
        ]);

        return response()->json([
            'error' => 'An error occurred while fetching prescriptions. Please try again later.',
        ], 500);
    }
}




public function pharmacyPresDate2(Request $request)
{
    try {
        $startDate = $request->input('start_date');
        $endDate   = $request->input('end_date');
        $loginId   = auth()->user()->login_id2;

        // Log the incoming request data
        Log::info('Pharmacy Prescription Date Filter 2 - Request received', [
            'start_date' => $startDate,
            'end_date'   => $endDate,
            'pharmacy_id' => $loginId,
            'user_id'    => auth()->id(),
        ]);

        // Validate presence of date inputs
        if (!$startDate || !$endDate) {
            throw new Exception('Start date or end date is missing.');
        }

        // Fetch prescriptions within date range for logged pharmacy
        $pPrescriptions = pprescription::where('pharmacy_id', $loginId)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        $output = '';

        foreach ($pPrescriptions as $prescription) {
            $prescriptionImages = '';

            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);
                $imageUrls = array_map(fn($img) => asset('storage/' . $img), $images);
                $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                if (count($images) > 1) {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i>
                    </a>';
                } else {
                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;"></i>
                    </a>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }

            $style = '';
            if ($prescription->payment_method == 1) {
                $style = 'background-color: lightgreen;';
            } elseif ($prescription->payment_method == 2) {
                $style = 'background-color: #fcff42;';
            }

            $output .= '<tr ' . (!empty($style) ? 'style="' . $style . '"' : '') . '>';
            $output .= '
                <td>' . htmlspecialchars(optional($prescription->user)->name ?? '-') . '</td>
                <td>' . htmlspecialchars($prescription->name) . '</td> 
                <td>' . htmlspecialchars(optional($prescription->pharmacy)->pharmacy_name ?? '-') . '</td>
                <td>' . htmlspecialchars(optional($prescription->user)->phone_number ?? '-') . '</td>
                <td>' . $prescriptionImages . '</td>
                <td>' . htmlspecialchars($prescription->delivery_address) . '</td>
                <td>' . htmlspecialchars($prescription->lat_long) . '</td> 
                <td class="payment-method-th">' 
                    . (($prescription->payment_method == 1) ? 'Online Payment' : (($prescription->payment_method == 2) ? 'Cash on Delivery' : '-')) 
                . '</td>
                <td>' . $prescription->created_at . '</td> 
                <td>
                    <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>';
        }

        // Log successful response
        Log::info('Pharmacy Prescription Date Filter 2 - Success', [
            'records_fetched' => $pPrescriptions->count(),
            'pharmacy_id' => $loginId,
            'user_id' => auth()->id(),
        ]);

        return response()->json([
            'output' => $output,
            'pagination' => $pPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);

    } catch (Exception $e) {
        // Log error details in laravel.log
        Log::error('Error in pharmacyPresDate', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
        ]);

        return response()->json([
            'error' => 'An error occurred while fetching prescriptions. Please try again later.',
        ], 500);
    }
}



public function rejected($id)
{
    try {
        // Attempt to find the prescription
        $pharmacyPrescription = pprescription::findOrFail($id);

        // Update the status to "rejected"
        $pharmacyPrescription->status = 5;
        $pharmacyPrescription->save();

        // Log the success
        Log::info('Prescription rejected successfully', [
            'prescription_id' => $id,
            'updated_status' => 5,
            'user_id' => auth()->id(),
            'timestamp' => now(),
        ]);

        return back()->with('success', 'Prescription rejected successfully.');

    } catch (Exception $e) {
        Log::error('Prescription not found for rejection', [
            'prescription_id' => $id,
            'error_message' => $e->getMessage(),
            'user_id' => auth()->id(),
            'timestamp' => now(),
        ]);

        return back()->with('error', 'Prescription not found.');

    } 
}

    
}

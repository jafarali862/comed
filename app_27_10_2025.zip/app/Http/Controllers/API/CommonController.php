<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Clinic;
use App\Models\User;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use App\Models\ClinicPrescription;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\PharmacyPrescription;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\JsonResponse;


class CommonController extends Controller
{
    public function pharmacyLister()
{
    try {
        $userId = Auth::id();

        $pharmacies = Pharmacy::with(['prescriptions' => function ($query) use ($userId) {
            $query->select(
                'pharmacy_id',
                DB::raw("
                    MAX(
                        CASE 
                            WHEN status = 1
                                 AND user_id = {$userId}
                                 AND (total_amount IS NOT NULL AND TRIM(total_amount) != '')
                                 AND receipt = '1'
                            THEN 1 ELSE 0 
                        END
                    ) as med_status
                ")
            )->groupBy('pharmacy_id');
        }])
        ->select(
            'id',
            'pharmacy_name',
            'pharmacy_address',
            'pharmacy_photo',
            'city',
            'email',
            'phone_number',
            'account_holder_name',
            'account_no',
            'ifsc',
            'upi',
            'qr_code'
        )
        ->get()
        ->map(function ($pharmacy) {
            $pharmacy->med_status = optional($pharmacy->prescriptions->first())->med_status ?? 0;
            unset($pharmacy->prescriptions);
            return $pharmacy;
        });

        return response()->json(['pharmacys' => $pharmacies]);

    } catch (Exception $e) {
        // Log the full exception message and trace
        Log::error('Pharmacy list fetch error: ' . $e->getMessage(), [
            'trace' => $e->getTraceAsString(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);

        return response()->json([
            'message' => 'Something went wrong, please try again later.',
            'error' => $e->getMessage(),
        ], 500);
    }
}

    public function clinicLister()
    {
        try {
            $clinics = Clinic::all();
            return response()->json(['clinics' => $clinics]);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

   
    public function pPrescription(Request $request)
    {

        try 
        {
            $request->validate([
                'user_id' => 'required|exists:users,id',
                'name' => 'required|string',
                'pharmacy_id' => 'required|integer',
                'prescription.*' => 'required|image',
                'delivery_address' => 'required|string',
                'lat_long' => 'required|string',
                'payment_method' => 'required|string',
                'customer_message'=>'nullable|string'
            ]);
    
            $prescriptionPaths = [];
            foreach ($request->file('prescription') as $file) {
                $prescriptionPaths[] = $file->store('prescriptions', 'public');
            }
    
            $prescription = PharmacyPrescription::create([
                'user_id' => $request->user_id,
                'name' => $request->name,
                'pharmacy_id' => $request->pharmacy_id,
                'prescription' => json_encode($prescriptionPaths),
                'delivery_address' => $request->delivery_address,
                'payment_method' => $request->payment_method,
                'lat_long' => $request->lat_long,
                'customer_message' => $request->customer_message,
            ]);
    
            $user = \App\Models\User::find($request->user_id);
    
            if ($user && $user->phone_number) 
            {

                $orderId = 'ORD' . str_pad($prescription->id, 5, '0', STR_PAD_LEFT); 
                $templateMessage = "Thanks for your order on CoMed. We've received your medicine order ID: $orderId and will notify you once it's processed. Areacode SCB";
    
                $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                    
                    'username'    => 'ascbcomed',
                    'password'    => 'Comed@123',
                    'mobile'      => $user->phone_number,
                    'message'     => $templateMessage,
                    'sendername'  => 'ARDSCB',
                    'routetype'   => 1,
                    'tid'         => '1207175446449105383', 
                    'var1'        => $orderId,
                ]);

                Log::info('Pharmacy SMS sent: ' . $response->body());

            }
    
            return response()->json(['success' => 'Prescription added successfully.'], 200);
        } 

        catch (Exception $e) 
        {
            Log::error('Pharmacy prescription error: ' . $e->getMessage());
    
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }   
    }

    public function clinicData()
    {
    try {
        $userId = Auth::id();

        $deliverRequest = ClinicPrescription::with(['user:id,phone_number'])
            ->where('delivery_id', $userId)
            ->whereIn('status', [0,1,2,3,4,5])
            ->select(
                'id',
                'name as customer_name',
                'user_id',
                'lat_long as deliv_coordinates',
                'address as deliv_address',
                'otp',
                'status',
                'test',
                DB::raw('updated_at as updated_at_str')
            )
            ->get()
            ->map(function ($item) {
                return [
                    'id'               => $item->id,
                    'customer_name'    => $item->customer_name,
                    'phone_number'     => $item->user->phone_number ?? null,
                    'deliv_coordinates'=> $item->deliv_coordinates,
                    'deliv_address'    => $item->deliv_address,
                    'otp'              => $item->otp,
                    'status'           => $item->status,
                    'test'             => $item->test,
                    'updated_at_str'   => $item->updated_at_str,
                ];
            });

        return response()->json(['clincData' => $deliverRequest]);

    } catch (Exception $e) {
        // Log the exception to storage/logs/laravel.log
        Log::error('Clinic Data Fetch Error: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => true,
            'message' => 'Something went wrong while fetching clinic data.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

   public function pharmacyData()
    {
    try {
        $userId = Auth::id();

        $deliverRequest = PharmacyPrescription::with([
                'user:id,phone_number',
                'pharmacy:id,qr_code,upi'
            ])
            ->where('delivery_id', $userId)
            ->whereIn('status', [3, 4])
            ->select(
                'id',
                'name',
                'user_id',
                'lat_long as deliv_coordinates',
                'status',
                'delivery_address',
                'payment_method',
                'expect_date',
                'total_amount',
                'pharmacy_id',
                DB::raw('updated_at as updated_at_str')
            )
            ->get()
            ->map(function ($item) {
                return [
                    'id'               => $item->id,
                    'name'             => $item->name,
                    'phone_number'     => $item->user->phone_number ?? null,
                    'deliv_coordinates'=> $item->deliv_coordinates,
                    'status'           => $item->status,
                    'delivery_address' => $item->delivery_address,
                    'payment_method'   => $item->payment_method,
                    'expect_date'      => $item->expect_date,
                    'total_amount'     => $item->total_amount,
                    'qr_code'          => $item->pharmacy->qr_code ?? null,
                    'upi'              => $item->pharmacy->upi ?? null,
                    'updated_at_str'   => $item->updated_at_str,
                ];
            });

        return response()->json(['pharamcyData' => $deliverRequest]);

    } catch (Exception $e) {
        Log::error('Pharmacy Data Fetch Error: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => true,
            'message' => 'Something went wrong while fetching pharmacy data.',
            'details' => $e->getMessage(),
        ], 500);
    }
}


    public function sendOtpToPhone(Request $request)
    {
    try {
        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|digits_between:10,15',
            'id'           => 'required|exists:pharmacy_prescriptions,id',
        ]);

        if ($validator->fails()) {
            Log::warning('OTP request failed validation', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = User::where('phone_number', $request->phone_number)->first();
        if (!$user) {
            Log::info('OTP request failed: phone number not registered', [
                'phone_number' => $request->phone_number
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Mobile number not registered.',
            ], 404);
        }

        $otp   = rand(1000, 9999);
        $refId = rand(1000, 9999);

        $user->update([
            'otp'            => $otp,
            'otp_ref_id'     => $refId,
            'otp_expires_at' => now()->addMinutes(5),
        ]);

        $pharmacyPrescription = PharmacyPrescription::find($request->id);
        if (!$pharmacyPrescription || $pharmacyPrescription->user_id !== $user->id) {
            Log::warning('OTP request failed: prescription not found or mismatched user', [
                'user_id'         => $user->id,
                'prescription_id' => $request->id,
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Prescription not found or does not belong to this user.',
            ], 404);
        }

        $orderId        = 'ORD' . str_pad($pharmacyPrescription->id, 5, '0', STR_PAD_LEFT);
        $templateId     = '1207175446609878410';
        $templateMessage = "Your OTP for confirming pharmacy order ID: $orderId delivery is $otp. Please share this with our delivery agent to complete the delivery. Areacode SCB";

        $smsPayload = [
            'username'   => 'ascbcomed',
            'password'   => 'Comed@123',
            'mobile'     => $user->phone_number,
            'message'    => $templateMessage,
            'sendername' => 'ARDSCB',
            'routetype'  => 1,
            'tid'        => $templateId,
            'var1'       => $orderId,
            'var2'       => $otp,
        ];

        $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', $smsPayload);

        Log::info('Pharmacy OTP SMS sent attempt', [
            'mobile'   => $user->phone_number,
            'order_id' => $orderId,
            'status'   => $response->status(),
            'response' => $response->body(),
        ]);


        if (str_contains($response->body(), 'Sent Successfully')) {
            $pharmacyPrescription->update([
                'status' => 4,
                'otp'    => $otp,
            ]);

            Log::info('OTP sent successfully', [
                'order_id' => $orderId,
                'otp'      => $otp,
                'user_id'  => $user->id,
            ]);

            return response()->json([
                'success'  => true,
                'message'  => 'OTP sent successfully. Please verify to continue.',
                'otp'      => $otp,
                'order_id' => $orderId,
            ]);
        }

        Log::error('SMS sending failed', [
            'response_body' => $response->body(),
            'payload'       => $smsPayload,
        ]);

        return response()->json([
            'success'      => false,
            'message'      => 'Failed to send OTP.',
            'api_response' => $response->body(),
        ], 500);

    } catch (Exception $e) {

        Log::error('Unexpected error in sendOtpToPhone', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'line'  => $e->getLine(),
            'file'  => $e->getFile(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while sending OTP.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}
   
public function sendOtpToPhoneclinic(Request $request)
{
    try {
        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|digits_between:10,15',
            'id'           => 'required|exists:clinic_prescriptions,id',
        ]);

        if ($validator->fails()) {
            Log::warning('Clinic OTP validation failed', ['errors' => $validator->errors()]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = User::where('phone_number', $request->phone_number)->first();
        if (!$user) {
            Log::info('Clinic OTP failed: phone number not registered', [
                'phone_number' => $request->phone_number
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Mobile number not registered.'
            ], 404);
        }

        $otp   = rand(1000, 9999);
        $refId = rand(1000, 9999);

        $user->update([
            'otp'            => $otp,
            'otp_ref_id'     => $refId,
            'otp_expires_at' => now()->addMinutes(5),
        ]);

        $clinicPrescription = ClinicPrescription::find($request->id);
        if (!$clinicPrescription || $clinicPrescription->user_id !== $user->id) {
            Log::warning('Clinic OTP failed: prescription not found or mismatched user', [
                'user_id'         => $user->id,
                'prescription_id' => $request->id,
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Clinic prescription not found or does not belong to this user.'
            ], 404);
        }

        $orderId = 'CP' . str_pad($clinicPrescription->id, 5, '0', STR_PAD_LEFT);
        $templateId = '1207175446753325392';
        $templateMessage = "Your OTP for confirming sample collection Test ID: $orderId is $otp. Please provide this to our agent to verify your pickup. Areacode SCB";

        $smsPayload = [
            'username'   => 'ascbcomed',
            'password'   => 'Comed@123',
            'mobile'     => $user->phone_number,
            'message'    => $templateMessage,
            'sendername' => 'ARDSCB',
            'routetype'  => 1,
            'tid'        => $templateId,
            'var1'       => $orderId,
            'var2'       => $otp,
        ];

        $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', $smsPayload);

        Log::info('Clinic OTP SMS send attempt', [
            'mobile'   => $user->phone_number,
            'order_id' => $orderId,
            'status'   => $response->status(),
            'response' => $response->body(),
        ]);

        if (str_contains($response->body(), 'Sent Successfully')) {
            $clinicPrescription->update([
                'status' => 4,
                'otp'    => $otp,
            ]);

            Log::info('Clinic OTP sent successfully', [
                'order_id' => $orderId,
                'otp'      => $otp,
                'user_id'  => $user->id,
            ]);

            return response()->json([
                'success'  => true,
                'message'  => 'OTP sent successfully. Please verify to continue.',
                'otp'      => $otp,
                'order_id' => $orderId,
            ]);
        }

        Log::error('Clinic OTP SMS failed', [
            'response_body' => $response->body(),
            'payload'       => $smsPayload,
        ]);

        return response()->json([
            'success'      => false,
            'message'      => 'Failed to send OTP.',
            'api_response' => $response->body(),
        ], 500);

    } catch (Exception $e) {
        Log::error('Unexpected error in sendOtpToPhoneclinic', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'file'  => $e->getFile(),
            'line'  => $e->getLine(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while sending OTP.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}


    public function clinicDataCompleted(Request $request, $id)
    {
        try {
       
            $validator = Validator::make($request->all(), [
                'delivery_coordinates' => 'required',
                'otp' => 'required|digits:4',
                // 'status' => 'required',
            ]);
    
            if ($validator->fails()) 
            {
                return response()->json([
                    'status' => false,
                    'errors' => $validator->errors()
                ], 422);
            }

            $prescriptions = ClinicPrescription::where('id', $id)->get();
    
            if ($prescriptions->isEmpty())
            {
                return response()->json([
                    'status' => false,
                    'message' => 'No delivery records found.',
                ], 404);
            }
    
            // Check if any record matches the OTP
            // $matched = false;
            foreach ($prescriptions as $prescription) 
            {
                // if ($prescription->otp === $request->otp) {
                    $prescription->update([
                        'status' => 2,
                        'lat_long' => $request->delivery_coordinates,
                        'otp' => $request->otp,
                        'updated_at' => now()
                    ]);
                    // $matched = true;
                // }
            }
    
            // if (!$matched) {
            //     return response()->json([
            //         'status' => false,
            //         'message' => 'Invalid OTP.',
            //     ], 400);
            // }
    
            return response()->json([
                'status' => true,
                'message' => 'Delivery Completed Successfully.',
            ]);
    
        } catch (\Exception $e) {
            return response()->json([
                'error' => true,
                'message' => $e->getMessage(),
            ], 500);
        }
    }



   public function clinicDataCompletednew(Request $request, $id)
{
    try {
        $validator = Validator::make($request->all(), [
            'delivery_coordinates'  => 'required',
            'otp'                   => 'required|digits:4',
            'phone_number'          => 'required|digits_between:10,15',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Check if user exists
        $user = User::where('phone_number', $request->phone_number)->first();
        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Mobile number not registered.'
            ], 404);
        }

        // Find prescription
        $prescription = ClinicPrescription::find($id);
        if (!$prescription) {
            return response()->json([
                'status' => false,
                'message' => 'No delivery records found.',
            ], 404);
        }

        // ✅ Validate OTP with prescription table
        if ($prescription->otp !== $request->otp) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid OTP for this delivery.',
            ], 403);
        }

        // ✅ OTP matches → update delivery status
        $prescription->status               = 2;
        $prescription->delivery_coordinates = $request->delivery_coordinates;
        $prescription->updated_at           = now();
        $prescription->save();

        // Reset user OTP details
        $user->otp = null;
        $user->otp_ref_id = null;
        $user->otp_expires_at = null;
        $user->save();

        // ✅ Success response only after successful update
        return response()->json([
            'status' => true,
            'message' => 'Delivery Completed Successfully.',
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'error' => true,
            'message' => $e->getMessage(),
        ], 500);
    }
}
    
        public function pMedicines(Request $request)
        {

        try 
        { 
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer',
            'pharmacy_id' => 'required|integer',
        ]);

        if ($validator->fails()) 
        {
            return response()->json([
                'status' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $prescription = PharmacyPrescription::where('user_id', $request->user_id)
            ->where('pharmacy_id', $request->pharmacy_id)
            ->latest()
            ->first();

        if (!$prescription) 
        {
            return response()->json([
                'status' => false,
                'message' => 'No prescription found for this user and pharmacy.'
            ], 404);
        }

        $prescriptionDetails = PharmacyPrescription::where('id', $prescription->id)
            ->select('id', 'expect_date', 'payment_method', 'total_amount')
            ->first();

        return response()->json([
            'status' => true,
            'message' => 'Prescription Details Retrieved Successfully.',
            'data' => $prescriptionDetails
        ], 200);

        } 

        catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'message' => 'An error occurred.',
            'error' => $e->getMessage()
        ], 500);
        }
        }


    public function cPrescription(Request $request)
    {
 
        try 
        {
            $request->validate([
                'user_id' => 'required|integer',
                'name' => 'required|string',
                'age' => 'required|integer',
                'gender' => 'required',
                'clinic_id' => 'required|integer',
                'prescription.*' => 'nullable|image',
                'test.*' => 'nullable|string',
                'address' => 'required|string',
                'lat_long' => 'nullable|string',
                'from_time' => 'nullable|string',
                'to_time' => 'nullable|string',
                'scheduled_at' => 'required',
                 'test_total' => 'nullable|string',
            ]);
        
            $prescriptionPaths = [];
            if ($request->hasFile('prescription')) {
                foreach ($request->file('prescription') as $file) {
                    $prescriptionPaths[] = $file->store('clinic_prescriptions', 'public');
                }
            }
        
            $prescription = ClinicPrescription::create([
                'user_id'       => $request->user_id,
                'clinic_id'     => $request->clinic_id,
                'name'          => $request->name,
                'age'           => $request->age,
                'from_time'     => $request->from_time,
                'to_time'       => $request->to_time,
                'gender'        => $request->gender,
                'prescription'  => json_encode($prescriptionPaths),
                'test'          => json_encode($request->test),
                'address'       => $request->address,
                'scheduled_at'  => $request->scheduled_at,
                'lat_long'      => $request->lat_long,
                 'test_total'      => $request->test_total,
            ]);
        
            $user = User::find($request->user_id);
            $clinic = Clinic::find($request->clinic_id);
            $clinicName = $clinic->clinic_name ?? 'Clinic';
        
            if ($user && $user->phone_number)      
            {
               
                $clinicPrescriptionId = 'CP' . str_pad($prescription->id, 5, '0', STR_PAD_LEFT);       
                $templateMessage = "Thank you for booking a sample collection on $clinicName for Test ID: $clinicPrescriptionId. We appreciate you choosing COMED. Areacode SCB";
        
                $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                    'username'    => 'ascbcomed',
                    'password'    => 'Comed@123',
                    'mobile'      => $user->phone_number,
                    'message'     => $templateMessage,
                    'sendername'  => 'ARDSCB',
                    'routetype'   => 1,
                    'tid'         => '1207175584362105164',
                    'var1'        => $clinicName,
                    'var2'        => $clinicPrescriptionId,
                    'var3'        => 'CoMed',
                ]);

                Log::info('Attempting to send SMS to user', [
                    'mobile' => $user->phone_number,
                    'clinic_id' => $request->clinic_id,
                    'clinicPrescriptionId' => $clinicPrescriptionId,
                    'message_sent' => $templateMessage,
                    'sms_api_status' => $response->status(),
                    'sms_api_response' => $response->body(),
                ]);

            } 


            else 
            {
                Log::warning('User or user phone number not found', [
                    'user_id' => $request->user_id,
                    'phone_number' => $user->phone_number ?? null,
                ]);
            }
        
            return response()->json(['success' => 'Prescriptions added successfully.'], 200);
        } catch (\Exception $e) {
            Log::error('Prescription error: ' . $e->getMessage());
        
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
        
    }

   public function getPrescriptions(Request $request, $userId)
{
    try {
        // Check authentication
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        // Check if the logged-in user is accessing their own prescriptions
        if ((int)$userId !== $authenticatedUserId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.'
            ], 403);
        }

        // Fetch prescriptions with related clinic data (via Eloquent relationship)
        $prescriptions = ClinicPrescription::with('clinic')
            ->where('user_id', $userId)
            ->get()
            ->map(function ($prescription) {
                return [
                    'id'           => $prescription->id,
                    'name'         => $prescription->name,
                    'clinic_id'    => $prescription->clinic_id,
                    'clinic_name'  => optional($prescription->clinic)->clinic_name, // safe null handling
                    'address'      => $prescription->address,
                    'age'          => $prescription->age,
                    'gender'       => $prescription->gender,
                    'test'         => $prescription->test,
                    'from_time'    => $prescription->from_time,
                    'to_time'      => $prescription->to_time,
                    'prescription' => $prescription->prescription,
                    'pres_upload'  => $prescription->pres_upload,
                    'status'       => $prescription->status,
                    'date'         => optional($prescription->scheduled_at)->format('Y-m-d'),
                ];
            });

        return response()->json([
            'success' => true,
            'data'    => $prescriptions,
        ], 200);

    } catch (\Exception $e) {
        Log::error('Error fetching prescriptions', [
            'user_id' => $userId,
            'error'   => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong, please try again later.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}



 public function getpharmacyPrescriptions(Request $request, $userId)
{
    try {

        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();


        if ((int)$userId !== $authenticatedUserId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.'
            ], 403);
        }


        $prescriptions = PharmacyPrescription::with(['pharmacy', 'payment'])
            ->where('user_id', $userId)
            ->get()
            ->map(function ($prescription) {
                return [
                    'id'                => $prescription->id,
                    'name'              => $prescription->name,
                    'payment_ref_no'    => optional($prescription->payment)->ref_no,
                    'pharmacy_name'     => optional($prescription->pharmacy)->pharmacy_name,
                    'pharmacy_id'       => $prescription->pharmacy_id,
                    'delivery_address'  => $prescription->delivery_address,
                    'prescription'      => $prescription->prescription,
                    'lat_long'          => $prescription->lat_long,
                    'payment_method'    => $prescription->payment_method,
                    'total_amount'      => $prescription->total_amount,
                    'delivery_id'       => $prescription->delivery_id,
                    'status'            => $prescription->status,
                    'date'              => optional($prescription->expect_date)->format('Y-m-d'),
                ];
            });


        return response()->json([
            'success' => true,
            'data'    => $prescriptions,
        ], 200);

    } catch (\Exception $e) {

        Log::error('Error fetching pharmacy prescriptions', [
            'user_id' => $userId,
            'error'   => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong, please try again later.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}



     public function updatePrescription(Request $request, $userId, $prescriptionId)
{
    try {
        // ✅ Step 1: Authentication check
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        // ✅ Step 2: Authorization check
        if ((int)$userId !== $authenticatedUserId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.'
            ], 403);
        }

        // ✅ Step 3: Validate incoming request
        $validated = $request->validate([
            'from_time'     => 'nullable|string',
            'to_time'       => 'nullable|string',
            'prescription'  => 'nullable|string',
            'status'        => 'nullable|string',
            'scheduled_at'  => 'nullable|date'
        ]);

        // ✅ Step 4: Find the prescription using Eloquent
        $prescription = ClinicPrescription::where('id', $prescriptionId)
            ->where('user_id', $userId)
            ->first();

        if (!$prescription) {
            return response()->json([
                'success' => false,
                'message' => 'Prescription not found.'
            ], 404);
        }

        // ✅ Step 5: Filter only provided fields (avoid null updates)
        $dataToUpdate = collect($validated)->filter(function ($value) {
            return !is_null($value);
        })->toArray();

        if (empty($dataToUpdate)) {
            return response()->json([
                'success' => false,
                'message' => 'No valid fields provided for update.'
            ], 400);
        }

        // ✅ Step 6: Perform update
        $prescription->update($dataToUpdate);

        // ✅ Step 7: Return success response
        return response()->json([
            'success' => true,
            'message' => 'Prescription updated successfully.',
            'updated_data' => $dataToUpdate
        ], 200);

    } catch (\Illuminate\Validation\ValidationException $e) {
        // Specific catch for validation errors
        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'errors'  => $e->errors()
        ], 422);

    } catch (\Exception $e) {
        // Generic catch for all other exceptions
        Log::error('Error updating clinic prescription', [
            'user_id' => $userId,
            'prescription_id' => $prescriptionId,
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong. Please try again later.',
            'error'   => $e->getMessage()
        ], 500);
    }
}


    public function pCashDelivery(Request $request)
{
    try {
        if (!Auth::check()) {
            return response()->json(['error' => 'User not authenticated. Please login.'], 401);
        }

        $userId = Auth::id();

        $validated = $request->validate([
            'id'             => 'required|integer',
            'total_amount'   => 'required|numeric',
            'payment_method' => 'required|in:1,2',
        ]);

        $prescription = PharmacyPrescription::where('id', $validated['id'])
                            ->where('user_id', $userId)
                            ->first();

        if (!$prescription) 
        {
        return response()->json(['error' => 'Prescription not found or unauthorized.'], 403);
        }

        $prescription->update([
            'status'         => 2,
            'payment_method' => $validated['payment_method'],
            'total_amount'   => $validated['total_amount'],
            'updated_at'     => now(),
        ]);

        $updatedData = PharmacyPrescription::find($prescription->id, [
            'id',
            'total_amount',
            'payment_method',
            'status'
        ]);

        return response()->json([
            'message' => 'Updated successfully.',
            'data'    => $updatedData
        ], 200);
    } 
    catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'error' => 'Validation failed',
            'messages' => $e->errors()
        ], 422);
    } 
    catch (\Exception $e) {
        Log::error('pCashDelivery error: ' . $e->getMessage());
        return response()->json([
            'message' => 'Something went wrong, please try again later.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}

    
public function updatePaymentMethod(Request $request, $id)
{
    try {
        if (!Auth::check()) {
            return response()->json([
                'error' => 'User not authenticated. Please login.'
            ], 401);
        }

        $userId = Auth::id();

        $validated = $request->validate([
            'payment_method' => 'required|in:1,2',
        ]);

        $prescription = PharmacyPrescription::where('id', $id)
                            ->where('user_id', $userId)
                            ->first();

        if (!$prescription) {
            return response()->json([
                'error' => 'Prescription not found or unauthorized access.'
            ], 404);
        }

        $prescription->update([
            'payment_method' => $validated['payment_method'],
            'updated_at'     => now(),
        ]);

        return response()->json([
            'message'         => 'Payment method updated successfully.',
            'payment_method'  => $prescription->payment_method,
        ], 200);

    } 
    catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'error'    => 'Validation failed',
            'messages' => $e->errors(),
        ], 422);
    } 
    catch (\Exception $e) {
        Log::error('updatePaymentMethod error: ' . $e->getMessage());
        return response()->json([
            'error'   => 'An error occurred while updating payment method.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

public function updateAccountData(Request $request, $id)
{
    try {
        if (!Auth::check()) {
            return response()->json([
                'error' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        $validated = $request->validate([
            'contact_number' => 'required|string|max:20',
            'account_no'     => 'required|string|max:50',
        ]);

        $user = User::find($id);

        if (!$user || $user->id !== $authenticatedUserId) {
            return response()->json([
                'error' => 'Unauthorized access.'
            ], 403);
        }

        $user->update([
            'contact_number' => $validated['contact_number'],
            'account_no'     => $validated['account_no'],
        ]);

        return response()->json([
            'message' => 'Account updated successfully.',
            'data'    => [
                'contact_number' => $user->contact_number,
                'account_no'     => $user->account_no,
            ]
        ], 200);
    } 

    catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'error'    => 'Validation failed.',
            'messages' => $e->errors(),
        ], 422);
    } 

    catch (\Exception $e) {
        Log::error('updateAccountData error: ' . $e->getMessage());
        return response()->json([
            'error'   => 'An error occurred while updating the account.',
            'details' => $e->getMessage(),
        ], 500);
    }
}


public function receiptPrescription(Request $request, $user_id, $pres_id)
{
    try {
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        if ((int)$user_id !== $authenticatedUserId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.'
            ], 403);
        }

        $validated = $request->validate([
            'receipt'      => 'nullable|image|max:2048', // optional image
            'total_amount' => 'required|numeric|min:0',
        ]);

        $pharmacyPres = PharmacyPrescription::where('id', $pres_id)
            ->where('user_id', $user_id)
            ->first();

        if (!$pharmacyPres) {
            return response()->json([
                'success' => false,
                'message' => 'Prescription record not found for this user.',
            ], 404);
        }

        if ($request->hasFile('receipt')) {
            $receiptFile = $request->file('receipt');

            if (!$receiptFile->isValid()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Uploaded file is not valid.',
                ], 400);
            }

            $receiptPath = $receiptFile->store('prescriptions', 'public');
            $pharmacyPres->receipt = $receiptPath;
        }

        $pharmacyPres->total_amount = $validated['total_amount'];
        $pharmacyPres->save();

        return response()->json([
            'success' => true,
            'message' => 'Receipt data updated successfully.',
            'data'    => [
                'receipt'      => $pharmacyPres->receipt ? asset('storage/' . $pharmacyPres->receipt) : null,
                'total_amount' => $pharmacyPres->total_amount,
                'created_at'   => $pharmacyPres->created_at->format('Y-m-d H:i:s'),
                'updated_at'   => $pharmacyPres->updated_at->format('Y-m-d H:i:s'),
            ],
        ], 200);
    } 

    catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'errors'  => $e->errors(),
        ], 422);
    } 

    catch (\Exception $e) {
        Log::error('receiptPrescription error: ' . $e->getMessage());
        return response()->json([
            'success' => false,
            'message' => 'Something went wrong. Please try again later.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}


    public function getAccountData($id)
    {
    try {
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        $user = User::select('id', 'name', 'email', 'contact_number', 'account_no')->find($id);

        if (!$user || $user->id !== $authenticatedUserId) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.'
            ], 403);
        }


        return response()->json([
            'success' => true,
            'message' => 'User account data fetched successfully.',
            'data'    => $user
        ], 200);
    } 

    catch (\Illuminate\Validation\ValidationException $e) {
        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'errors'  => $e->errors(),
        ], 422);
    } 

    catch (\Exception $e) {
        Log::error('getAccountData error: ' . $e->getMessage());
        return response()->json([
            'success' => false,
            'message' => 'Failed to fetch account data. Please try again later.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}


       public function cancelPharMedicine($id)
{
    try {
        if (!Auth::check()) {
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated. Please login.'
            ], 401);
        }

        $authenticatedUserId = Auth::id();

        DB::beginTransaction();

        $prescription = PharmacyPrescription::where('id', $id)
            ->where('user_id', $authenticatedUserId)
            ->first();

        if (!$prescription) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Prescription not found or unauthorized access.'
            ], 404);
        }

        $prescription->forceDelete();

        DB::commit();

        return response()->json([
            'success' => true,
            'message' => 'Prescription cancelled successfully.'
        ], 200);
    } 
    catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        DB::rollBack();
        return response()->json([
            'success' => false,
            'message' => 'Prescription record not found.'
        ], 404);
    } 
    catch (\Exception $e) {
        DB::rollBack();
        Log::error('cancelPharMedicine error: ' . $e->getMessage());

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong. Please try again later.',
            'error'   => $e->getMessage()
        ], 500);
    }
}



   public function getTestsByClinicId($clinic_id): JsonResponse
{
    try {

        $clinic = Clinic::with('tests')->find($clinic_id);

        if (!$clinic) {
            return response()->json([
                'status' => false,
                'error' => 'Clinic not found.'
            ], 404);
        }

        $formatted = $clinic->tests->map(function ($test) {
            return [
                'test_name'   => $test->test_name,
                'amount'      => $test->amount,
                'description' => $test->description,
            ];
        });

        return response()->json([
            'status'      => true,
            'clinic_id'   => $clinic->id,
            'clinic_name' => $clinic->clinic_name,
            'tests'       => $formatted
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'status' => false,
            'error' => $e->getMessage()
        ], 500);
    }
}


}

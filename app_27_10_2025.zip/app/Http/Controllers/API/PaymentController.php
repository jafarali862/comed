<?php

namespace App\Http\Controllers\API;

use Exception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\PharmacyPrescription;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
  public function paymentConformed(Request $request, $user_id, $pres_id)
{
    try {
        // ✅ Step 1: Validate input
        $validator = Validator::make($request->all(), [
            'status'       => 'required|string|max:50',
            'ref_no'       => 'required|string|max:100',
            'message'      => 'required|string|max:255',
            'trans_status' => 'nullable|string|max:50',
            'accno'        => 'nullable|string|max:50',
            'amount'       => 'nullable|numeric|min:0',
            'remark'       => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        DB::beginTransaction();

        // ✅ Step 2: Create new payment record
        $payment = Payment::create([
            'pres_id'      => $pres_id,
            'status'       => $request->status,
            'ref_no'       => $request->ref_no,
            'message'      => $request->message,
            'trans_status' => $request->trans_status,
            'accno'        => $request->accno,
            'amount'       => $request->amount,
            'remark'       => $request->remark,
        ]);

        // ✅ Step 3: Update related pharmacy prescription status (if transaction success)
        $pharmacyPres = PharmacyPrescription::find($pres_id);

        if (!$pharmacyPres) {
            DB::rollBack();
            return response()->json([
                'status'  => false,
                'message' => 'Prescription not found.'
            ], 404);
        }

        if ($request->trans_status === 'success') {
            $pharmacyPres->status = 2; // Example: 2 = Paid
            $pharmacyPres->save();
        }

        DB::commit();

        return response()->json([
            'status'  => true,
            'message' => 'Payment recorded successfully.',
            'data'    => $payment
        ], 201);

    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'error'   => true,
            'message' => 'Something went wrong while processing payment.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

    public function paymentHistory($user_id)
    {
        try {
    
        $paymentHistory = Payment::whereHas('prescription', function ($query) use ($user_id) {
                $query->where('user_id', $user_id);
            })
            ->with([
                'prescription:id,pharmacy_id',
                'prescription.pharmacy:id,pharmacy_name'
            ])
            ->get()
            ->map(function ($payment) {
                return [
                    'payment_status' => $payment->status,
                    'payment_ref_no' => $payment->ref_no,
                    'payment_amount' => $payment->amount,
                    'payment_date'   => $payment->created_at->format('Y-m-d H:i:s'),
                    'pharmacy_name'  => $payment->prescription->pharmacy->pharmacy_name ?? 'N/A',
                ];
            });

        return response()->json([
            'success' => true,
            'data'    => $paymentHistory
        ], 200);

         } 
         catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Failed to fetch payment history.',
            'error'   => $e->getMessage(),
        ], 500);
    }
    }

}

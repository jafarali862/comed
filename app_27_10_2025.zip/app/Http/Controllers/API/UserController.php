<?php
namespace App\Http\Controllers\API;

use Exception;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    public function register(Request $request)
    {

        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|unique:users,email',
                'password' => 'nullable|string',
                'date_of_birth' => 'required|date',
                'gender' => 'required|string|max:10',
                'phone_number' => 'required|string|max:10|unique:users,phone_number',
                'address' => 'required|string',
                'user_type' => 'required|string',
                'emergency_contact_name' => 'nullable|string|max:255',
                'emergency_contact_phone' => 'nullable|string|max:15',
                'insurance_provider' => 'nullable|string|max:255',
                'insurance_policy_number' => 'nullable|string|max:255',
                'primary_physician' => 'nullable|string|max:255',
                'medical_history' => 'nullable|string',
                'medications' => 'nullable|string',
                'allergies' => 'nullable|string',
                'blood_type' => 'nullable|string|max:10',
                'status' => 'nullable|integer',

            ], 
            [
                
                'email.unique' => 'This email is already registered',
                'phone_number.unique' => 'This phone number is already in use',
            ]);
        
            // ]);

            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 400);
            }

            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'phone_number' => $request->phone_number,
                'address' => $request->address,
                'user_type' => $request->user_type,
                'emergency_contact_name' => $request->emergency_contact_name,
                'emergency_contact_phone' => $request->emergency_contact_phone,
                'insurance_provider' => $request->insurance_provider,
                'insurance_policy_number' => $request->insurance_policy_number,
                'primary_physician' => $request->primary_physician,
                'medical_history' => $request->medical_history,
                'medications' => $request->medications,
                'allergies' => $request->allergies,
                'blood_type' => $request->blood_type,
                'status' =>  1,
            ]);

            return response()->json([
                'message' => 'User successfully registered!',
                'user' => $user
            ], 201);

        } 
        
        catch (Exception $e) 
        {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function delivery_login(Request $request)
    {
        try {
            $validator = Validator::make(
                $request->all(),
                [
                    'email' => 'required|email',
                    'password' => 'required'
                ]
            );

            if ($validator->fails()) {
                return response()->json(['error' => $validator->errors()], 422);
            }

            if (Auth::attempt(['email' => request('email'), 'password' => request('password'),'user_type'=>1])) {

                $user = User::find(Auth::user()->id);


                $token = $user->createToken('appToken')->accessToken;

                return response()->json([
                    'success' => true,
                    'token' => $token,
                    'user' => $user,
                    'message' => 'User successfully Log in!',
                ], 200);
            } else {

                return response()->json([
                    'success' => false,
                    'message' => 'Failed to authenticate.',
                ], 401);
            }
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function login(Request $request)
{
    try {
      
        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|digits_between:10,15',
        ]);

        if ($validator->fails()) {
            Log::warning('Login validation failed', [
                'errors' => $validator->errors()
            ]);

            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }


        $user = User::where('phone_number', $request->phone_number)
            ->where('user_type', 0)
            ->first();

        if (!$user) {
            Log::info('Login attempt with unregistered number', [
                'phone_number' => $request->phone_number
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Mobile number not registered.'
            ], 404);
        }

        $otp = rand(100000, 999999);
        $refId = rand(1000, 9999);

        $user->update([
            'otp' => $otp,
            'otp_ref_id' => $refId,
            'otp_expires_at' => now()->addMinutes(5),
        ]);

        $templateMessage = "Your login OTP for CoMed is $otp. Please enter this code to continue. Do not share this OTP with anyone. Areacode SCB";

        $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
            'username'   => 'ascbcomed',
            'password'   => 'Comed@123',
            'mobile'     => $user->phone_number,
            'message'    => $templateMessage,
            'sendername' => 'ARDSCB',
            'routetype'  => 1,
            'tid'        => '1207175437936872721',
            'var1'       => 'CoMed',
            'var2'       => $otp,
        ]);

        if (str_contains($response->body(), 'Sent Successfully')) {
            Log::info('OTP sent successfully', [
                'phone_number' => $user->phone_number,
                'otp_ref_id' => $refId,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'OTP sent successfully. Please verify to continue.',
                'otp_ref_id' => $refId,
                'phone_number' => $user->phone_number,
                'otp' => $otp,
            ], 200);
        } else {
            Log::error('OTP sending failed', [
                'phone_number' => $user->phone_number,
                'response' => $response->body(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Failed to send OTP.',
                'api_response' => $response->body(),
            ], 500);
        }
    } catch (\Exception $e) {
        Log::error('Login process error', [
            'exception' => $e->getMessage(),
            'stack' => $e->getTraceAsString()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong. Please try again later.',
            'error' => $e->getMessage(),
        ], 500);
    }
}


    public function verifyOtp(Request $request)
{
    try {
 
        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|digits_between:10,15',
            'otp' => 'required|digits:6',
        ]);

        if ($validator->fails()) {
            Log::warning('OTP verification validation failed', [
                'errors' => $validator->errors(),
                'input' => $request->all(),
            ]);

            return response()->json([
                'success' => false,
                'errors' => $validator->errors(),
            ], 422);
        }

        $user = User::where('phone_number', $request->phone_number)->first();

        if (!$user) {
            Log::info('OTP verification attempt for non-existent user', [
                'phone_number' => $request->phone_number,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'User not found.',
            ], 404);
        }

        if ($user->otp != $request->otp) {
            Log::warning('Invalid OTP attempt', [
                'phone_number' => $request->phone_number,
                'entered_otp' => $request->otp,
                'expected_otp' => $user->otp,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Invalid OTP.',
            ], 401);
        }

        if ($user->otp_expires_at && now()->gt($user->otp_expires_at)) {
            Log::info('OTP expired', [
                'phone_number' => $request->phone_number,
                'otp_expires_at' => $user->otp_expires_at,
            ]);

            return response()->json([
                'success' => false,
                'message' => 'OTP expired.',
            ], 403);
        }

        $user->update([
            'otp' => null,
            'otp_ref_id' => null,
            'otp_expires_at' => null,
        ]);

        $token = $user->createToken('appToken')->accessToken;

        Log::info('User login successful via OTP', [
            'user_id' => $user->id,
            'phone_number' => $user->phone_number,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Login successful.',
            'token' => $token,
            'user' => $user,
        ], 200);

    } catch (\Exception $e) {
        Log::error('Error during OTP verification', [
            'exception' => $e->getMessage(),
            'stack' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong. Please try again later.',
            'error' => $e->getMessage(),
        ], 500);
    }
}


    public function login2(Request $request)
    {
    try 
    {

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'new_phone_number' => 'required|digits_between:10,15|unique:users,phone_number',
        ]);

        if ($validator->fails()) {
            Log::warning('Validation failed in login2', [
                'errors' => $validator->errors()->toArray(),
                'request' => $request->all()
            ]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = User::find($request->user_id);

        if (!$user) {
            Log::error('User not found in login2', ['user_id' => $request->user_id]);
            return response()->json([
                'success' => false,
                'message' => 'User not found.'
            ], 404);
        }

        $otp = rand(100000, 999999);
        $refId = rand(1000, 9999);

        $user->new_phone_otp = $otp;
        $user->new_phone_otp_ref_id = $refId;
        $user->new_phone_number_temp = $request->new_phone_number;
        $user->new_phone_otp_expires_at = now()->addMinutes(5);
        $user->save();

        $templateMessage = "Your login OTP for CoMed is $otp. Please enter this code to continue. Do not share this OTP with anyone. Areacode SCB";

        Log::info('Sending OTP in login2', [
            'user_id' => $user->id,
            'new_phone_number' => $request->new_phone_number,
            'otp' => $otp,
            'ref_id' => $refId
        ]);

        $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
            'username'   => 'ascbcomed',
            'password'   => 'Comed@123',
            'mobile'     => $request->new_phone_number,
            'message'    => $templateMessage,
            'sendername' => 'ARDSCB',
            'routetype'  => 1,
            'tid'        => '1207175437936872721',
            'var1'       => 'CoMed',
            'var2'       => $otp,
        ]);

        Log::info('SMS API Response (login2)', [
            'body' => $response->body()
        ]);

        if (str_contains($response->body(), 'Sent Successfully')) {
            Log::info('OTP sent successfully in login2', [
                'user_id' => $user->id,
                'new_phone_number' => $request->new_phone_number,
                'otp_ref_id' => $refId
            ]);

            return response()->json([
                'success'       => true,
                'message'       => 'OTP sent successfully. Please verify to continue.',
                'otp_ref_id'    => $refId,
                'otp'           => $otp,
            ]);
        }

        Log::error('SMS sending failed in login2', [
            'user_id' => $user->id,
            'api_response' => $response->body()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Failed to send OTP.',
            'api_response' => $response->body(),
        ], 500);

    } catch (\Exception $e) {
        Log::error('Exception in login2', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while sending OTP.',
            'error' => $e->getMessage()
        ], 500);
    }
}

    public function verifyOtp2(Request $request)
    {
    try {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'otp' => 'required|digits:6',
        ]);

        if ($validator->fails()) {
            Log::warning('Validation failed in verifyOtp2', [
                'errors' => $validator->errors()->toArray(),
                'request' => $request->all()
            ]);
            return response()->json(['error' => $validator->errors()], 422);
        }

        $user = User::find($request->user_id);

        if (!$user) {
            Log::error('User not found in verifyOtp2', ['user_id' => $request->user_id]);
            return response()->json([
                'success' => false,
                'message' => 'User not found.',
            ], 404);
        }

        if (
            $user->new_phone_otp != $request->otp ||
            now()->gt($user->new_phone_otp_expires_at)
        ) {
            Log::warning('Invalid or expired OTP in verifyOtp2', [
                'user_id' => $user->id,
                'entered_otp' => $request->otp,
                'stored_otp' => $user->new_phone_otp,
                'otp_expiry' => $user->new_phone_otp_expires_at,
            ]);
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired OTP for new number.',
            ], 403);
        }


        $oldPhone = $user->phone_number;
        $newPhone = $user->new_phone_number_temp;

        $user->phone_number = $newPhone;
        $user->new_phone_number_temp = null;
        $user->new_phone_otp = null;
        $user->new_phone_otp_ref_id = null;
        $user->new_phone_otp_expires_at = null;
        $user->save();

        // Step 5: Log the successful update
        Log::info('Phone number updated successfully in verifyOtp2', [
            'user_id' => $user->id,
            'old_phone' => $oldPhone,
            'new_phone' => $newPhone
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Phone number updated successfully.',
            'phone_number' => $user->phone_number,
        ]);

    } catch (\Exception $e) {
        // Step 6: Catch unexpected exceptions
        Log::error('Exception in verifyOtp2', [
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Something went wrong while verifying OTP.',
            'error' => $e->getMessage()
        ], 500);
    }
}


   public function auth(Request $request)
{
    try {

        $request->validate([
            'client_id' => 'required|string',
            'username'  => 'required|string',
            'password'  => 'required|string',
        ]);


        Log::info('Auth API request initiated', [
            'client_id' => $request->input('client_id'),
            'username'  => $request->input('username'),
        ]);

        $response = Http::withoutVerifying()->post(
            'https://neopay.dineshsoftware.in:546/areacode/payment/public/api/auth',
            [
                'client_id' => $request->input('client_id'),
                'username'  => $request->input('username'),
                'password'  => $request->input('password'),
            ]
        );

        Log::info('Auth API response', [
            'status' => $response->status(),
            'body'   => $response->json(),
        ]);

        return response()->json($response->json(), $response->status());
    } 
    catch (\Illuminate\Validation\ValidationException $e) {
        // Log validation issues
        Log::warning('Auth validation failed', [
            'errors' => $e->errors(),
            'input'  => $request->except('password'),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'errors'  => $e->errors(),
        ], 422);
    } 
    catch (\Illuminate\Http\Client\RequestException $e) {
        // Log HTTP client request errors
        Log::error('Auth API request failed', [
            'message'  => $e->getMessage(),
            'response' => $e->response ? $e->response->body() : null,
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Failed to connect to external API.',
            'error'   => $e->getMessage(),
        ], 500);
    } 
    catch (\Exception $e) {
        // Log any other unexpected errors
        Log::error('Unexpected error in auth()', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'An unexpected error occurred.',
            'error'   => $e->getMessage(),
        ], 500);
    }
}
    
public function accountverification(Request $request)
{
    try {
        // Get Bearer token from request
        $token = $request->bearerToken();
        Log::info('Incoming Bearer token:', [$token]);

        // Prepare request data
        $data = [
            'ref_id'      => $request->input('ref_id'),
            'customer_id' => $request->input('customer_id'),
            'accno'       => $request->input('accno'),
            'mobno'       => $request->input('mobno'),
            'bill_amt'    => $request->input('bill_amt'),
        ];
        Log::info('Account verification request payload:', $data);

        // Send API request
        $response = Http::withoutVerifying()
            ->withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Accept'        => 'application/json',
            ])
            ->post('https://neopay.dineshsoftware.in:546/areacode/payment/public/api/account-verification', $data);

        // Log response
        Log::info('Account verification API response:', [
            'status' => $response->status(),
            'body'   => $response->json(),
        ]);

        // Return API response to client
        return response()->json($response->json(), $response->status());

    } catch (Exception $e) {
        // Log the exception
        Log::error('Error in account verification:', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        // Return error response
        return response()->json([
            'error'   => true,
            'message' => 'Something went wrong while verifying account.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

  public function fundtransfer(Request $request)
{
    try {

        $token = $request->bearerToken();
        Log::info('Incoming Bearer token:', [$token]);

        $data = [
            'reference_id' => $request->input('reference_id'),
            'accno'        => $request->input('accno'),
            'mobileno'     => $request->input('mobileno'),
            'txnamount'    => $request->input('txnamount'),
            'otp'          => $request->input('otp'),
            'remarks'      => $request->input('remarks'),
        ];

        Log::info('Fund Transfer Request Payload:', $data);

        $response = Http::withoutVerifying()
            ->withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Accept'        => 'application/json',
            ])
            ->post('https://neopay.dineshsoftware.in:546/areacode/payment/public/api/fund-transfer', $data);

        Log::info('Fund Transfer API Response:', [
            'status' => $response->status(),
            'body'   => $response->json(),
        ]);

        return response()->json($response->json(), $response->status());

    } 
    catch (Exception $e) {
        Log::error('Error during Fund Transfer:', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error'   => true,
            'message' => 'Something went wrong while processing fund transfer.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

   public function fundtransferstatus(Request $request)
{
    try {
        // Extract Bearer Token
        $token = $request->bearerToken();
        Log::info('Incoming Bearer token for Fund Transfer Status:', [$token]);

        // Prepare API request payload
        $data = [
            'ref_id' => $request->input('ref_id'),
        ];

        Log::info('Fund Transfer Status Request Payload:', $data);

        // Make external API request
        $response = Http::withoutVerifying()
            ->withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Accept'        => 'application/json',
            ])
            ->post('https://neopay.dineshsoftware.in:546/areacode/payment/public/api/fund-transfer-status', $data);

        // Log the API response
        Log::info('Fund Transfer Status API Response:', [
            'status' => $response->status(),
            'body'   => $response->json(),
        ]);

        // Return the response as-is to the client
        return response()->json($response->json(), $response->status());

    } catch (Exception $e) {
        // Log the error details
        Log::error('Error during Fund Transfer Status Check:', [
            'message' => $e->getMessage(),
            'trace'   => $e->getTraceAsString(),
        ]);

        // Return a structured JSON error response
        return response()->json([
            'error'   => true,
            'message' => 'Something went wrong while checking fund transfer status.',
            'details' => $e->getMessage(),
        ], 500);
    }
}

    public function updateProfile(Request $request)
    {
        try {

            $userId = auth()->user()->id;

            if (!$userId) {
                return response()->json(['message' => 'User not found.'], 404);
            }

            $validator = Validator::make($request->all(), [
                'name' => 'nullable|string|max:255',
                'email' => 'nullable|string|email',
                'password' => 'nullable|string|min:8',
                'date_of_birth' => 'nullable|date',
                'gender' => 'nullable|string|max:10',
                'phone_number' => 'nullable|string|max:15',
                'address' => 'nullable|string',
                'emergency_contact_name' => 'nullable|string|max:255',
                'emergency_contact_phone' => 'nullable|string|max:15',
                'insurance_provider' => 'nullable|string|max:255',
                'insurance_policy_number' => 'nullable|string|max:255',
                'primary_physician' => 'nullable|string|max:255',
                'medical_history' => 'nullable|string',
                'medications' => 'nullable|string',
                'allergies' => 'nullable|string',
                'blood_type' => 'nullable|string|max:10',
                'role'=>'nullable|string|'

            ]);

            if ($validator->fails()) {
                return response()->json([
                    'errors' => $validator->errors()
                ], 400);
            }

            $user = User::find($userId);
            $user->update([
                'name' => $request->name ?? $user->name,
                'email' => $request->email ?? $user->email,
                'password' => $request->password ? Hash::make($request->password) : $user->password,
                'date_of_birth' => $request->date_of_birth ?? $user->date_of_birth,
                'gender' => $request->gender ?? $user->gender,
                'phone_number' => $request->phone_number ?? $user->phone_number,
                'address' => $request->address ?? $user->address,
                'emergency_contact_name' => $request->emergency_contact_name ?? $user->emergency_contact_name,
                'emergency_contact_phone' => $request->emergency_contact_phone ?? $user->emergency_contact_phone,
                'insurance_provider' => $request->insurance_provider ?? $user->insurance_provider,
                'insurance_policy_number' => $request->insurance_policy_number ?? $user->insurance_policy_number,
                'primary_physician' => $request->primary_physician ?? $user->primary_physician,
                'medical_history' => $request->medical_history ?? $user->medical_history,
                'medications' => $request->medications ?? $user->medications,
                'allergies' => $request->allergies ?? $user->allergies,
                'blood_type' => $request->blood_type ?? $user->blood_type,
                // 'role'=>$request->role
                
            ]);

            return response()->json([
                'message' => 'Profile updated successfully!',
                'user' => $user
            ], 200);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function logOut()
    {
        try {
            $id = Auth::user()->id;
            $user=User::findOrFail($id);
            $user->tokens()->delete();

            return response()->json([
                'message' => 'User Logout Successfully!',
            ], 200);
        } catch (Exception $e) {
            Log::error($e);
            return response()->json([
                'message' => 'Something went wrong, please try again later.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

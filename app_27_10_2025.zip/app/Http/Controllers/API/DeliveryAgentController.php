<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DeliveryAgent;
use Exception;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\PharmacyPrescription;
use App\Models\User;
use Illuminate\Support\Facades\Auth;


class DeliveryAgentController extends Controller
{
  
    public function deliveryRequests()
{
    try {
        $userId = Auth::id();

        if (!$userId) {
            return response()->json([
                'error' => true,
                'message' => 'User not authenticated.'
            ], 401);
        }

 
        $deliveryRequests = DeliveryAgent::with(['customer:id,name', 'prescription:id,total_amount,payment_method'])
            ->where('delivery_status', 0)
            ->where('delivery_agent_id', $userId)
            ->get()
            ->map(function ($delivery) {
                return [
                    'customer_name'   => $delivery->customer->name ?? 'N/A',
                    'deliv_address'   => $delivery->address,
                    'deliv_coordinates'=> $delivery->coordinates,
                    'customer_mob'    => $delivery->customer_mob,
                    'delivery_agent_id'=> $delivery->id,
                    'otp'             => $delivery->otp,
                    'total_amount'    => $delivery->prescription->total_amount ?? 0,
                    'payment_method'  => match($delivery->prescription->payment_method ?? null) {
                        1 => 'Online Payment',
                        2 => 'Cash on Delivery',
                        default => 'Unknown',
                    },
                ];
            });

        return response()->json([
            'success' => true,
            'deliveryData' => $deliveryRequests
        ], 200);

    } catch (\Exception $e) {
        return response()->json([
            'error' => true,
            'message' => 'Something went wrong while fetching delivery requests.',
            'details' => $e->getMessage(),
        ], 500);
    }
}


    public function deliveryCompleted(Request $request, $id)
    {
        try {
            $validator = Validator::make($request->all(), [
                'delivered_coordinates' => 'required',
                'otp' => 'required',
            ]);

            if ($validator->fails()) {

                return response()->json([
                    'status' => false,
                    'errors' => $validator->errors()
                ], 422);
            }
            $deliveryAgent = DeliveryAgent::where('id', $id)->where('otp', $request->otp)->first();

            if ($deliveryAgent) {
                $deliveryAgent->update([
                    'delivery_status'=>1,
                    'delivered_coordinates' => $request->delivered_coordinates,
                ]);

                PharmacyPrescription::where('id',$deliveryAgent->pres_id)->update([
                    'status'=>3
                ]);

                return response()->json([
                    'message' => 'Delivery Completed Successfully.',
                ]);
            } else {
                return response()->json([
                    'message' => 'Invalid OTP.',
                ], 400);
            }
        } 
        catch (Exception $e) 
        {
           return response()->json([
                'error' => true,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    
    public function pharmacydeliveryCompleted(Request $request, $id)
    {

        try {
        $validator = Validator::make($request->all(), [
            'delivered_coordinates' => 'required|string',
            'otp'                   => 'required|digits:4',
            'phone_number'          => 'required|digits_between:10,15',
            'confirm_payment'       => 'nullable|image', // optional image upload
            'payment_type'          => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Check user
        $user = User::where('phone_number', $request->phone_number)->first();
        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'Mobile number not registered.',
            ], 404);
        }

        // Find prescription
        $prescription = PharmacyPrescription::find($id);
        if (!$prescription) {
            return response()->json([
                'status' => false,
                'message' => 'No delivery records found.',
            ], 404);
        }

        // ✅ Validate OTP against prescription only
        if ($prescription->otp !== $request->otp) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid OTP for this delivery.',
            ], 403);
        }

        // ✅ Handle confirm_payment image upload
        if ($request->hasFile('confirm_payment')) {
            $file = $request->file('confirm_payment');
            $path = $file->store('prescriptions', 'public'); // storage/app/public/prescriptions
            $prescription->confirm_payment = 'storage/' . $path;
        }

        // ✅ Update prescription after OTP success
        $prescription->status               = 4;
        $prescription->delivery_coordinates = $request->delivered_coordinates;
        $prescription->payment_type         = $request->payment_type;
        $prescription->updated_at           = now();
        $prescription->save();

        // Reset user OTP
        $user->otp = null;
        $user->otp_ref_id = null;
        $user->otp_expires_at = null;
        $user->save();

        return response()->json([
            'status' => true,
            'message' => 'Delivery Completed Successfully.',
        ]);

    } catch (\Exception $e) {
        return response()->json([
            'error' => true,
            'message' => $e->getMessage(),
        ], 500);
    }

}

    }

<?php

namespace App\Http\Controllers;

// use App\Models\Log;
use Illuminate\Http\Request;
use App\Models\PharmacyPrescription as pprescription;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Exception;

class PharmacyMedicineController extends Controller
{
   

public function addMedicine(Request $request)
{
    try {

        $request->validate([
            'pharmacy_prescription_id' => 'required|integer|exists:pharmacy_prescriptions,id',
            'payment_method' => 'nullable|string',
            'total_amount' => 'nullable|numeric',
            'assigned_user' => 'required_if:status,3',
            'status' => 'required|integer'
        ]);

        DB::beginTransaction();


        $prescription = pprescription::with(['user', 'deliveryAgent', 'pharmacy'])
            ->findOrFail($request->pharmacy_prescription_id);

        $prescription->fill([
            'status'          => $request->status,
            'payment_method'  => $request->payment_method ?? $prescription->payment_method,
            'total_amount'    => $request->total_amount ?? $prescription->total_amount,
            'expect_date'     => $request->expect_date ?? $prescription->expect_date,
            'delivery_id'     => $request->assigned_user ?? $prescription->delivery_id,
        ])->save();


        $customer = $prescription->user;
        $deliveryAgent = $prescription->deliveryAgent;
        $pharmacy = $prescription->pharmacy;
        $orderId = 'ORD' . str_pad($prescription->id, 5, '0', STR_PAD_LEFT);


        if ($request->status == 1 && $customer && $customer->phone_number) {
            $templateMessage = "Your prescription for order $orderId has been approved by our pharmacist. Your medicines will be prepared shortly. Areacode SCB";

            $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $customer->phone_number,
                'message'    => $templateMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175584451532538',
                'var1'       => $orderId,
            ]);

            Log::info('Prescription approved SMS sent', [
                'mobile' => $customer->phone_number,
                'orderId' => $orderId,
                'response_status' => $response->status(),
                'response_body' => $response->body(),
            ]);
        }

        if ($request->status == 3 && $deliveryAgent && $customer) {
            $deliveryName = $deliveryAgent->name ?? 'our delivery partner';
            $deliveryMessage = "Your pharmacy order ID: $orderId is out for delivery. Our delivery partner $deliveryName will deliver your order soon. Areacode SCB";

            $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $customer->phone_number,
                'message'    => $deliveryMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175446231076349',
                'var1'       => $orderId,
                'var2'       => $deliveryName,
            ]);

            Log::info('Out for delivery SMS sent to customer', [
                'mobile' => $customer->phone_number,
                'orderId' => $orderId,
                'delivery_person' => $deliveryName,
                'response_status' => $response->status(),
                'response_body' => $response->body(),
            ]);


            if ($deliveryAgent->phone_number) {
                $pharmacyName = $pharmacy->pharmacy_name ?? 'Unknown Pharmacy';
                $deliveryboyMessage = "New pharmacy delivery assigned: Order ID: $orderId from $pharmacyName. Please check your app for details. Areacode SCB";

                $response2 = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                    'username'   => 'ascbcomed',
                    'password'   => 'Comed@123',
                    'mobile'     => $deliveryAgent->phone_number,
                    'message'    => $deliveryboyMessage,
                    'sendername' => 'ARDSCB',
                    'routetype'  => 1,
                    'tid'        => '1207175446450937525',
                    'var1'       => $orderId,
                    'var2'       => $pharmacyName,
                ]);

                Log::info('Delivery assignment SMS sent to delivery person', [
                    'mobile' => $deliveryAgent->phone_number,
                    'orderId' => $orderId,
                    'pharmacy_name' => $pharmacyName,
                    'response_status' => $response2->status(),
                    'response_body' => $response2->body(),
                ]);
            }
        }


        if ($request->status == 4 && $customer && $customer->phone_number) {
            $otp = rand(100000, 999999);
            $deliveryCompleteMessage = "Your OTP for confirming pharmacy order ID: $orderId delivery is $otp. Please share this with our delivery agent to complete the delivery. Areacode SCB";

            $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $customer->phone_number,
                'message'    => $deliveryCompleteMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175446609878410',
                'var1'       => $orderId,
                'var2'       => $otp,
            ]);

            Log::info('Delivery OTP SMS sent', [
                'mobile' => $customer->phone_number,
                'orderId' => $orderId,
                'otp' => $otp,
                'response_status' => $response->status(),
                'response_body' => $response->body(),
            ]);
        }


        \App\Models\Log::create([
            'user_id'  => auth()->id(),
            'log_type' => 'Prescription Updated',
            'message'  => "Prescription ID: {$prescription->id} updated to status {$request->status} by " . auth()->user()->name,
        ]);

        DB::commit();

        return redirect()->route('pharmacy-prescriptions.index')->with('success', 'Prescription updated successfully.');

    } 
    catch (Exception $e) 
    {
        DB::rollBack();

        Log::error('Error updating prescription', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
        ]);

        \App\Models\Log::create([
            'user_id'  => auth()->id(),
            'log_type' => 'Error',
            'message'  => 'Failed to update prescription: ' . $e->getMessage(),
        ]);

        return redirect()->route('pharmacy-prescriptions.index')->with('error', 'Something went wrong while updating the prescription.');
    }
}


}

<?php

namespace App\Http\Controllers;

use App\Models\Pharmacy;
use App\Models\PharmacyPrescription;
use App\Models\ClinicPrescription;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
// use App\Models\Log;
use Exception;
use Illuminate\Support\Facades\Log;
use App\Exports\DaybookExport;
use App\Exports\DaybookExport2;
use App\Exports\DaybookExport3;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Pagination\LengthAwarePaginator;
use Carbon\Carbon;
class PharmacyController extends Controller
{
    public function index()
    {
        $pharmacies = Pharmacy::all();
        return view('backend.pharmacy.index', compact('pharmacies'));
    }

    public function index2()
    {
        $pharmacies = Pharmacy::all();
        return view('backend.pharmacy2.index', compact('pharmacies'));
    }


    public function create()
    {
        return view('backend.pharmacy.add_pharmacy');
    }

    public function create2()
    {
        return view('backend.pharmacy2.add_pharmacy');
    }

   public function daybook(Request $request)
    {
    try {
        Log::info('Daybook report generation started', [
            'user_id' => auth()->id(),
            'from_date' => $request->input('from_date'),
            'to_date' => $request->input('to_date'),
            'payment_method' => $request->input('payment_method'),
            'pharmacy_id' => $request->input('pharmacy_id')
        ]);

        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        // Handle missing date range
        if (!$fromDate || !$toDate) {
            $toDate = Carbon::today()->format('Y-m-d');
            $fromDate = Carbon::today()->subDays(30)->format('Y-m-d');

            Log::warning('Date range not provided — default applied', [
                'default_from' => $fromDate,
                'default_to' => $toDate
            ]);

            return redirect()->route('day-book', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
                'payment_method' => $request->input('payment_method'),
                'pharmacy_id' => $request->input('pharmacy_id'),
            ]);
        }

        // Build query
        $query = PharmacyPrescription::with(['user', 'pharmacy', 'deliveryAgent'])
            ->where('status', '!=', 5);

        if (in_array($request->payment_method, ['1', '2'])) {
            $query->where('payment_method', $request->payment_method);
        }

        if ($request->filled('pharmacy_id')) {
            $query->where('pharmacy_id', $request->pharmacy_id);
        }

        $query->whereBetween('created_at', [
            $fromDate . ' 00:00:00',
            $toDate . ' 23:59:59',
        ]);

        $payments = $query->latest()->paginate(10);
        $pharmacies = Pharmacy::orderBy('pharmacy_name')->get();

        Log::info('Daybook report successfully fetched', [
            'record_count' => $payments->total(),
            'date_range' => "$fromDate to $toDate",
            'executed_by' => auth()->id()
        ]);

        return view('backend.daybook.index', compact('payments', 'pharmacies'))
            ->with('success', 'Daybook data loaded successfully.');

    } catch (Exception $e) {
        Log::error('Error while generating daybook report', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'An error occurred while loading the daybook. Please try again later.');
    }
}

    public function book_clinic(Request $request)
{
    try {
        Log::info('Clinic Daybook generation started', [
            'user_id' => auth()->id(),
            'from_date' => $request->input('from_date'),
            'to_date' => $request->input('to_date')
        ]);

        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        // Handle missing date range with default last 30 days
        if (!$fromDate || !$toDate) {
            $toDate = Carbon::today()->format('Y-m-d');
            $fromDate = Carbon::today()->subDays(30)->format('Y-m-d');

            Log::warning('No date range provided — using defaults', [
                'default_from' => $fromDate,
                'default_to' => $toDate
            ]);

            return redirect()->route('day-book-clinic', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ]);
        }

        $loginId = auth()->user()->login_id;

        // Query building
        $query = ClinicPrescription::with(['user', 'deliveryAgent'])
            ->where('status', '!=', 5)
            ->where('clinic_id', $loginId)
            ->whereBetween('created_at', [
                $fromDate . ' 00:00:00',
                $toDate . ' 23:59:59',
            ]);

        $payments = $query->latest()->paginate(10);

        Log::info('Clinic daybook data fetched successfully', [
            'user_id' => auth()->id(),
            'login_id' => $loginId,
            'record_count' => $payments->total(),
            'date_range' => "$fromDate to $toDate"
        ]);

        return view('backend.daybook.index_clinic', compact('payments'))
            ->with('success', 'Clinic daybook loaded successfully.');

    } catch (Exception $e) {
        Log::error('Error while generating clinic daybook report', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]);

        return back()->with('error', 'An unexpected error occurred while loading the clinic daybook. Please try again later.');
    }
}


    public function daybook2(Request $request)
{
    try {
        Log::info('Daybook2 function called', [
            'user_id' => auth()->id(),
            'params' => $request->all(),
        ]);

        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        // Set default date range if not provided
        if (!$fromDate || !$toDate) {
            $toDate = Carbon::today()->format('Y-m-d');
            $fromDate = Carbon::today()->subDays(30)->format('Y-m-d');

            Log::info('Default date range applied', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ]);

            return redirect()->route('day-book2', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
                'payment_method' => $request->input('payment_method'),
                'pharmacy_id' => $request->input('pharmacy_id'),
            ]);
        }

        $loginId = auth()->user()->login_id2;

        // Build query
        $query = PharmacyPrescription::with(['user', 'pharmacy', 'deliveryAgent'])
            ->where('status', '!=', 5)
            ->where('pharmacy_id', $loginId);

        if (in_array($request->payment_method, ['1', '2'])) {
            $query->where('payment_method', $request->payment_method);
            Log::info('Filtered by payment method', ['payment_method' => $request->payment_method]);
        }

        if ($request->filled('pharmacy_id')) {
            $query->where('pharmacy_id', $request->pharmacy_id);
            Log::info('Filtered by pharmacy', ['pharmacy_id' => $request->pharmacy_id]);
        }

        $query->whereBetween('created_at', [
            $fromDate . ' 00:00:00',
            $toDate . ' 23:59:59',
        ]);

        // Fetch results
        $payments = $query->latest()->paginate(10);
        $pharmacies = Pharmacy::orderBy('pharmacy_name')->get();

        Log::info('Daybook2 data fetched successfully', [
            'total_payments' => $payments->total(),
            'from_date' => $fromDate,
            'to_date' => $toDate,
        ]);

        return view('backend.daybook.index2', compact('payments', 'pharmacies'));
    } catch (\Exception $e) {
        Log::error('Error in daybook2 function', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'An unexpected error occurred while generating the daybook. Please try again later.');
    }
}


    


public function export(Request $request)
{
    try {
        Log::info('Daybook export initiated', [
            'user_id' => auth()->id(),
            'params' => $request->all(),
        ]);

        $fileName = 'daybook_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
        $export = new DaybookExport($request->all());

        Log::info('Daybook export processing started');

        return Excel::download($export, $fileName);
    } catch (\Exception $e) {
        Log::error('Error during daybook export', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'An error occurred while exporting the daybook. Please try again.');
    }
}

public function export2(Request $request)
{
    try {
        Log::info('Daybook2 export initiated', [
            'user_id' => auth()->id(),
            'params' => $request->all(),
        ]);

        $fileName = 'daybook2_' . now()->format('Y_m_d_H_i_s') . '.xlsx';
        $export = new DaybookExport2($request->all());

        Log::info('Daybook2 export processing started');

        return Excel::download($export, $fileName);
    } catch (\Exception $e) {
        Log::error('Error during daybook2 export', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'An error occurred while exporting the daybook (Export 2). Please try again.');
    }
}





public function report(Request $request)
{
    try {
        Log::info('Report generation started', [
            'user_id' => auth()->id(),
            'params' => $request->all(),
        ]);

        $from = $request->from_date ? $request->from_date . ' 00:00:00' : null;
        $to   = $request->to_date ? $request->to_date . ' 23:59:59' : null;

        $pharmacyPrescriptions = collect();
        $clinicPrescriptions   = collect();

        // ✅ Fetch clinic prescriptions
        if ($request->types == '1' || empty($request->types)) {
            Log::info('Fetching clinic prescriptions', compact('from', 'to'));

            $clinicQuery = ClinicPrescription::with(['user', 'clinic', 'deliveryAgent']);

            if ($from && $to) {
                $clinicQuery->whereBetween('created_at', [$from, $to]);
            }

            $clinicPrescriptions = $clinicQuery->get()->each(function ($item) {
                $item->setAttribute('type', 'clinic');
            });

            Log::info('Clinic prescriptions retrieved', [
                'count' => $clinicPrescriptions->count(),
            ]);
        }

        // ✅ Fetch pharmacy prescriptions
        if ($request->types == '2' || empty($request->types)) {
            Log::info('Fetching pharmacy prescriptions', compact('from', 'to'));

            $pharmacyQuery = PharmacyPrescription::with(['user', 'pharmacy']);

            if ($from && $to) {
                $pharmacyQuery->whereBetween('created_at', [$from, $to]);
            }

            $pharmacyPrescriptions = $pharmacyQuery->get()->each(function ($item) {
                $item->setAttribute('type', 'pharmacy');
            });

            Log::info('Pharmacy prescriptions retrieved', [
                'count' => $pharmacyPrescriptions->count(),
            ]);
        }

        // ✅ Merge and sort data
        $allPrescriptions = $pharmacyPrescriptions->merge($clinicPrescriptions)
            ->sortByDesc('created_at')
            ->values();

        // ✅ Pagination
        $page = LengthAwarePaginator::resolveCurrentPage();
        $perPage = 10;

        $paginated = new LengthAwarePaginator(
            $allPrescriptions->forPage($page, $perPage),
            $allPrescriptions->count(),
            $perPage,
            $page,
            ['path' => request()->url(), 'query' => request()->query()]
        );

        Log::info('Report generation completed successfully', [
            'total_records' => $allPrescriptions->count(),
        ]);

        return view('backend.daybook.report', ['payments' => $paginated]);
    } catch (\Exception $e) {
        Log::error('Error generating report', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'request_data' => $request->all(),
        ]);

        return back()->with('error', 'An error occurred while generating the report. Please try again.');
    }
}


   public function store(Request $request)
{
    try {
        Log::info('Pharmacy store process started', [
            'user_id' => auth()->id(),
            'request_data' => $request->except(['password', '_token']),
        ]);

        // ✅ Validate input
        $validatedData = $request->validate([
            'pharmacy_name'             => 'required|string|max:255',
            'pharmacy_address'          => 'required|string',
            'city'                      => 'required|string|max:255',
            'phone_number'              => 'required|string|max:20',
            'types'                     => 'required|string|max:20',
            'email'                     => 'required|email|unique:users,email',
            'pharmacy_photo'            => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'qr_code'                   => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'upi'                       => 'required|string|max:20',
            'account_holder_name'       => 'required|string|max:50',
            'account_no'                => 'required|string|max:50',
            'ifsc'                      => 'required|string|max:50',
            'password'                  => 'required|string|min:6|confirmed',
        ]);

        // ✅ File uploads
        $pharmacyPhotoPath = null;
        if ($request->hasFile('pharmacy_photo')) {
            $pharmacyPhotoPath = $request->file('pharmacy_photo')->store('pharmacy_photo', 'public');
            Log::info('Pharmacy photo uploaded', ['path' => $pharmacyPhotoPath]);
        }

        $qrPhotoPath = null;
        if ($request->hasFile('qr_code')) {
            $qrPhotoPath = $request->file('qr_code')->store('pharmacy_qr', 'public');
            Log::info('QR code uploaded', ['path' => $qrPhotoPath]);
        }

        // ✅ Create pharmacy record
        $pharmacy = Pharmacy::create([
            'pharmacy_name' => $validatedData['pharmacy_name'],
            'pharmacy_address' => $validatedData['pharmacy_address'],
            'city' => $validatedData['city'],
            'phone_number' => $validatedData['phone_number'],
            'types' => $validatedData['types'],
            'email' => $validatedData['email'],
            'pharmacy_photo' => $pharmacyPhotoPath,
            'qr_code' => $qrPhotoPath,
            'upi' => $validatedData['upi'],
            'account_holder_name' => $validatedData['account_holder_name'],
            'account_no' => $validatedData['account_no'],
            'ifsc' => $validatedData['ifsc'],
        ]);

        Log::info('Pharmacy created successfully', [
            'pharmacy_id' => $pharmacy->id,
            'pharmacy_name' => $pharmacy->pharmacy_name,
        ]);

        // ✅ Create user for this pharmacy
        $user = User::create([
            'name'          => $validatedData['pharmacy_name'],
            'email'         => $validatedData['email'],
            'password'      => bcrypt($validatedData['password']),
            'login_id2'     => $pharmacy->id,
            'user_type'     => 0,
        ]);

        Log::info('User account created for pharmacy', [
            'user_id' => $user->id,
            'email' => $user->email,
        ]);

        // ✅ Record the action in your custom Log table (if exists)
        if (class_exists(\App\Models\Log::class)) {
            \App\Models\Log::create([
                'user_id' => auth()->id(),
                'log_type' => 'Pharmacy Created',
                'message' => 'Pharmacy "' . $pharmacy->pharmacy_name . '" created by ' . Auth::user()->name,
            ]);
        }

        Log::info('Pharmacy creation process completed successfully', [
            'pharmacy_id' => $pharmacy->id,
        ]);

        return redirect()
            ->route('pharmacies.index')
            ->with('success', 'Pharmacy added successfully.');

    } catch (\Exception $e) {
        // ✅ Log exception with detailed context
        Log::error('Error in Pharmacy store process', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'request_data' => $request->except(['password', '_token']),
        ]);

        return back()->withInput()->with('error', 'An error occurred while adding the pharmacy. Please try again.');
    }
}


public function daybooks(Request $request)
{
    try {
        Log::info('Daybooks method started', [
            'user_id' => auth()->id(),
            'login_id' => auth()->user()->login_id ?? null,
            'input_data' => $request->all(),
        ]);

        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        if (!$fromDate || !$toDate) {
            $toDate = Carbon::today()->format('Y-m-d');
            $fromDate = Carbon::today()->subDays(30)->format('Y-m-d');

            Log::warning('From/To date not provided. Defaulting to last 30 days.', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ]);

            return redirect()->route('day-books', [
                'from_date' => $fromDate,
                'to_date' => $toDate,
            ]);
        }

        $loginId = auth()->user()->login_id;
        $query = ClinicPrescription::with(['deliveryAgent'])
            ->where('status', '!=', 5)
            ->where('clinic_id', $loginId)
            ->whereBetween('created_at', [
                $fromDate . ' 00:00:00',
                $toDate . ' 23:59:59',
            ])
            ->orderByDesc('created_at');

        Log::info('Daybooks query prepared successfully', [
            'clinic_id' => $loginId,
            'from_date' => $fromDate,
            'to_date' => $toDate,
        ]);

        $payments = $query->paginate(10);
        Log::info('Daybooks query executed successfully', [
            'records_count' => $payments->total(),
        ]);

        return view('backend.daybook.index3', compact('payments'));

    } catch (\Exception $e) {

        Log::error('Error occurred in daybooks method', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'request_data' => $request->all(),
        ]);


        return back()->with('error', 'An error occurred while loading the daybook. Please try again later.');
    }
}


    public function export3(Request $request)
    {
    try 
    {
    return Excel::download(new DaybookExport3($request->all()), 'daybook.xlsx');
    } 
    catch (Exception $e) 
    {
    Log::error('Daybook Export3 failed', [
    'error_message' => $e->getMessage(),
    'trace' => $e->getTraceAsString(),
    'request_data' => $request->all(),
    'user_id' => auth()->id(),
    ]);

    return redirect()->back()->with('error', 'Something went wrong while exporting the Daybook. Please try again later.');
    }
    }

 public function edit($id)
{
    try {
        $pharmacy = Pharmacy::findOrFail($id);

        return view('backend.pharmacy.edit_pharmacy', compact('pharmacy'));

    } catch (Exception $e) {
        // Log the error details in laravel.log
        Log::error('Pharmacy Edit Failed', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'pharmacy_id' => $id,
            'user_id' => auth()->id(),
        ]);

        // Redirect back with an error flash message
        return redirect()
            ->back()
            ->with('error', 'Something went wrong while loading the pharmacy edit page. Please try again later.');
    }
}



public function update(Request $request, $id)
{
    try {
        $request->validate([
            'pharmacy_name'         => 'required|string|max:255',
            'pharmacy_address'      => 'required|string',
            'city'                  => 'required|string|max:255',
            'types'                 => 'required|string|max:20',
            'phone_number'          => 'required|string|max:20',
            'email'                 => 'required|email',
            'pharmacy_photo'        => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'qr_code'               => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'upi'                   => 'required|string',
            'account_holder_name'   => 'required|string|max:50',
            'account_no'            => 'required|string|max:50',
            'ifsc'                  => 'required|string|max:50',
            'password'              => 'nullable|min:6',
        ]);

        $pharmacy = Pharmacy::findOrFail($id);

        if ($request->hasFile('pharmacy_photo')) {
            if ($pharmacy->pharmacy_photo) {
                Storage::delete('public/' . $pharmacy->pharmacy_photo);
            }
            $pharmacyPhotoPath = $request->file('pharmacy_photo')->store('pharmacy_photo', 'public');
        } else {
            $pharmacyPhotoPath = $pharmacy->pharmacy_photo;
        }


        if ($request->hasFile('qr_code')) {
            if ($pharmacy->qr_code) {
                Storage::delete('public/' . $pharmacy->qr_code);
            }
            $qrPhotoPath = $request->file('qr_code')->store('pharmacy_photo', 'public');
        } else {
            $qrPhotoPath = $pharmacy->qr_code;
        }

        $pharmacy->update([
            'pharmacy_name'         => $request->pharmacy_name,
            'pharmacy_address'      => $request->pharmacy_address,
            'city'                  => $request->city,
            'phone_number'          => $request->phone_number,
            'types'                 => $request->types,
            'email'                 => $request->email,
            'pharmacy_photo'        => $pharmacyPhotoPath,
            'upi'                   => $request->upi,
            'qr_code'               => $qrPhotoPath,
            'account_holder_name'   => $request->account_holder_name,
            'account_no'            => $request->account_no,
            'ifsc'                  => $request->ifsc,
        ]);

        $user = User::where('login_id2', $pharmacy->id)->first();
        if ($user) {
            $user->name = $request->pharmacy_name;
            $user->email = $request->email;
            if ($request->filled('password')) {
                $user->password = bcrypt($request->password);
            }
            $user->save();
        }

        \App\Models\Log::create([
            'user_id'   => auth()->id(),
            'log_type'  => 'Pharmacy updated',
            'message'   => 'Pharmacy: ' . $request->pharmacy_name . ' updated by ' . auth()->user()->name,
        ]);

        Log::info('Pharmacy updated successfully', [
            'pharmacy_id' => $pharmacy->id,
            'user_id' => auth()->id(),
            'user_name' => auth()->user()->name,
            'timestamp' => now()->toDateTimeString(),
        ]);

        return redirect()
            ->route('pharmacies.index')
            ->with('success', 'Pharmacy updated successfully.');

    }
     catch (Exception $e) {

        Log::error('Pharmacy update failed', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'pharmacy_id' => $id,
            'user_id' => auth()->id(),
            'timestamp' => now()->toDateTimeString(),
        ]);

        \App\Models\Log::create([
            'user_id'   => auth()->id(),
            'log_type'  => 'Error',
            'message'   => 'Failed to update pharmacy ID ' . $id . ': ' . $e->getMessage(),
        ]);

        return redirect()
            ->back()
            ->withInput()
            ->with('error', 'Something went wrong while updating the pharmacy. Please try again later.');
    }
}

public function destroy($id)
{
    try {

        $pharmacy = Pharmacy::findOrFail($id);

        $pharmacy->prescriptions()->delete();
        $pharmacy->delete();

        \App\Models\Log::create([
            'user_id'  => auth()->id(),
            'log_type' => 'Pharmacy deleted',
            'message'  => 'Pharmacy: ' . $pharmacy->pharmacy_name . ' deleted by ' . auth()->user()->name,
        ]);

        Log::info('Pharmacy deleted successfully', [
            'pharmacy_id' => $id,
            'pharmacy_name' => $pharmacy->pharmacy_name,
            'deleted_by_user_id' => auth()->id(),
            'deleted_by_user_name' => auth()->user()->name,
            'timestamp' => now()->toDateTimeString(),
        ]);

        return redirect()
            ->route('pharmacies.index')
            ->with('success', 'Pharmacy and its related prescriptions deleted successfully.');

    } catch (Exception $e) {
        Log::error('Failed to delete pharmacy', [
            'pharmacy_id' => $id,
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
            'timestamp' => now()->toDateTimeString(),
        ]);

        \App\Models\Log::create([
            'user_id'  => auth()->id(),
            'log_type' => 'Error',
            'message'  => 'Failed to delete pharmacy ID ' . $id . ': ' . $e->getMessage(),
        ]);

        return redirect()
            ->route('pharmacies.index')
            ->with('error', 'Something went wrong while deleting the pharmacy. Please try again later.');
    }
}

}

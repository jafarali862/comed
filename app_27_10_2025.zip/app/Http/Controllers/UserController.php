<?php

namespace App\Http\Controllers;

use Exception;
// use App\Models\Log;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;


class UserController extends Controller
{
    public function index()
    {
      $users = User::where('status_new', '!=', 1)
    ->whereNull('login_id')
    ->whereNull('login_id2')
    ->where('role', '!=', 'admin')
    ->get();
        return view('backend.user.users', compact('users'));

    }

    public function index2()
    {
      $users = User::where('status_new', '!=', 1)
    ->whereNull('login_id')
    ->whereNull('login_id2')
    ->where('role', '!=', 'admin') 
    ->get();

        return view('backend.user2.users', compact('users'));
    }

    public function create()
    {
        return view('backend.user.user_create');
    }

    public function create2()
    {
        return view('backend.user2.user_create');
    }


public function store(Request $request)
{
    try 
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email:rfc,dns|unique:users,email',
            'password' => 'required|min:6',
            'date_of_birth' => 'required|date',
            'gender' => 'required|string',
            'phone_number' => 'required|string|max:10',
            'address' => 'required|string',
            'user_type' => 'required',
            'type' => 'required_if:user_type,1|string|nullable',
            'insurance_provider' => 'nullable|string',
            'insurance_policy_number' => 'nullable|string',
            'primary_physician' => 'nullable|string',
            'medical_history' => 'nullable|string',
            'medications' => 'nullable|string',
            'allergies' => 'nullable|string',
            'blood_type' => 'nullable|string|max:10',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'user_type' => $request->user_type,
            'type' => $request->type,
            'insurance_provider' => $request->insurance_provider,
            'insurance_policy_number' => $request->insurance_policy_number,
            'primary_physician' => $request->primary_physician,
            'medical_history' => $request->medical_history,
            'medications' => $request->medications,
            'allergies' => $request->allergies,
            'blood_type' => $request->blood_type,
            'status_new' => 0,
        ]);

        Log::info('New user created successfully', [
            'created_user_id' => $user->id,
            'created_user_name' => $user->name,
            'created_by' => Auth::user()->name ?? 'System',
            'timestamp' => now(),
        ]);

        return redirect()->route('users.index')->with('success', 'User added successfully.');

    }
     catch (Exception $e) {
        Log::error('Error occurred while creating user', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_data' => $request->all(),
            'user_id' => auth()->id(),
            'timestamp' => now(),
        ]);

        return back()->with('error', 'Something went wrong while creating the user. Please try again.');
    }
}


public function edit($id)
{
    try 
    {
        $user = User::findOrFail($id);
        Log::info('User edit page accessed', [
            'user_id' => $id,
            'accessed_by' => Auth::user()->name ?? 'System',
            'timestamp' => now(),
        ]);

        return view('backend.user.user_edit', compact('user'));
    }  
    catch (Exception $e) 
    {
        Log::error('Unexpected error in User edit method', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => $id,
            'accessed_by' => auth()->id(),
            'timestamp' => now(),
        ]);

        return redirect()->route('users.index')->with('error', 'Something went wrong while loading the edit page.');
    }
}



public function updatePassword(Request $request)
{
    
    try {
        $request->validate([
            'new_password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

          /** @var User $user */
        $user = Auth::user();


        if (!$user) {
            throw new Exception('Authenticated user not found.');
        }

        $user->password = bcrypt($request->new_password);
        $user->save();

        Log::info('Password updated successfully', [
            'user_id' => $user->id,
            'user_name' => $user->name,
            'timestamp' => now(),
        ]);

        return redirect()->back()->with('success', 'Password updated successfully!');
    } 

     catch (Exception $e) {
        Log::error('Error updating password', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => Auth::id(),
            'timestamp' => now(),
        ]);

        return redirect()->back()->with('error', 'Something went wrong while updating the password.');
    }
}


public function updateProfile(Request $request)
{
    try {
        
       /** @var User $user */
        $user = Auth::user();

        if (!$user) 
        {
            throw new Exception('Authenticated user not found.');
        }

        $request->validate([
            'name' => 'nullable|string|max:255',
            'email' => [
                'nullable',
                'email:rfc,dns',
                'unique:users,email,' . $user->id,
            ],
            'phone_number' => [
                'nullable',
                'digits:10',
                'regex:/^[0-9]{10}$/',
                'unique:users,phone_number,' . $user->id,
            ],
        ]);

        $updates = [];
        if ($request->filled('name')) {
            $user->name = $request->name;
            $updates['name'] = $request->name;
        }

        if ($request->filled('email')) {
            $user->email = $request->email;
            $updates['email'] = $request->email;
        }

        if ($request->filled('phone_number')) {
            $user->phone_number = $request->phone_number;
            $updates['phone_number'] = $request->phone_number;
        }

        if (!empty($updates)) 
        {
        $user->save();
        }

        Log::info('User profile updated successfully', [
            'user_id' => $user->id,
            'updated_fields' => $updates,
            'ip' => request()->ip(),
            'timestamp' => now(),
        ]);

        return back()->with('success', 'Profile updated successfully.');

    } 
    
    catch (Exception $e) {
        Log::error('Error updating profile', [
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
            'user_id' => Auth::id(),
            'ip' => request()->ip(),
            'timestamp' => now(),
        ]);

        return back()->with('error', 'Something went wrong while updating your profile.');
    }
}


    public function showPhoneRequestForm()
    {
        return view('auth.passwords.phone'); // create this blade file
    }

    public function showOtpForm()
    {
        return view('auth.passwords.verify-otp'); // create this blade file
    }


public function verifyOtp(Request $request)
{
    try {
        // Validate input
        $request->validate([
            'otp' => 'required'
        ]);

        DB::beginTransaction();

        // Fetch user (replace with dynamic logic if needed)
        $user = User::find(1);

        if ($user && $request->otp == $user->otp2) {
            Log::info('OTP verified successfully for user ID: ' . $user->id);

            DB::commit();
            return redirect()->route('password.reset.form')->with('success', 'OTP verified successfully!');
        } else {
            Log::warning('Invalid OTP entered for user ID: ' . ($user ? $user->id : 'Unknown'));

            DB::rollBack();
            return back()->withErrors(['otp' => 'Invalid OTP. Please try again.']);
        }
    } 
     catch (\Exception $e) {
        DB::rollBack();

        // Log unexpected errors
        Log::error('Error during OTP verification: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]);

        return back()->with('error', 'Something went wrong while verifying OTP. Please try again later.');
    }
}

    public function showResetForm()
    {
        return view('auth.passwords.reset'); // create this blade file
    }


public function resetPassword(Request $request)
{
    try {
        $request->validate([
            'password' => 'required|min:6|confirmed',
        ]);

        DB::beginTransaction();

        $user = \App\Models\User::find(1);

        if (!$user) {
            Log::warning('Password reset attempted for a non-existent user (ID: 1)');
            DB::rollBack();
            return back()->withErrors(['user' => 'User not found']);
        }

        // Update password
        $user->password = Hash::make($request->password);
        $user->save();

        // Clear any OTP/session data
        Session::forget('otp');
        Session::forget('phone');

        DB::commit();

        // Log success event
        Log::info('Password successfully reset for user ID: ' . $user->id, [
            'user_email' => $user->email,
            'timestamp' => now(),
        ]);

        return redirect('/login')->with('status', 'Password successfully reset!');
    } 

    catch (\Exception $e) {
        DB::rollBack();

        Log::error('Error resetting password: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'Something went wrong while resetting your password. Please try again later.');
    }
}


public function sendPasswordResetOtp(Request $request)
{
    try {
        // Validate input
        $request->validate([
            'phone' => 'required|digits:10'
        ]);

        DB::beginTransaction();

        // Find user
        $user = User::where('phone_number', $request->phone)->first();

        if (!$user) {
            Log::warning('Password reset OTP request failed: user not found', [
                'phone' => $request->phone,
                'timestamp' => now()
            ]);
            return back()->withErrors(['phone' => 'User with this phone number not found.']);
        }

        // Generate OTP and Reference ID
        $otp = rand(100000, 999999);
        $refId = rand(1000, 9999);

        // Save OTP to user
        $user->otp2 = $otp;
        $user->save();

        // Prepare SMS message
        $templateMessage = "Your Login OTP for CoMed is $otp. Please enter this code to continue. Do not share this OTP with anyone. Areacode SCB";

        // Try sending the SMS
        $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
            'username'   => 'ascbcomed',
            'password'   => 'Comed@123',
            'mobile'     => $request->phone,
            'message'    => $templateMessage,
            'sendername' => 'ARDSCB',
            'routetype'  => 1,
            'tid'        => '1207175437936872721',
            'var1'       => 'CoMed',
            'var2'       => $otp,
        ]);

        DB::commit();

        // Log success
        Log::info('Password reset OTP sent successfully', [
            'user_id' => $user->id,
            'phone' => $request->phone,
            'otp' => $otp,
            'response_status' => $response->status(),
            'timestamp' => now()
        ]);

        return redirect()->route('password.otp.verify')
            ->with('message', 'OTP sent to your phone successfully.');
    } 

    catch (\Exception $e) {
        DB::rollBack();
        Log::error('Unexpected error during OTP generation', [
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);
        return back()->with('error', 'Something went wrong. Please try again later.');
    }
}



public function update(Request $request, $id)
{
    try {
        DB::beginTransaction();

        // Find user safely
        $user = User::findOrFail($id);

        // Validate request
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email:rfc,dns|unique:users,email,' . $user->id,
            'password' => 'nullable|min:6',
            'date_of_birth' => 'required|date',
            'gender' => 'required|string',
            'phone_number' => 'required|string|max:10',
            'address' => 'required|string',
            'user_type' => 'required',
            'insurance_provider' => 'nullable|string',
            'insurance_policy_number' => 'nullable|string',
            'primary_physician' => 'nullable|string',
            'medical_history' => 'nullable|string',
            'medications' => 'nullable|string',
            'allergies' => 'nullable|string',
            'blood_type' => 'nullable|string|max:10',
            'role' => 'nullable'
        ]);

        // Update user record
        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->filled('password') ? bcrypt($request->password) : $user->password,
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'user_type' => $request->user_type,
            'insurance_provider' => $request->insurance_provider,
            'insurance_policy_number' => $request->insurance_policy_number,
            'primary_physician' => $request->primary_physician,
            'medical_history' => $request->medical_history,
            'medications' => $request->medications,
            'allergies' => $request->allergies,
            'blood_type' => $request->blood_type,
        ]);

        // Log user update event
        Log::info('User updated successfully', [
            'user_id' => $user->id,
            'updated_by' => Auth::user()->name ?? 'System',
            'updated_by_id' => Auth::id(),
            'request_data' => $request->except(['password']),
            'timestamp' => now(),
        ]);

        // Optional database logging (if using custom Log model)
        \App\Models\Log::create([
            'user_id' => auth()->id(),
            'log_type' => 'User updated',
            'message' => 'User: ' . $request->name . ', User ID: ' . $id . ' updated by ' . (Auth::user()->name ?? 'System'),
        ]);

        DB::commit();

        return redirect()->route('users.index')->with('success', 'User updated successfully.');
    } 
   
    catch (\Exception $e) {
        DB::rollBack();
        Log::error('Unexpected error during user update', [
            'user_id' => $id,
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);
        return back()->with('error', 'Something went wrong while updating the user. Please try again.');
    }
}


   public function destroy($id)
{
    try {
        // Find the user
        $user = User::findOrFail($id);

        // Delete all tokens first
        $user->tokens()->delete();

        // Delete the user record
        $user->delete();

    
        return redirect()->route('users.index')->with('success', 'User deleted successfully.');
    } 
     catch (\Exception $e) {
        // Log any unexpected errors
        Log::error('User deletion failed: ' . $e->getMessage());

        return redirect()->route('users.index')->with('error', 'An error occurred while deleting the user. Please try again.');
    }
}


    
}

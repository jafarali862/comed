<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
// use App\Models\Log;
use App\Models\User;
use App\Models\Clinic;
use Illuminate\Http\Request;
use App\Models\ClinicPrescription;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Exception;

class ClinicPrescriptionController extends Controller
{
    public function index()
    {

    return view('backend.clinicpres.index');
    }

    public function index2()
    {
    return view('backend.clinicpres2.index');
    }

    public function edit($id)
{
    try {
        // Fetch Clinic Prescription with its delivery agent relationship
        $clinicPrescription = ClinicPrescription::with('deliveryAgent')->findOrFail($id);

        // Get delivery agents (user_type = 1)
        $deliveryAgents = User::where('user_type', 1)->get();

        // Check the status for additional validation
        $status = $clinicPrescription->status;
        if ($status != 2 && $status != 3) {
            Log::info("ClinicPrescription ID {$id} has non-editable status: {$status}");
        }

        // Optionally fetch again (can be skipped since we already have it)
        $cPres = ClinicPrescription::find($id);

        // Get related user and clinic data
        $users = User::all();
        $clinic = Clinic::all();

        // Return the edit view with compact data
        return view('backend.clinicPres.edit_cpres', compact(
            'clinicPrescription',
            'users',
            'clinic',
            'deliveryAgents'
        ));

    } catch (ModelNotFoundException $e) {
        // Log specific not-found error
        Log::error('ClinicPrescription not found', [
            'id' => $id,
            'error' => $e->getMessage(),
        ]);

        // Redirect back with a user-friendly message
        return redirect()->back()->with('error', 'Clinic Prescription not found.');

    } catch (Exception $e) {
        // Log general exceptions with full context
        Log::error('Unexpected error while editing ClinicPrescription', [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        // Redirect back with a generic error message
        return redirect()->back()->with('error', 'An unexpected error occurred while loading the prescription.');
    }
}


    public function edit2($id)
    {
    try {
        // Log the start of the request
        Log::info("Attempting to edit ClinicPrescription2 record", [
            'id' => $id,
            'user_id' => auth()->id(),
            'user_name' => auth()->user()->name ?? 'Guest',
        ]);

        // Fetch clinic prescription with delivery agent relation
        $clinicPrescription = ClinicPrescription::with('deliveryAgent')->findOrFail($id);

        // Get all delivery agents
        $deliveryAgents = User::where('user_type', 1)->get();

        // Check the prescription status
        $status = $clinicPrescription->status;
        if ($status != 2 && $status != 3) {
            Log::warning("ClinicPrescription2 ID {$id} has non-editable status", [
                'status' => $status,
                'handled_by' => auth()->user()->name ?? 'Unknown',
            ]);
        }

        // Optional — second fetch (you can remove this if redundant)
        $cPres = ClinicPrescription::find($id);

        // Fetch users and clinics
        $users = User::all();
        $clinic = Clinic::all();

        // Return the edit view
        return view('backend.clinicPres2.edit_cpres', compact(
            'clinicPrescription',
            'users',
            'clinic',
            'deliveryAgents'
        ));

    } catch (ModelNotFoundException $e) {
        // Log when the record is not found
        Log::error("ClinicPrescription2 not found", [
            'id' => $id,
            'error' => $e->getMessage(),
            'user_id' => auth()->id(),
            'user_name' => auth()->user()->name ?? 'Guest',
        ]);

        return redirect()->back()->with('error', 'Clinic Prescription not found.');

    } catch (Exception $e) {
        // Log general unexpected exceptions
        Log::error("Unexpected error while editing ClinicPrescription2", [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
            'user_name' => auth()->user()->name ?? 'Guest',
        ]);

        return redirect()->back()->with('error', 'An unexpected error occurred while loading the prescription.');
    }
}

   public function update(Request $request, $id)
{
    try {
        // Validate request (will throw ValidationException on failure)
        $request->validate([
            'address'    => 'required|string',
            'status'     => 'nullable',
            'delivery_id'=> 'required_if:status,0|integer|exists:users,id',
            'pres_upload'=> 'nullable|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        // Who is doing this (for logs)
        $authId = auth()->id();
        $authName = auth()->user()->name ?? null;

        Log::info('Update ClinicPrescription request received', [
            'id' => $id,
            'user_id' => $authId,
            'user_name' => $authName,
            'input' => $request->except('pres_upload'),
        ]);

        // Find record
        $ClinicPrescriptions = ClinicPrescription::findOrFail($id);

        // Update fields
        $ClinicPrescriptions->address = $request->address;
        $ClinicPrescriptions->status = $request->status;

        if ($request->filled('delivery_id')) {
            $ClinicPrescriptions->delivery_id = $request->delivery_id;
        }

        // Handle file upload
        if ($request->hasFile('pres_upload')) {
            $file = $request->file('pres_upload');
            $filename = time() . '_' . $file->getClientOriginalName();
            // storeAs may throw; let it bubble to catch
            $path = $file->storeAs('prescriptions', $filename, 'public');
            $ClinicPrescriptions->pres_upload = $path;

            Log::info('Prescription file uploaded', [
                'id' => $id,
                'stored_path' => $path,
                'uploaded_by' => $authId,
            ]);
        }

        // Save
        $ClinicPrescriptions->save();

        // Prepare related data
        $user = \App\Models\User::find($ClinicPrescriptions->user_id);
        $user2 = \App\Models\User::find($ClinicPrescriptions->delivery_id);
        $clinic = \App\Models\Clinic::find($ClinicPrescriptions->clinic_id);
        $clinicName = $clinic->clinic_name ?? 'Clinic';
        $testId = 'CP' . str_pad($ClinicPrescriptions->id, 5, '0', STR_PAD_LEFT);

        // If status == 1 => accepted message to patient
        if ($request->status == 1 && $user && $user->phone_number) {
            $templateMessage = "Your Test ID: $testId has been accepted and is being processed after pickup from $clinicName. You’ll receive results soon. Areacode SCB";

            $response = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $user->phone_number,
                'message'    => $templateMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175584605864059',
                'var1'       => $testId,
                'var2'       => $clinicName,
            ]);

            Log::info('Accepted Test SMS sent', [
                'mobile' => $user->phone_number,
                'testId' => $testId,
                'clinicName' => $clinicName,
                'message_sent' => $templateMessage,
                'sms_api_status' => $response->status(),
                'sms_api_response' => $response->body(),
                'sent_by_user_id' => $authId,
            ]);
        }

        // If delivery assigned => scheduled message to patient
        if (!empty($ClinicPrescriptions->delivery_id) && $user && $user->phone_number) {
            $deliveryUser = \App\Models\User::find($ClinicPrescriptions->delivery_id);
            $deliveryName = $deliveryUser ? $deliveryUser->name : 'our partner';

            $scheduledMessage = "Your test has been scheduled Test ID: $testId. Our partner $deliveryName from $clinicName will visit shortly for sample collection. Areacode SCB";

            $response2 = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $user->phone_number,
                'message'    => $scheduledMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175446666883293',
                'var1'       => $testId,
                'var2'       => $deliveryName,
                'var3'       => $clinicName,
            ]);

            Log::info('Scheduled Sample Collection SMS sent', [
                'mobile' => $user->phone_number,
                'testId' => $testId,
                'delivery_person' => $deliveryName,
                'clinicName' => $clinicName,
                'message_sent' => $scheduledMessage,
                'sms_api_status' => $response2->status(),
                'sms_api_response' => $response2->body(),
                'sent_by_user_id' => $authId,
            ]);
        }

        // If status == 2 => send OTP to delivery agent
        if ($request->status == 2 && !empty($ClinicPrescriptions->delivery_id) && $user2 && $user2->phone_number) {
            $otp = rand(100000, 999999);

            $deliverycompleteMessage = "Your OTP for confirming sample collection Test ID: $testId is $otp. Please provide this to our agent to verify your pickup. Areacode SCB";

            $response3 = Http::get('http://smsgt.niveosys.com/SMS_API/sendsms.php', [
                'username'   => 'ascbcomed',
                'password'   => 'Comed@123',
                'mobile'     => $user2->phone_number,
                'message'    => $deliverycompleteMessage,
                'sendername' => 'ARDSCB',
                'routetype'  => 1,
                'tid'        => '1207175446753325392', // Out-for-delivery TID
                'var1'       => $testId,
                'var2'       => $otp,
            ]);

            Log::info('Delivery SMS sent', [
                'mobile' => $user2->phone_number,
                'testId' => $testId,
                'otp' => $otp,
                'message_sent' => $deliverycompleteMessage,
                'sms_api_status' => $response3->status(),
                'sms_api_response' => $response3->body(),
                'sent_by_user_id' => $authId,
            ]);

            // Optional: persist the OTP for verification later (uncomment to use)
            // $ClinicPrescriptions->collection_otp = $otp;
            // $ClinicPrescriptions->save();
        }

        Log::info('ClinicPrescription updated successfully', [
            'id' => $ClinicPrescriptions->id,
            'updated_by' => $authId,
            'status' => $ClinicPrescriptions->status,
        ]);

        return redirect()->route('clinic-prescriptions.index')->with('success', 'Prescription updated successfully.');

    } catch (ValidationException $e) {
        // Validation failure
        Log::warning('Validation failed when updating ClinicPrescription', [
            'id' => $id,
            'errors' => $e->errors(),
            'user_id' => auth()->id(),
        ]);

        return redirect()->back()->withErrors($e->errors())->withInput();

    } catch (ModelNotFoundException $e) {
      
        Log::error('ClinicPrescription not found for update', [
            'id' => $id,
            'error' => $e->getMessage(),
            'user_id' => auth()->id(),
        ]);

        return redirect()->back()->with('error', 'Clinic Prescription not found.');

    } catch (Exception $e) {
        // Any other unexpected error
        Log::error('Unexpected error while updating ClinicPrescription', [
            'id' => $id,
            'error' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
            'user_id' => auth()->id(),
        ]);

        return redirect()->back()->with('error', 'An unexpected error occurred while updating the prescription.');
    }
}


   public function update2(Request $request, $id)
{
    try {
        // Step 1: Validate inputs
        $request->validate([
            'address' => 'required|string',
            'status'  => 'nullable|string',
            'start_time' => 'nullable|string',
        ]);

        // Step 2: Find the record
        $clinicPrescription = ClinicPrescription::findOrFail($id);

        // Step 3: Update fields
        $clinicPrescription->address = $request->address;
        $clinicPrescription->status = $request->status;

        // Step 4: Handle start_time with flexible parsing
        if ($request->filled('start_time')) {
            try {
                // Try 12-hour format (e.g., 02:30 PM)
                $time = Carbon::createFromFormat('h:i A', $request->start_time);
            } catch (\Exception $e1) {
                try {
                    // Try 24-hour format (e.g., 14:30)
                    $time = Carbon::createFromFormat('H:i', $request->start_time);
                } catch (\Exception $e2) {
                    Log::error('Invalid time format for ClinicPrescription update', [
                        'input_time' => $request->start_time,
                        'clinic_prescription_id' => $id,
                        'error' => $e2->getMessage(),
                    ]);
                    return redirect()->back()->withErrors([
                        'start_time' => 'Invalid time format. Please use HH:MM or HH:MM AM/PM.',
                    ])->withInput();
                }
            }

            $clinicPrescription->start_time = $time->format('h:i A');
        }

        // Step 5: Save the record
        $clinicPrescription->save();

        // Step 6: Log success
        Log::info('ClinicPrescription updated successfully', [
            'clinic_prescription_id' => $id,
            'user_id' => auth()->id(),
            'data' => $clinicPrescription->toArray(),
        ]);

        // Step 7: Redirect on success
        return redirect()
            ->route('clinic-prescriptions2.index')
            ->with('success', 'Prescription updated successfully.');

    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
        Log::error('ClinicPrescription not found during update', [
            'clinic_prescription_id' => $id,
            'error' => $e->getMessage(),
        ]);
        return redirect()->back()->withErrors(['error' => 'Prescription not found.']);
    } catch (\Illuminate\Validation\ValidationException $e) {
        Log::error('Validation failed during ClinicPrescription update', [
            'errors' => $e->errors(),
        ]);
        throw $e; // Let Laravel handle validation redirection
    } catch (\Exception $e) {
        Log::error('Unexpected error during ClinicPrescription update', [
            'clinic_prescription_id' => $id,
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return redirect()->back()->withErrors([
            'error' => 'An unexpected error occurred. Please try again later.',
        ]);
    }
}


public function clinicPresStatus(Request $request)
{
    try {
        $query = $request->input('status');

        Log::info('Fetching clinic prescriptions (admin view)', [
            'status_filter' => $query,
            'user_id' => auth()->id(),
        ]);

        $cPrescriptions = ClinicPrescription::where('status', '=', $query)
            ->orderBy('scheduled_at', 'asc')
            ->paginate(10);

        $output = '';

        foreach ($cPrescriptions as $prescription) {
            $prescriptionImages = '';
            $test = '';

            try {
                // Decode and display prescription images
                if ($prescription->prescription) {
                    $images = json_decode($prescription->prescription, true);
                    $imageUrls = array_map(fn($img) => asset('storage/' . $img), $images);
                    $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;">'
                        . (count($images) > 1 ? ' +' . count($images) : '') .
                        '</i></a>';
                } else {
                    $prescriptionImages = '<span>No image</span>';
                }

                // Decode tests
                if ($prescription->test) {
                    $tests = json_decode($prescription->test, true);
                    $test = implode(', ', $tests);
                } else {
                    $test = '<span>No Tests</span>';
                }

                $output .= '
                    <tr>
                        <td>' . e($prescription->user->name ?? 'N/A') . '</td>
                        <td>' . e($prescription->name) . '</td>
                        <td>' . e($prescription->age) . '</td>
                        <td>' . e($prescription->gender) . '</td>
                        <td>' . e($prescription->clinic->clinic_name ?? 'N/A') . '</td>
                        <td>' . e($prescription->user->phone_number ?? '-') . '</td>
                        <td>' . Carbon::parse($prescription->scheduled_at)->format('d-m-Y') . '</td>
                        <td>' . $prescriptionImages . '</td>
                        <td>' . e($prescription->address) . '</td>
                        <td>' . $test . '</td>
                        <td>' . e($prescription->lat_long) . '</td>
                        <td>
                            <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . e($prescription->id) . '" title="Edit">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>';
            } catch (\Exception $innerEx) {
                Log::error('Error rendering clinic prescription row', [
                    'prescription_id' => $prescription->id,
                    'error' => $innerEx->getMessage(),
                ]);
                continue;
            }
        }

        Log::info('Clinic prescriptions fetched successfully', [
            'count' => $cPrescriptions->count(),
        ]);

        return response([
            'output' => $output,
            'pagination' => $cPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);
    } catch (\Exception $e) {
        Log::error('Error in clinicPresStatus()', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response([
            'output' => '<tr><td colspan="12" class="text-center text-danger">Error loading prescriptions.</td></tr>',
            'pagination' => '',
        ], 500);
    }
}


public function clinicPresStatus2(Request $request)
{
    try {
        $query = $request->input('status');
        $loginId = auth()->user()->login_id;

        Log::info('Fetching clinic prescriptions (clinic view)', [
            'status_filter' => $query,
            'clinic_id' => $loginId,
        ]);

        $cPrescriptions = ClinicPrescription::where('status', $query)
            ->where('clinic_id', $loginId)
            ->orderBy('scheduled_at', 'asc')
            ->paginate(10);

        $output = '';

        foreach ($cPrescriptions as $prescription) {
            $prescriptionImages = '';
            $test = '';

            try {
                // Prescription images
                if ($prescription->prescription) {
                    $images = json_decode($prescription->prescription, true);
                    $imageUrls = array_map(fn($img) => asset('storage/' . $img), $images);
                    $encodedImageUrls = htmlspecialchars(json_encode($imageUrls), ENT_QUOTES, 'UTF-8');

                    $prescriptionImages .= '<a href="javascript:void(0);" class="show-prescriptions" data-images="' . $encodedImageUrls . '">
                        <i class="fas fa-images" style="color: green; font-size: 20px;">'
                        . (count($images) > 1 ? ' +' . count($images) : '') .
                        '</i></a>';
                } else {
                    $prescriptionImages = '<span>No image</span>';
                }

                // Tests
                if ($prescription->test) {
                    $tests = json_decode($prescription->test, true);
                    $test = implode(', ', $tests);
                } else {
                    $test = '<span>No Tests</span>';
                }

                $output .= '
                    <tr>
                        <td>' . e($prescription->user->name ?? 'N/A') . '</td>
                        <td>' . e($prescription->name) . '</td>
                        <td>' . e($prescription->age) . '</td>
                        <td>' . e($prescription->gender) . '</td>
                        <td>' . e($prescription->clinic->clinic_name ?? 'N/A') . '</td>
                        <td>' . e($prescription->user->phone_number ?? '-') . '</td>
                        <td>' . Carbon::parse($prescription->scheduled_at)->format('d-m-Y') . '</td>
                        <td>' . $prescriptionImages . '</td>
                        <td>' . e($prescription->address) . '</td>
                        <td>' . $test . '</td>
                        <td>' . e($prescription->lat_long) . '</td>
                        <td>
                            <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . e($prescription->id) . '" title="Edit">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>';
            } catch (\Exception $innerEx) {
                Log::error('Error rendering clinic prescription row (clinic view)', [
                    'prescription_id' => $prescription->id,
                    'error' => $innerEx->getMessage(),
                ]);
                continue;
            }
        }

        Log::info('Clinic prescriptions fetched successfully (clinic view)', [
            'count' => $cPrescriptions->count(),
        ]);

        return response([
            'output' => $output,
            'pagination' => $cPrescriptions->links('pagination::bootstrap-5')->render(),
        ]);
    } catch (\Exception $e) {
        Log::error('Error in clinicPresStatus2()', [
            'clinic_id' => auth()->user()->login_id ?? null,
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response([
            'output' => '<tr><td colspan="12" class="text-center text-danger">Error loading prescriptions.</td></tr>',
            'pagination' => '',
        ], 500);
    }
}




public function completeAuth(Request $request)
{
    try {
        Log::info('Starting completeAuth process', [
            'user_id' => auth()->id(),
            'request_data' => $request->except(['auth_password']), // avoid logging sensitive data
        ]);

        // Validate input
        $validated = $request->validate([
            'auth_password' => 'required',
            'id2' => 'required|integer|exists:clinic_prescriptions,id',
        ]);

        // Fetch authenticated user
        $user = auth()->user();
        if (!$user) {
            Log::warning('Authentication failed: no user found in session');
            return response()->json([
                'success' => false,
                'message' => 'User not authenticated.',
            ], 401);
        }

        // Find prescription
        $prescription = ClinicPrescription::findOrFail($validated['id2']);

        // Verify password
        if (!Hash::check($validated['auth_password'], $user->password)) {
            Log::warning('Password mismatch during completeAuth', [
                'user_id' => $user->id,
                'prescription_id' => $validated['id2'],
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Password does not match the authenticated user.',
                'errors'  => ['auth_password' => ['Password is incorrect.']],
            ], 422);
        }

        // Update prescription
        $prescription->status = 4;
        $prescription->login_id_new = $user->id;
        $prescription->save();

        Log::info('Prescription marked as completed successfully', [
            'prescription_id' => $prescription->id,
            'updated_by' => $user->id,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Prescription marked as completed successfully.',
        ], 200);

    } catch (\Illuminate\Validation\ValidationException $ve) {
        // Laravel validation exception
        Log::error('Validation error in completeAuth', [
            'errors' => $ve->errors(),
            'user_id' => auth()->id(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Validation failed.',
            'errors'  => $ve->errors(),
        ], 422);

    } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $mnfe) {
        Log::error('ClinicPrescription not found in completeAuth', [
            'id2' => $request->id2,
            'error' => $mnfe->getMessage(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Prescription not found.',
        ], 404);

    } catch (\Exception $e) {
        // Catch-all for unexpected exceptions
        Log::error('Unexpected error in completeAuth', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'An unexpected error occurred. Please try again later.',
        ], 500);
    }
}


   public function clinicPresDate(Request $request)
{
    try {
        Log::info('clinicPresDate request started', [
            'user_id' => auth()->id(),
            'start_date' => $request->input('start_date'),
            'end_date' => $request->input('end_date'),
        ]);


        $request->validate([
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
        ]);

        $startDate = Carbon::parse($request->input('start_date'))->startOfDay();
        $endDate = Carbon::parse($request->input('end_date'))->endOfDay();


        $cPrescriptions = ClinicPrescription::whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('scheduled_at', 'asc')
            ->paginate(10);

        $output = '';

        foreach ($cPrescriptions as $prescription) {
            $prescriptionImages = '';


            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);
                $count = is_array($images) ? count($images) : 0;
                if ($count > 1) {
                    $prescriptionImages = '<i class="fas fa-images" style="color: green; font-size: 20px;"> +' . $count . '</i>';
                } else {
                    $prescriptionImages = '<i class="fas fa-images" style="color: green; font-size: 20px;"></i>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }


            if ($prescription->test) {
                $tests = json_decode($prescription->test, true);
                $test = is_array($tests) && count($tests) ? implode(', ', $tests) : '<span>No Tests</span>';
            } else {
                $test = '<span>No Tests</span>';
            }


            $output .= '
            <tr>
                <td>' . e($prescription->user->name ?? '-') . '</td>
                <td>' . e($prescription->name ?? '-') . '</td>
                <td>' . e($prescription->age ?? '-') . '</td>
                <td>' . e($prescription->gender ?? '-') . '</td>
                <td>' . e($prescription->clinic->clinic_name ?? '-') . '</td>
                <td>' . e($prescription->user->phone_number ?? '-') . '</td>
                <td>' . ($prescription->scheduled_at ? Carbon::parse($prescription->scheduled_at)->format('d-m-Y') : '-') . '</td>
                <td>' . $prescriptionImages . '</td>
                <td>' . e($prescription->address ?? '-') . '</td>
                <td>' . $test . '</td>
                <td>' . e($prescription->lat_long ?? '-') . '</td>
                <td>
                    <button class="btn btn-warning btn-sm open-edit-modal" data-id="' . $prescription->id . '" title="Edit">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>';
        }

        Log::info('clinicPresDate data fetched successfully', [
            'total_records' => $cPrescriptions->total(),
            'user_id' => auth()->id(),
        ]);


        return response([
            'output' => $output,
            'pagination' => $cPrescriptions->links('pagination::bootstrap-5')->render(),
        ], 200);

    } catch (\Illuminate\Validation\ValidationException $ve) {
        Log::warning('Validation failed in clinicPresDate', [
            'user_id' => auth()->id(),
            'errors' => $ve->errors(),
        ]);

        return response([
            'success' => false,
            'message' => 'Invalid date input.',
            'errors' => $ve->errors(),
        ], 422);

    } catch (Exception $e) {
        Log::error('Unexpected error in clinicPresDate', [
            'user_id' => auth()->id(),
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response([
            'success' => false,
            'message' => 'An unexpected error occurred while fetching prescriptions.',
        ], 500);
    }
}

   public function clinicPresDate2(Request $request)
{
    try {
        $startDate = $request->input('start_date');
        $endDate = $request->input('end_date');
        $loginId = auth()->user()->login_id;

        // Log input details for debugging
        Log::info('clinicPresDate2 request started', [
            'user_id' => auth()->id(),
            'login_id' => $loginId,
            'start_date' => $startDate,
            'end_date' => $endDate
        ]);

        // Fetch prescriptions
        $cPrescriptions = ClinicPrescription::where('clinic_id', $loginId)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('scheduled_at', 'asc')
            ->paginate(10);

        $output = '';

        foreach ($cPrescriptions as $prescription) {
            $prescriptionImages = '';

            if ($prescription->prescription) {
                $images = json_decode($prescription->prescription, true);

                if (json_last_error() !== JSON_ERROR_NONE) {
                    Log::warning('Invalid JSON format for prescription images', [
                        'prescription_id' => $prescription->id
                    ]);
                }

                if (!empty($images) && count($images) > 1) {
                    $prescriptionImages .= '<i class="fas fa-images" style="color: green; font-size: 20px;"> +' . count($images) . '</i>';
                } else {
                    $prescriptionImages .= '<i class="fas fa-images" style="color: green; font-size: 20px;"></i>';
                }
            } else {
                $prescriptionImages = '<span>No image</span>';
            }


            if ($prescription->test) {
                $tests = json_decode($prescription->test, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    Log::warning('Invalid JSON format for test data', [
                        'prescription_id' => $prescription->id
                    ]);
                }

                foreach ($tests as $test) {
                    $test;
                }
            } else {
                $test = '<span>No Tests</span>';
            }

            $output .= '
            <tr>
                <td>' . e($prescription->user->name ?? 'N/A') . '</td>
                <td>' . e($prescription->name ?? '') . '</td>
                <td>' . e($prescription->age ?? '') . '</td>
                <td>' . e($prescription->gender ?? '') . '</td>
                <td>' . e($prescription->clinic->clinic_name ?? '') . '</td>
                <td>' . e($prescription->user->phone_number ?? '') . '</td>
                <td>' . \Carbon\Carbon::parse($prescription->scheduled_at)->format('d-m-Y') . '</td>
                <td>' . $prescriptionImages . '</td>
                <td>' . e($prescription->address ?? '') . '</td>
                <td>' . $test . '</td>
                <td>' . e($prescription->lat_long ?? '') . '</td>  
                <td>
                    <button class="btn btn-warning btn-sm open-edit-modal" 
                        data-id="' . $prescription->id . '" title="Edit">
                        <i class="fas fa-eye"></i>
                    </button>
                </td>
            </tr>';
        }

        Log::info('clinicPresDate2 executed successfully', [
            'total_records' => $cPrescriptions->total()
        ]);

        return response([
            'output' => $output,
            'pagination' => $cPrescriptions->links('pagination::bootstrap-5')->toHtml(),
        ]);

    } catch (Exception $e) {

        Log::error('Error in clinicPresDate2', [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'error' => true,
            'message' => 'An unexpected error occurred while fetching clinic prescriptions.',
        ], 500);
    }
}


 

public function rejected($id)
{
    try {
        Log::info('Rejecting clinic prescription initiated', [
            'prescription_id' => $id,
            'user_id' => auth()->id()
        ]);

        $cPrescriptions = ClinicPrescription::findOrFail($id);

        $cPrescriptions->status = 5;
        $cPrescriptions->save();

        Log::info('Clinic prescription successfully rejected', [
            'prescription_id' => $cPrescriptions->id,
            'status' => $cPrescriptions->status,
            'updated_by' => auth()->id()
        ]);

        return back()->with('success', 'Prescription marked as rejected successfully.');

    } catch (Exception $e) {
        Log::error('Error while rejecting clinic prescription', [
            'prescription_id' => $id,
            'error_message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return back()->with('error', 'An error occurred while rejecting the prescription. Please try again later.');
    }
}




}

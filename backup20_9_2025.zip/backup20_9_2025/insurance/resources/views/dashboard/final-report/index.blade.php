@extends('dashboard.layout.app')
@section('title', 'Fianl Report')

@section('content')

<div class="content-page">
    <div class="container-fluid">

        <!-- Page Header -->
        <div class="page-title-head d-flex align-items-center mb-3">
            <div class="flex-grow-1">
                <h4 class="fs-sm text-uppercase fw-bold m-0">
                    <i class="fa-solid fa-clipboard-list me-2 text-primary"></i> Final Report
                </h4>
            </div>
            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('dashboard') }}">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Final Report</li>
                </ol>
            </div>
        </div>

        <!-- Header Buttons -->
        <div class="d-flex justify-content-end mb-3 gap-2 flex-wrap">
            <button class="btn btn-danger" onclick="window.history.back()">
                <i class="fa-solid fa-arrow-left me-1"></i> Back
            </button>
            <button class="btn btn-warning" onclick="window.location.reload()">
                <i class="fa-solid fa-rotate me-1"></i> Reload
            </button>
        </div>

        <!-- Filter Form -->
        <!-- <form id="filterForm" class="row g-3 align-items-end mb-4">
            <div class="col-md-3">
                <label for="from_date" class="form-label fw-bold">From Date</label>
                <input type="date" name="from_date" id="from_date" value="{{ $from ?? '' }}" class="form-control">
            </div>
            <div class="col-md-3">
                <label for="to_date" class="form-label fw-bold">To Date</label>
                <input type="date" name="to_date" id="to_date" value="{{ $to ?? '' }}" class="form-control">
            </div>
        </form> -->

        <!-- Report Table -->
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"  style="color:#fff;">Final Report</h5>
            </div>
        </div>

            <div class="card-body p-0">
                <div class="table-responsive">
                    
                    <table id="reportTable" class="table table-bordered table-striped align-middle text-center mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th>S.No</th>
                                <th>Customer Name</th>
                                <th>Company Name</th>
                                <th>Investigation Date</th>
                                <th>Type</th>
                                <th>Download PDF</th>
                            </tr>
                        </thead>
                   <tbody>
    @if($reports && $reports->count())
        @foreach ($reports as $index => $report)
            @if ($report)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $report->customer_name ?? '-' }}</td>
                    <td>{{ $report->company_name ?? '-' }}</td>
                    <td>{{ \Carbon\Carbon::parse($report->date)->format('d-m-Y') }}</td>
                    <td>{{ $report->type ?? '-' }}</td>
                    <td>
                        <a href="javascript:void(0);" onclick="downloadPdf({{ $report->report_id }})"
                            class="btn btn-success btn-sm">
                            <i class="fa fa-download me-1"></i>Download
                        </a>
                    </td>
                </tr>
            @endif
        @endforeach
    @else
        <tr>
            <td colspan="6" class="text-muted">No reports found for selected dates.</td>
        </tr>
    @endif
</tbody>

                    </table>
                </div>
            </div>
        </div>

    </div>
</div>



<!-- DataTables -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script>
    $(document).ready(function () {
        $('#reportTable').DataTable({
        pageLength: 10,
        responsive: true,
        autoWidth: false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search reports...",
            emptyTable: "No reports available for the selected dates."
        },
        dom: '<"row mb-3"<"col-md-6"l><"col-md-6 text-end"f>>rt<"row mt-3"<"col-md-6"i><"col-md-6 text-end"p>>'
    });
    });

    function downloadPdf(id) {
        if (id != null) {
            $.ajax({
                url: '{{ route("final.report.download") }}',
                type: 'POST',
                data: {
                    report_id: id,
                    _token: '{{ csrf_token() }}',
                },
                xhrFields: {
                    responseType: 'blob'
                },
                success: function (response) {
                    if (response instanceof Blob) {
                        var link = document.createElement('a');
                        link.href = URL.createObjectURL(response);
                        link.download = 'report_' + id + '.pdf';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    } else {
                        alert("Report could not be downloaded.");
                    }
                },
                error: function (xhr, status, error) {
                    alert('Error: ' + error + '\n' + xhr.responseText);
                }
            });
        }
    }


      function autoSubmitFilter() {
        const from = document.getElementById('from_date').value;
        const to = document.getElementById('to_date').value;

        if (from && to) {
            const queryParams = new URLSearchParams(window.location.search);
            queryParams.set('from_date', from);
            queryParams.set('to_date', to);
            window.location.href = window.location.pathname + '?' + queryParams.toString();
        }
    }

    document.getElementById('from_date').addEventListener('change', autoSubmitFilter);
    document.getElementById('to_date').addEventListener('change', autoSubmitFilter);

    
</script>
@endsection

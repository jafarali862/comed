@extends('dashboard.layout.app')
@section('title', 'Fake Case List')
@section('content')
<div class="content-page">
  <div class="container-fluid">

    <!-- Page Header -->
    <div class="page-title-head d-flex align-items-center mb-3">
      <div class="flex-grow-1">
        <h4 class="fs-sm text-uppercase fw-bold m-0">
          <i class="fa-solid fa-clipboard-list me-2 text-primary"></i> Fake Case List
        </h4>
      </div>
      <div class="text-end">
        <ol class="breadcrumb m-0 py-0">
          <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
          <li class="breadcrumb-item active">Fake Cases</li>
        </ol>
      </div>
    </div>

    <!-- Header Buttons -->
   <button class="btn btn-danger mr-2 mb-2" onclick="window.history.back()"><i class="fa fa-arrow-left"
                    aria-hidden="true"></i></button>
            <button class="btn btn-warning mr-2 mb-2" onclick="window.location.reload()"><i class="fa fa-spinner"
                    aria-hidden="true"></i></button>

      
    </div>

    <!-- Filter Form -->
 

    <!-- Card -->
    <div class="card shadow-sm border-0">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0"  style="color:#fff;">Fake Case List</h5>
      </div>
   </div>
   
      <div class="card-body p-0">
        <div class="table-responsive">
          <table id="casesTable" class="table table-striped table-bordered mb-0">
            <thead class="table-dark">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Company</th>
                <th>Case Type</th>
                <th>Crime Number</th>
                <th>Police Station</th>
                <th>Investigation Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $i = $cases->firstItem(); ?>
              @foreach ($cases as $case)
              <tr>
                <td>{{ $i++ }}</td>
                <td>
                  {{ $case->customer_name }}<br />
                  <small class="text-muted">{{ $case->phone }}</small>
                </td>
                <td>{{ $case->company_name }}</td>
                <td>{{ $case->type }}</td>
                <td>{{ $case->crime_number }}</td>
                <td>{{ $case->police_station }}</td>
                <td>{{ \Carbon\Carbon::createFromFormat('Y-m-d', $case->date)->format('d-F-Y') }}</td>
                <td class="text-nowrap">
                  @if ($case->case_status == 1)
                  <span class="badge bg-danger">Pending</span>
                  <button type="button" 
                    class="btn btn-primary btn-sm ms-2 open-reassign-modal" 
                    data-url="{{ route('re.assign.case', $case->id) }}" 
                    data-bs-toggle="modal" data-bs-target="#reassignModal" 
                    title="Re-Assign Case">
                    <i class="fa fa-retweet"></i>
                  </button>
                  <button type="button" 
                    class="btn btn-info btn-sm ms-2 open-view-modal" 
                    data-url="{{ route('view.case_assignment', $case->id) }}" 
                    data-bs-toggle="modal" data-bs-target="#viewModal" 
                    title="View Case Details">
                    <i class="fa fa-eye"></i>
                  </button>
                  @else
                  <span class="badge bg-success">Complete</span>
                  <button class="btn btn-danger btn-sm ms-2" disabled title="Case Completed">
                    <i class="fa fa-window-close"></i>
                  </button>
                  @endif
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- Reassign Modal -->
<div class="modal fade" id="reassignModal" tabindex="-1" aria-labelledby="reassignModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="reassignModalLabel">Re-Assign Case</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="reassignModalBody">
        <div class="text-center py-5">
          <div class="spinner-border text-primary" role="status" aria-hidden="true"></div>
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-info text-white">
        <h5 class="modal-title" id="viewModalLabel">Case Details</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="viewModalBody">
        <!-- AJAX-loaded content will appear here -->
      </div>
    </div>
  </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<script>
$(document).ready(function() {
    // Initialize DataTable
    $('#casesTable').DataTable({
        order: [[0, "asc"]],
        paging: true,
        lengthChange: true,
        searching: true,
        info: true,
        autoWidth: false,
        lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
        responsive: true,
    });

    // Reassign Modal open + AJAX load
    $('.open-reassign-modal').on('click', function() {
        const url = $(this).data('url');
        const modalEl = document.getElementById('reassignModal');
        const modal = new bootstrap.Modal(modalEl);
        const modalBody = $('#reassignModalBody');

        modalBody.html(`
            <div class="text-center py-5">
                <div class="spinner-border text-primary" role="status"></div>
            </div>
        `);

        modal.show();

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error('Failed to load modal content.');
                return response.text();
            })
            .then(html => {
                modalBody.html(html);
                bindReassignFormSubmit(modal);
            })
            .catch(error => {
                modalBody.html('<div class="alert alert-danger">Unable to load content. Try again later.</div>');
                console.error(error);
            });
    });

    function bindReassignFormSubmit(modal) {
        const form = $('#caseUpdate');
        if (!form.length) return;

        form.off('submit').on('submit', function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            fetch('{{ route('re.assign.update') }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'Accept': 'application/json'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message (make sure #successMessage exists inside modal or globally)
                    $('#successMessage').text(data.success).show();

                    setTimeout(() => {
                        modal.hide();
                        location.reload();
                    }, 1500);
                } else if(data.errors) {
                    // Optional: handle validation errors here if returned
                    let errorsHtml = '<div class="alert alert-danger"><ul>';
                    for(const key in data.errors) {
                        data.errors[key].forEach(error => {
                            errorsHtml += `<li>${error}</li>`;
                        });
                    }
                    errorsHtml += '</ul></div>';
                    form.prepend(errorsHtml);
                }
            })
            .catch(err => {
                console.error('Error submitting form:', err);
                alert('Something went wrong while submitting the form.');
            });
        });
    }

    // View Modal open + AJAX load
    $('.open-view-modal').on('click', function() {
        const url = $(this).data('url');
        const modalEl = document.getElementById('viewModal');
        const modal = new bootstrap.Modal(modalEl);
        const modalBody = $('#viewModalBody');

        modalBody.html(`
            <div class="text-center py-5">
                <div class="spinner-border text-info" role="status"></div>
            </div>
        `);
        modal.show();

        fetch(url)
            .then(response => {
                if (!response.ok) throw new Error('Failed to load');
                return response.text();
            })
            .then(html => {
                modalBody.html(html);
            })
            .catch(error => {
                modalBody.html('<div class="alert alert-danger">Error loading details. Try again.</div>');
                console.error('Error loading view modal:', error);
            });
    });

    // Auto-submit filter when dates change
    function autoSubmitFilter() {
        const fromDate = $('#from_date').val();
        const toDate = $('#to_date').val();

        if (fromDate && toDate) {
            const url = "{{ route('assigned.case') }}?from_date=" + encodeURIComponent(fromDate) + "&to_date=" + encodeURIComponent(toDate);
            window.location.href = url;
        }
    }

    $('#from_date, #to_date').on('change', autoSubmitFilter);
});

</script>
<script>

  document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#from_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("from_date").value // use DB value
    });
});

  document.addEventListener("DOMContentLoaded", function() {
    flatpickr("#to_date", {
        allowInput: true,
        dateFormat: "Y-m-d",               // matches your input value
        altInput: true,                    // nicer display
        altFormat: "d-m-Y",                // what user sees
        clickOpens: true,                  // opens only on click
        defaultDate: document.getElementById("to_date").value // use DB value
    });
});

    $('#viewModal .btn-close').on('click', function () {
        location.reload();
    });
</script>

<script>
    $('#reassignModal .btn-close').on('click', function () {
        location.reload();
    });
</script>
@endsection













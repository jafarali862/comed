@extends('layouts.app')

@section('content')
<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-10 col-lg-12 col-md-9">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block bg-login-image">
                            <img src="{{asset('img/login.png')}}" style="width:512px;height:512px;">
                        </div>
                        <div class="col-lg-6">
                            <div class="p-5 mt-5">
                                <!-- <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                </div> -->
                             <form method="POST" action="{{ route('password.phone.sendOtp') }}">
                                    @csrf
                              <div class="form-group">
    <label for="phone">Phone Number</label>
    <input type="text" class="form-control @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone') }}">

    @error('phone')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
    @enderror
</div>

                                  


                                   
                                    <button type='submit' class="btn btn-primary btn-user btn-block">
                                        Send OTP
                                    </button>
                                    <hr>
                                    
                                </form>
                                <hr>
                               
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>





@endsection
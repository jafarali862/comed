@extends('layouts.app')
@section('content')
<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-10 col-lg-12 col-md-9">

        <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
        <div class="col-lg-6 d-none d-lg-block bg-login-image">
        <img src="{{asset('img/login.png')}}" style="width:512px;height:512px;">
        </div>
        <div class="col-lg-6">
        <div class="p-5 mt-5">
        @if(session('message'))
        <p>{{ session('message') }}</p>
        @endif
        <form method="POST" action="{{ route('password.reset.submit') }}" class="w-100">
        @csrf
        
        <div class="form-group">
       <label for="password" class="form-label">New Password</label>
        <input type="password" name="password" id="password" class="form-control" required>
        </div>

         <div class="form-group">
         <label for="password_confirmation" class="form-label">Confirm Password</label>
        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
        </div>

                                  
    <button type='submit' class="btn btn-primary btn-user btn-block">
  Reset Password
    </button>
    <hr>

    </form>
    <hr>


    </div>
    </div>
    </div>
    </div>
    </div>

    </div>
    </div>
    </div>

@endsection



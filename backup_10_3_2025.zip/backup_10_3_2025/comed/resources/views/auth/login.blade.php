@extends('layouts.app')

@section('content')
<div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

        <div class="col-xl-10 col-lg-12 col-md-9">

            <div class="card o-hidden border-0 shadow-lg my-5">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="col-lg-6 d-none d-lg-block bg-login-image">
                            <img src="{{asset('img/login.png')}}" style="width:512px;height:512px;">
                        </div>
                        <div class="col-lg-6">
                            <div class="p-5 mt-5">
                                <div class="text-center">
                                    <h1 class="h4 text-gray-900 mb-4" style="font-weight: 600;font-size: 28px;">Welcome Back!</h1>
                                </div>
                                <form method="POST" action="{{ route('login') }}">
                                    @csrf
                                    <div class="form-group">
                                        <input type="email" class="form-control @error('email') is-invalid @enderror form-control-user"
                                            id="exampleInputEmail" aria-describedby="emailHelp" name="email" placeholder="Enter Email Address..." >

                                        @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                    <!-- <div class="form-group">
                                        <input type="password" class="form-control  @error('password') is-invalid @enderror form-control-user" name="password" id="exampleInputPassword" placeholder="Password" >

                                        @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div> -->


                                    <div class="form-group position-relative">
  <input 
    type="password" 
    class="form-control @error('password') is-invalid @enderror form-control-user" 
    name="password" 
    id="exampleInputPassword" 
    placeholder="Password" 
  >
  <span 
    toggle="#exampleInputPassword" 
    class="fa fa-fw fa-eye field-icon toggle-password" 
    style="position: absolute; top: 50%; right: 10px; transform: translateY(-50%); cursor: pointer;"
  ></span>

  @error('password')
  <span class="invalid-feedback" role="alert">
    <strong>{{ $message }}</strong>
  </span>
  @enderror
</div>

                                   
                                    <button type='submit' class="btn btn-primary btn-user btn-block">
                                        Login
                                    </button>
                                    <hr>
                                    
                                </form>
                                <hr>
                                <div class="text-center">
                                    <!-- <a class="small" href="{{ route('password.request') }}">Forgot Password?</a> -->

                                    <a class="small" href="{{ route('password.phone.request') }}">Forgot Password?</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

</div>


<script>
  document.querySelector('.toggle-password').addEventListener('click', function () {
    const input = document.querySelector(this.getAttribute('toggle'));
    if (input.type === 'password') {
      input.type = 'text';
      this.classList.remove('fa-eye');
      this.classList.add('fa-eye-slash');
    } else {
      input.type = 'password';
      this.classList.remove('fa-eye-slash');
      this.classList.add('fa-eye');
    }
  });
</script>


@endsection
@extends('backend.layouts.app')

@section('content')

<!-- /.content-header -->

<!-- Main content -->


         

<div class="content-wrapper">
     @if(auth()->user()->role === 'user')
    <h3 style="margin-left: 30px;">{{ Auth::user()->name }}</h3>
           @endif
    <section class='content'>
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$userCount}}</h3>
                            <p>Total Users  </p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add"></i>
                        </div>
                        <a href="{{route('users2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
               
                <!-- ./col -->
             
                <!-- ./col -->
         

                @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$clinicPresCount}}</h3>
                            <p>New Laboratory Prescription</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('clinic-prescriptions2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                @endif



                 @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3>{{$testcount}}</h3>
                            <p>Test</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('clinic-prescriptions2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                @endif


        @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))

                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                        <div class="inner">
                            <h3>{{$pharmacyPresCount}}</h3>
                            <p>New Pharmacy Prescription</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="{{route('pharmacy-prescriptions2.index')}}" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                       @endif
                       
                <!-- ./col -->
            </div>

            <!-- Charts Row -->
             <div class="row mt-5">
                <div class="col-md-6">
                    <!-- Pie Chart -->
                    <!-- <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h3 class="card-title">Category Distribution</h3>
                        </div>
                        <div class="card-body">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div> -->

                    <div class="card">
  <div class="card-header bg-primary text-white">
    <h3 class="card-title">Category Distribution</h3>
  </div>
  <div class="card-body">
    <!-- Chart label -->
    <!-- <h5 id="chartLabel" class="mb-3">Clinic Prescription</h5> -->

    <!-- Toggle button -->
    <!-- <button id="toggleChartBtn2" class="btn btn-primary mb-3">Show Pharmacy Prescriptions</button> -->

        <div class="mb-3">
        <!-- <label><strong>Select Prescription Type:</strong></label><br> -->

          @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))
        <!-- <input type="radio" name="chartType" value="clinic" id="clinicRadio" checked> -->
        <label for="clinicRadio">Laboratoy Prescriptions</label>
    @endif
        
      @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))
        <input type="radio" name="chartType" value="pharmacy" id="pharmacyRadio">
        <label for="pharmacyRadio">Pharmacy Prescriptions</label>
 @endif
        </div>

<!-- <canvas id="myPieChart" width="400" height="400"></canvas> -->


    <!-- Pie chart -->
    <canvas id="pieChart"></canvas>
  </div>
</div>


                </div>

                 @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))
                <div class="col-md-6">
                    <!-- Bar Graph -->
                    <div class="card" style="height: 506px;">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Comparitive Analysis</h3>
                        </div>
                        <div class="card-body">

                       <!-- <button id="toggleChartBtn" class="btn btn-primary mb-3">Prescription Count</button> -->

                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                </div>
          @endif



            @if(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))
                <div class="col-md-6">
                    <!-- Bar Graph -->
                    <div class="card" style="height: 506px;">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Comparitive Analysis</h3>
                        </div>
                        <div class="card-body">

                       <!-- <button id="toggleChartBtn" class="btn btn-primary mb-3">Prescription Count</button> -->

                            <canvas id="barChartTests"></canvas>
                        </div>
                    </div>
                </div>
          @endif


            </div>
        </div>
    </section>
</div>









<!-- Chart.js Script -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
   document.addEventListener("DOMContentLoaded", function() {
  const ctx1 = document.getElementById('pieChart').getContext('2d');

  // Clinic prescription data
  const clinicLabels = ['New', 'Pending', 'Collected', 'Testing', 'Completed', 'Rejected'];
  const clinicData = [
    {{$clinicPresCount}}, 
    {{$clinicPresCount11}}, 
    {{$clinicPresCount12}}, 
    {{$clinicPresCount13}}, 
    {{$clinicPresCount14}}, 
    {{$clinicPresCount15}}
  ];
  const clinicColors = ['#007bff', '#28a745', '#ffc107', '#ff10ebff', '#6410ffff', '#ff7010ff'];

  // Pharmacy prescription data
  const pharmacyLabels = ['New', 'Processing', 'Confirmed', 'Assigned Delivery', 'Completed', 'Rejected'];
  const pharmacyData = [
    {{$pharmacyPresCount}}, 
    {{$pharmacyPresCount11}}, 
    {{$pharmacyPresCount12}}, 
    {{$pharmacyPresCount13}}, 
    {{$pharmacyPresCount14}}, 
    {{$pharmacyPresCount15}}
  ];
  const pharmacyColors = ['#6610f2', '#e83e8c', '#fd7e14', '#20c997', '#17a2b8', '#dc3545'];

  // Track which data is showing
  let showingClinic = true;

  // Initialize pie chart with clinic data
  const pieChart = new Chart(ctx1, {
    type: 'pie',
    data: {
      labels: clinicLabels,
      datasets: [{
        data: clinicData,
        backgroundColor: clinicColors
      }]
    }
  });



  
const ctx2 = document.getElementById('barChart').getContext('2d');

// Data sets
const totalData = {
  labels: ['Online Payment', 'Cash on Delivery'],
  data: [{{ $pharmacyPresCount2 }}, {{ $pharmacyPresCount3 }}],
  backgroundColor: ['#007bff', '#28a745', '#ffc107']
};



let showingTotal = true; // Track current dataset

const barChart = new Chart(ctx2, {
  type: 'bar',
  data: {
    labels: totalData.labels,
    datasets: [{
      label: 'Total Count',
      data: totalData.data,
      backgroundColor: totalData.backgroundColor,
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        ticks: { color: "#000" }
      },
      y: {
        beginAtZero: true,
        ticks: { stepSize: 1 }
      }
    },
      plugins: {
    legend: {
      display: false   // hides the legend entirely
    }
  }
  }
});








// Toggle function
function toggleChartData() {
  if(showingTotal) {
    barChart.data.labels = paymentMethodData.labels;
    barChart.data.datasets[0].data = paymentMethodData.data;
    barChart.data.datasets[0].backgroundColor = paymentMethodData.backgroundColor;
    barChart.data.datasets[0].label = 'Pharmacy Prescriptions by Payment Method';
    showingTotal = false;
  } else {
    barChart.data.labels = totalData.labels;
    barChart.data.datasets[0].data = totalData.data;
    barChart.data.datasets[0].backgroundColor = 'transparent';
    barChart.data.datasets[0].label = '';
    showingTotal = true;
  }
  barChart.update();

   
  }

function toggleChartData2() {
  if (showingClinic) {
      // Switch to pharmacy data
      pieChart.data.labels = pharmacyLabels;
      pieChart.data.datasets[0].data = pharmacyData;
      pieChart.data.datasets[0].backgroundColor = pharmacyColors;
      document.getElementById('toggleChartBtn2').textContent = "Show Clinic Prescriptions";
      showingClinic = false;
    } else {
      // Switch back to clinic data
      pieChart.data.labels = clinicLabels;
      pieChart.data.datasets[0].data = clinicData;
      pieChart.data.datasets[0].backgroundColor = clinicColors;
      document.getElementById('toggleChartBtn2').textContent = "Show Pharmacy Prescriptions";
      showingClinic = true;
    }
    pieChart.update();

}


function updateChartData(selected) {
    if (selected === 'pharmacy') {
      pieChart.data.labels = pharmacyLabels;
      pieChart.data.datasets[0].data = pharmacyData;
      pieChart.data.datasets[0].backgroundColor = pharmacyColors;
    } else {
      pieChart.data.labels = clinicLabels;
      pieChart.data.datasets[0].data = clinicData;
      pieChart.data.datasets[0].backgroundColor = clinicColors;
    }

    pieChart.update();
  }

  // Event listener for radio buttons
  document.querySelectorAll('input[name="chartType"]').forEach(radio => {
    radio.addEventListener('change', function () {
      updateChartData(this.value);
    });
  });

document.getElementById('toggleChartBtn2').addEventListener('click', toggleChartData2);

document.getElementById('toggleChartBtn').addEventListener('click', toggleChartData);


});
</script>


<script>
 const testLabels = {!! json_encode($labels) !!};   // ✅ Correct: ['Blood Test', 'CBC', 'Lipid Profile']
  const testCounts = {!! json_encode($counts) !!};

  const ctx = document.getElementById('barChartTests').getContext('2d');
const testBarChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: testLabels, // ✅ now labels like ["Blood Test", "CBC", "Lipid Profile"]
        datasets: [{
            data: testCounts,
            backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                ticks: {
                    color: '#000',
                    maxRotation: 45,
                    minRotation: 0,
                    autoSkip: false
                }
            },
            y: {
                beginAtZero: true
            }
        },
        plugins: {
            legend: { display: false },
            tooltip: { enabled: true }
        }
    }
});

</script>




@endsection
@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Laboratory</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item active">Laboratory</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <!-- /.card -->

          <div class="card">
            <div class="card-header d-flex justify-content-end">
              <a class="btn btn-success" href="{{route('add-new-clinics')}}">
                <i class="fas fa-plus"></i> Add Laboratory
              </a>
            </div>
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                
                    <th>Address</th>
                    <th>City</th>
                    <th>Phone No</th>
                    <th>Email</th>
                    <th>Laboratory Photo</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($clinics as $clinic)
                  <tr>
                    <td>{{ $clinic->clinic_name }}</td>
              
                    <td>{{ $clinic->clinic_address }}</td>
                    <td>{{ $clinic->city }}</td>
                    <td>{{ $clinic->phone_number }}</td>
                    <td>{{ $clinic->email }}</td>
                    <td>
                      @if ($clinic->clinic_photo)
                       <div style="width: 50px; height: 50px; overflow: hidden; border: 1px solid #ccc; border-radius: 0.25rem;">
    <img src="{{ asset('storage/' . $clinic->clinic_photo) }}" alt="Clinic Photo"
         style="width: 100%; height: 100%; object-fit: cover;" class="img-thumbnail">
  </div>

                      @else
                        <span>No Photo</span>
                      @endif
                    </td>
                      <td>
  <div class="d-flex flex-wrap gap-2">
    <a href="{{ route('clinics.edit', $clinic->id) }}" class="btn btn-warning btn-sm" style="margin-bottom: 0;">
      <i class="fas fa-edit"></i>
    </a>

    <form action="{{ route('clinics.destroy', $clinic->id) }}" method="POST" style="margin: 0;">
      @csrf
      @method('DELETE')
      <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this laboratory?');">
        <i class="fas fa-trash"></i>
      </button>
    </form>
  </div>
</td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->



<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>



<link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">

<style>
.dataTables_wrapper .dataTables_paginate .paginate_button:hover
{
background-color: unset !important;
box-shadow: unset !important;
box-shadow: unset !important;
border: unset !important;
background: unset !important;
}
</style>




<!-- jQuery -->
<script src="{{asset('plugins/jquery/jquery.min.js')}}"></script>
<!-- Page specific script -->
<script>
 $(function() {
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "order": [[0, "desc"]],
      "columnDefs": [
        { "orderable": false, "targets": -1 } // Make last column (e.g., "Action") not orderable
      ],
      "buttons": [
        {
          extend: 'copy',
          exportOptions: {
                     columns: [0, 1, 2,3,4] // Include only first 3 columns

          }
        },
        {
          extend: 'csv',
          exportOptions: {
                    columns: [0, 1, 2,3,4] // Include only first 3 columns

          }
        },
        {
          extend: 'excel',
          exportOptions: {
                      columns: [0, 1, 2,3,4] // Include only first 3 columns

          }
        },
        {
          extend: 'pdf',
          exportOptions: {
                      columns: [0, 1, 2,3,4] // Include only first 3 columns

          }
        },
        {
          extend: 'print',
          exportOptions: {
                    columns: [0, 1, 2,3,4] // Include only first 3 columns

          }
        }
      ]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  });
</script>

@endsection

<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Clinic;
use App\Models\Medicine;
use App\Models\Pharmacy;
use Illuminate\Http\Request;
use App\Models\ClinicPrescription;
use App\Models\PharmacyPrescription;
use Illuminate\Support\Facades\Http;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   $today= Carbon::now()->toDateString();
        $users=User::all();
        // $userCount=count($users);
       $userCount = User::where('status_new', '!=', 1)
        ->where('role', '!=', 'admin') // ✅ Exclude Admins
        ->where(function ($query) {
        $query->where(function ($q) {
        $q->whereNull('login_id')->orWhere('login_id', '');
        })->where(function ($q) {
        $q->whereNull('login_id2')->orWhere('login_id2', '');
        });
        })
        ->count();
         $smsBalance = $this->getSmsBalance();

        $clinic=Clinic::all();
        $clinicCount=count($clinic);
        $pharmacy=Pharmacy::all();
        $pharmacyCount=count($pharmacy);
        $medicine=Medicine::all();
        $medicineCount=count($medicine);
        // $pharmacyPres=PharmacyPrescription::where("created_at","like",$today.'%')->get();
        $pharmacyPres=PharmacyPrescription::where("status",'0')->get();
        $pharmacyPresCount=count( $pharmacyPres);
        // $clinicPres=ClinicPrescription::where("created_at","like",$today.'%')->get();
          $clinicPres=ClinicPrescription::where("status",'0')->get();
        $clinicPresCount=count( $clinicPres);

        $pharmacyPres2=PharmacyPrescription::where("payment_method",'1')->get();
              $pharmacyPresCount2=count( $pharmacyPres2);

                $pharmacyPres3=PharmacyPrescription::where("payment_method",'2')->get();
              $pharmacyPresCount3=count( $pharmacyPres3);

        // $pharmacyPres=PharmacyPrescription::where("created_at","like",$today.'%')->get();
        $pharmacyPres=PharmacyPrescription::where("status",'0')->get();
        $pharmacyPresCount=count( $pharmacyPres);
        // $clinicPres=ClinicPrescription::where("created_at","like",$today.'%')->get();
          $clinicPres=ClinicPrescription::where("status",'0')->get();
        $clinicPresCount=count( $clinicPres);

           $clinicPres11=ClinicPrescription::where("status",'1')->get();
        $clinicPresCount11=count( $clinicPres11);

         $clinicPres12=ClinicPrescription::where("status",'2')->get();
        $clinicPresCount12=count( $clinicPres12);

           $clinicPres13=ClinicPrescription::where("status",'3')->get();
        $clinicPresCount13=count( $clinicPres13);

           $clinicPres14=ClinicPrescription::where("status",'4')->get();
        $clinicPresCount14=count( $clinicPres14);

         $clinicPres15=ClinicPrescription::where("status",'5')->get();
        $clinicPresCount15=count( $clinicPres15);


             $pharmacyPres11=PharmacyPrescription::where("status",'1')->get();
        $pharmacyPresCount11=count( $pharmacyPres11);

               $pharmacyPres12=PharmacyPrescription::where("status",'2')->get();
        $pharmacyPresCount12=count( $pharmacyPres12);

         $pharmacyPres13=PharmacyPrescription::where("status",'3')->get();
        $pharmacyPresCount13=count( $pharmacyPres13);

 $pharmacyPres14=PharmacyPrescription::where("status",'4')->get();
        $pharmacyPresCount14=count( $pharmacyPres14);

         $pharmacyPres15=PharmacyPrescription::where("status",'5')->get();
        $pharmacyPresCount15=count($pharmacyPres15);

        return view('backend.home',compact('userCount','clinicCount','pharmacyCount','medicineCount',
        'smsBalance','pharmacyPresCount','clinicPresCount',
        'clinicPresCount11','clinicPresCount12','clinicPresCount13',
        'clinicPresCount14','clinicPresCount15',
         'pharmacyPresCount11','pharmacyPresCount12',
         'pharmacyPresCount13','pharmacyPresCount14','pharmacyPresCount15',
         'pharmacyPresCount2','pharmacyPresCount3'
        ));
    }


    public function getSmsBalance()
{
    $response = Http::get('http://smsgt.niveosys.com/SMS_API/balanceinfo.php?apikey=595e1783-6ba7-11f0-9b8b-e29d2b69142c');

    if ($response->successful()) {
        $body = $response->body();  // e.g. "T-50<br>P-0"
        $parts = explode('<br>', $body);

        $tPart = trim($parts[0] ?? ''); // "T-50"

        // Remove "T-" prefix if exists
        if (str_starts_with($tPart, 'T-')) {
            $tPart = substr($tPart, 2);  // removes first 2 chars "T-"
        }

        return $tPart ?: 'N/A';
    }

    return 'N/A';
}


    
}

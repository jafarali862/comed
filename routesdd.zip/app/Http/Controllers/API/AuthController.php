<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\CompanyLogo;

class AuthController extends Controller
{
    public function login(Request $request)
    {

        //Check email
        $email = User::where("email", $request->email)->exists();

        if (User::where('email', $email)->exists()) {
            return response()->json(['message' => 'Invalid login credentials.'], 401);
        }

        $status = User::where('email', $request->email)->first();

        if ($status->status == 0) {
            return response()->json(['message' => 'Profile already blocked. Contact admin.'], 345);
        }

        if ($status->login_request != 0) {
        return response()->json(['message' => 'Login request pending or not allowed.'], 401);
        }

        if ($status->role == 1 || $status->role == 2) {
            return response()->json(['message' => 'Invalid login credentialsee.'], 401);
        }

        $credentials = $request->only('email', 'password');

        $imei = $request->imei ?? null;

      if (Auth::attempt($credentials)) {
    $user = Auth::user();

    if ($user->login_request == 0) 
        {
        // Delete old tokens
        $user->tokens()->delete();

        // Create new token
        $token = $user->createToken('Insurance API Auth')->accessToken;

        // Mark user as having an active login
        $user->login_request = 1;
        $user->save();

        // Optional IMEI update
        $imei = $request->imei ?? null;
        DB::table('users')->where('id', $user->id)->update(['imei' => $imei]);

        // Get company info
        $company = CompanyLogo::orderBy('id')->first();

        // Build response
        $response = [
            'token' => $token,
            'name' => $user->name,
            'place' => $user->place,
            'phone' => $user->phone,
            'email' => $user->email,
            'user_id' => $user->id,
            'emp_id' => 'USR' . str_pad($user->id, 6, '0', STR_PAD_LEFT),
            'profile_pic' => $user->profile_image,
            'imei' => $imei,
            'blood_group' => $user->blood,
            'date_of_birth' => $user->date_of_birth,
            'join_date' => $user->join_date,
            'company_name' => $company->name ?? '',
            'company_phone' => $company->phone ?? '',
            'company_email' => $company->email ?? '',
            'company_logo' => $company->logo ?? '',
            'company_address' => $company->place ?? '',
        ];

        return response()->json($response, 200);
    } else {
   
        return response()->json([
            'message' => 'Login request already in progress or user already logged in.'
        ], 403);
    }
} else {

    return response()->json([
        'message' => 'Invalid login credentials.'
    ], 401);
}
    }

    public function logout(Request $request)
    {
        $user = Auth::user();

        if ($user) {
            $user->tokens()->delete();

            return response()->json(['message' => 'Successfully logged out.'], 200);
        }

        return response()->json(['message' => 'User not authenticated.'], 401);
    }

}


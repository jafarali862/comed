import Echo from 'laravel-echo';
import Reverb from '@reverbdotdev/reverb-js';

// You don't need Pusher here unless you use it for something else
// window.Pusher = require('pusher-js');

window.Echo = new Echo({
  broadcaster: 'reverb',
  key: import.meta.env.VITE_REVERB_APP_KEY,
  host: import.meta.env.VITE_REVERB_HOST,
  port: import.meta.env.VITE_REVERB_PORT,
  scheme: import.meta.env.VITE_REVERB_SCHEME,
  encrypted: import.meta.env.VITE_REVERB_SCHEME === 'https',
  client: Reverb,
  disableStats: true,
});

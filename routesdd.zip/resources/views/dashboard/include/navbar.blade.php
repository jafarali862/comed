@php
$user = Auth::user();
@endphp
<header class="app-topbar">
        <div class="container-fluid topbar-menu">
        <div class="d-flex align-items-center gap-2">
        <!-- Topbar Brand Logo -->
        <div class="logo-topbar">
        <!-- Logo light -->
        <!-- <a href="index.html" class="logo-light">
        <span class="logo-lg">
        <img src="assets/images/logo.png" alt="logo">
        </span>
        <span class="logo-sm">
        <img src="assets/images/logo-sm.png" alt="small logo">
        </span>
        </a> -->

        <!-- Logo Dark -->

        <!-- <a href="index.html" class="logo-dark">
        <span class="logo-lg">
        <img src="assets/images/logo-black.png" alt="dark logo">
        </span>
        <span class="logo-sm">
        <img src="assets/images/logo-sm.png" alt="small logo">
        </span>
        </a> -->

        </div>

        <!-- Sidebar Menu Toggle Button -->
        <button class="sidenav-toggle-button btn btn-primary btn-icon">
        <i class="ti ti-menu-4 fs-22"></i>
        </button>

        <!-- Horizontal Menu Toggle Button -->
        <button class="topnav-toggle-button px-2" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
        <i class="ti ti-menu-4 fs-22"></i>
        </button>

        <!-- Search -->
        <!-- <div class="app-search d-none d-xl-flex">
        <input type="search" class="form-control topbar-search" name="search" placeholder="Search for something...">
        <i data-lucide="search" class="app-search-icon text-muted"></i>
        </div> -->

        <div class="app-search d-none d-xl-flex">
    <div id="currentDateTime" class="form-control topbar-search text-center fw-bold"></div>
   
</div>

        <!-- Mega Menu Dropdown -->
        <div class="topbar-item d-none d-md-flex">
        <div class="dropdown">
       
        <div class="dropdown-menu dropdown-menu-xxl p-0">
        <div class="h-100" style="max-height: 380px;" data-simplebar>
        <div class="row g-0">
        <div class="col-12">
        <div class="p-3 text-center bg-light bg-opacity-50">
        <h4 class="mb-0 fs-lg fw-semibold">Welcome to <span class="text-primary">Insurance</span></h4>
        </div>
        </div>
        </div>
        <div class="row g-0">
        <div class="col-md-4">
        <div class="p-3">
        <h5 class="mb-2 fw-semibold fs-sm dropdown-header">Dashboard & Analytics</h5>
        <ul class="list-unstyled megamenu-list">
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Sales Dashboard</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Marketing Dashboard</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Finance Overview</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">User Analytics</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Traffic Insights</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Performance Metrics</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Conversion Tracking</a>
        </li>
        </ul>
        </div>
        </div>

        <div class="col-md-4">
        <div class="p-3">
        <h5 class="mb-2 fw-semibold fs-sm dropdown-header">Project Management</h5>
        <ul class="list-unstyled megamenu-list">
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Task Overview</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Kanban Board</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Gantt Chart</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Team Collaboration</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Project Milestones</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Workflow Automation</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Timesheets & Reports</a>
        </li>
        </ul>
        </div>
        </div>

        <div class="col-md-4">
        <div class="p-3">
        <h5 class="mb-2 fw-semibold fs-sm dropdown-header">User Management</h5>
        <ul class="list-unstyled megamenu-list">
        <li>
        <a href="javascript:void(0);" class="dropdown-item">User Profiles</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Access Control</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Role Permissions</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Activity Logs</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Security Settings</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">User Groups</a>
        </li>
        <li>
        <a href="javascript:void(0);" class="dropdown-item">Authentication & Login</a>
        </li>
        </ul>
        </div> <!-- end dropdown-->
        </div> <!-- end col-->
        </div> <!-- end row-->

        </div> <!-- end .h-100-->
        </div> <!-- .dropdown-menu-->
        </div> <!-- .dropdown-->
        </div> <!-- end topbar-item -->
        </div> <!-- .d-flex-->

        <div class="d-flex align-items-center gap-2">
        <!-- Language Dropdown -->
        

        <!-- Messages Dropdown -->
       
        <!-- Notification Dropdown -->
       

        <!-- Button Trigger Customizer Offcanvas -->
       
        
        <div class="topbar-item">
        <div class="dropdown">
        <button class="topbar-link dropdown-toggle drop-arrow-none" data-bs-toggle="dropdown" data-bs-offset="0,22" type="button" data-bs-auto-close="outside" aria-haspopup="false" aria-expanded="false">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-lucide="bell" class="lucide lucide-bell fs-xxl"><path d="M10.268 21a2 2 0 0 0 3.464 0"></path><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"></path></svg>
        <span  id="topbar-alert-count" class="badge badge-square text-bg-warning topbar-badge"> {{ \App\Models\User::where('login_request', 1)->count() }}</span>
        </button>

        <div class="dropdown-menu p-0 dropdown-menu-end dropdown-menu-lg" data-popper-placement="bottom-end" style="position: absolute; inset: 0px 0px auto auto; margin: 0px; transform: translate(0px, 44px);">
        <div class="px-3 py-2 border-bottom">
        <div class="row align-items-center">
        <div class="col">
        <h6 class="m-0 fs-md fw-semibold">Notifications</h6>
        </div>
        <div class="col text-end">

        <a href="#!" class="badge text-bg-light badge-label py-1">
        <span id="alert-count">{{ \App\Models\User::where('login_request', 1)->count() }}</span> Alerts
        </a>

        </div>
        </div>
        </div>
        @php
        use Carbon\Carbon;
        $users = \App\Models\User::where('login_request', 1)->get();
        @endphp

        <div data-simplebar class="simplebar-scrollable-y">
        <div class="simplebar-content">
        @foreach($users as $user)
        <div class="dropdown-item notification-item py-2 text-wrap" id="notification-{{ $user->id }}">
        <span class="d-flex gap-2">
        <span class="avatar-md flex-shrink-0">
        <span class="avatar-title bg-danger-subtle text-danger rounded fs-22">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
        viewBox="0 0 24 24" fill="none" stroke="currentColor"
        stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
        data-lucide="server-crash" class="lucide lucide-server-crash fs-xl fill-danger">
        <path d="M6 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2"></path>
        <path d="M6 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2"></path>
        <path d="M6 6h.01"></path>
        <path d="M6 18h.01"></path>
        <path d="m13 6-4 6h6l-4 6"></path>
        </svg>
        </span>
        </span>

        <span class="flex-grow-1 text-muted">
        <a href="{{ route('approval.request') }}" class="fw-medium text-body text-decoration-none">
        <span class="fw-medium text-body">{{ $user->name }} Approval Request</span>
        <br>
        <span class="fs-xs">{{ \Carbon\Carbon::parse($user->updated_at)->diffForHumans() }}</span>

        </a>
        </span>


        <button type="button"
        class="flex-shrink-0 text-muted btn btn-link p-0 dismiss-btn"
        data-notification-id="notification-{{ $user->id }}">
        <i class="ti ti-xbox-x-filled fs-xxl"></i>
        </button>
        </span>
        </div>
        @endforeach
        </div>
        </div>

                                <div data-simplebar class="simplebar-scrollable-y">
                                    <div class="simplebar-wrapper" style="margin: 0px;">
                                        <div class="simplebar-height-auto-observer-wrapper">
                                            <div class="simplebar-height-auto-observer">

                                            </div>
                                        </div>
                                        <div class="simplebar-mask">
                                            <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                                <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden scroll;">
                                                    <div class="simplebar-content" style="padding: 0px;">
                                    <!-- item 1 -->
                            




                                    <!-- item 2 -->
                                  

                                    <!-- item 3 -->
                               

                                    <!-- item 4 -->
                                  

                                    <!-- item 5 -->
                               

                                    <!-- item 6 -->
                               
                                    <!-- item 7 -->
                                 

                                    <!-- item 8 -->
                                   

                                    <!-- item 9 -->
                                

                                    <!-- item 10 -->
                                  

                                    <!-- item 11 -->
                                 

                                    <!-- item 12 -->
                               
                                    <!-- item 13 -->
                              

                                    <!-- item 14 -->
                               
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="simplebar-placeholder" style="width: 318px; height: 865px;">

                    </div>
                </div>
                                
                                <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                    <div class="simplebar-scrollbar" style="width: 0px; display: none;">

                                    </div>
                                </div>
                                <div class="simplebar-track simplebar-vertical" style="visibility: visible;">
                                    <div class="simplebar-scrollbar" style="height: 104px; display: block; transform: translate3d(0px, 0px, 0px);">

                                    </div>
                                </div>
                            </div> <!-- end dropdown-->                   

                            </div>
                        </div>
                    </div>



        <!-- Light/Dark Mode Button -->
        <div class="topbar-item  d-sm-flex">
        <button class="topbar-link" id="light-dark-mode" type="button">
        <i data-lucide="moon" class="fs-xxl mode-light-moon"></i>
        <i data-lucide="sun" class="fs-xxl mode-light-sun"></i>
        </button>
        </div>

        <!-- User Dropdown -->
        <div class="topbar-item nav-user">
        <div class="dropdown">
        <a class="topbar-link dropdown-toggle drop-arrow-none px-2" data-bs-toggle="dropdown" data-bs-offset="0,16" href="#!" aria-haspopup="false" aria-expanded="false">
       
        @if(Auth::user() && Auth::user()->role == 1)
        <img src="{{ Storage::url(Auth::user()->profile_image) }}" width="32" class="rounded-circle me-lg-2 d-flex" alt="user-image">
        @endif

        @if(Auth::user() && Auth::user()->role ==2)
        <img src="{{ Storage::url(Auth::user()->profile_image) }}" width="32" class="rounded-circle me-lg-2 d-flex" alt="user-image">
        @endif
        

        <div class="d-lg-flex align-items-center gap-1 d-none">
        <h5 class="my-0">{{ Auth::user()->name }} </h5>
        <i class="ti ti-chevron-down align-middle"></i>
        </div>
        </a>
        <div class="dropdown-menu dropdown-menu-end">
        <!-- Header -->


        <!-- <div class="dropdown-header noti-title text-center px-3 py-1">
        <h6 class="fw-bold text-primary fs-6 m-0">Welcome back!</h6>
        </div> -->


        @if(Auth::user() && Auth::user()->role == 1)
        <a href="javascript:void(0);" 
        class="dropdown-item" 
        data-bs-toggle="modal" 
        data-bs-target="#adminProfileModal">
        <i class="ti ti-user-circle me-2 fs-17 align-middle"></i>
        <span class="align-middle">Profile</span>
        </a>
        @endif

       

        <!-- Logout -->
       <a href="javascript:void(0);" 
   class="dropdown-item text-danger fw-semibold" 
   data-bs-toggle="modal" 
   data-bs-target="#logoutModal">
    <i class="ti ti-logout-2 me-2 fs-17 align-middle"></i>
    <span class="align-middle">Log Out</span>
</a>


        </div>

        </div>
        </div>
        </div>
        </div>
        </header>






        <!-- Admin Profile Modal -->
<div class="modal fade" id="adminProfileModal" tabindex="-1" aria-labelledby="adminProfileModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="adminProfileModalLabel">Admin Profile</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

  <form method="POST" action="{{ route('admin.profile.update') }}" enctype="multipart/form-data">

        @csrf
        <div class="modal-body">
          @php
              $admin = \App\Models\User::where('role', 1)->first(); // or use auth()->user() if logged-in user is admin
          @endphp

          <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" value="{{ old('name', $admin->name) }}" class="form-control" required>
          </div>

          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" value="{{ old('email', $admin->email) }}" class="form-control" required>
          </div>


<div class="mb-3">
    <label for="profile_image">Profile Picture</label><br>

    {{-- Show existing image (if any) --}}
    @if (!empty($admin->profile_image))
        @php
            $profileImagePath = filter_var($admin->profile_image, FILTER_VALIDATE_URL)
                ? $admin->profile_image
                : asset('storage/' . ltrim($admin->profile_image, '/'));
        @endphp
     <div class="mt-3" id="existing-logo-wrapper">
        <img src="{{ $profileImagePath }}" alt="Current Profile Picture"
             style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%; border: 1px solid #ccc; margin-bottom: 10px;">
     </div>
    @else
        <p><em>No profile picture uploaded.</em></p>
    @endif

    {{-- File input --}}
    <input type="file" name="profile_image" id="profile_image" class="form-control" accept="image/*">

    {{-- Live preview of newly selected image --}}
    <div class="mt-3">
        <img id="preview-cropped" src="#" class="img-fluid"
             style="max-width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 1px solid #aaa; display: none;" />
    </div>
</div>


        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Update Profile</button>
        </div>
      </form>
    </div>
  </div>
</div>






   <!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Crop Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div>
          <img id="image-to-crop" src="" class="img-fluid" />
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" id="cropImageBtn" class="btn btn-primary">Crop & Save</button>
      </div>
    </div>
  </div>
</div>


<!-- Cropper.js CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css" rel="stylesheet" />

<!-- Cropper.js JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">



<script>
    document.addEventListener('DOMContentLoaded', function () {
        const dismissButtons = document.querySelectorAll('.dismiss-btn');

        dismissButtons.forEach(button => {
            button.addEventListener('click', function () {
                const notificationId = this.getAttribute('data-notification-id');
                const notificationElement = document.getElementById(notificationId);

                if (notificationElement) {
                    notificationElement.remove();
                    function decrementCounter(counterId) {
                        const counter = document.getElementById(counterId);
                        if (counter) {
                            let currentCount = parseInt(counter.textContent);
                            if (!isNaN(currentCount) && currentCount > 0) {
                                counter.textContent = currentCount - 1;
                            }
                        }
                    }

                    // Decrement both counters
                    decrementCounter('alert-count');
                    decrementCounter('topbar-alert-count');

                    // Optional: Send AJAX request to mark notification as handled
                }
            });
        });
    });
</script>



<script>

    function updateNotifications() {
        fetch('/notifications/login-requests')
            .then(response => response.json())
            .then(data => {
             
                document.getElementById('topbar-alert-count').innerText = data.count;
                document.getElementById('alert-count').innerText = data.count;

      
                const list = document.getElementById('notification-list');
                list.innerHTML = '';

                if (data.count === 0) {
                    list.innerHTML = '<div class="px-3 py-2 text-center text-muted">No new login requests.</div>';
                    return;
                }

                data.users.forEach(user => {
                    const item = document.createElement('div');
                    item.classList.add('notification-item', 'px-3', 'py-2', 'border-bottom');

                    const createdAt = new Date(user.created_at);
                    const timeAgo = timeSince(createdAt);

                    item.innerHTML = `
                        <strong>${user.name}</strong> requested login.<br>
                        <small>${timeAgo} ago</small>
                    `;
                    list.appendChild(item);
                });
            })
            .catch(err => {
                console.error('Failed to fetch notifications:', err);
            });
    }

    function timeSince(date) {
        const seconds = Math.floor((new Date() - date) / 1000);
        let interval = Math.floor(seconds / 31536000);
        if (interval > 1) return interval + " years";
        interval = Math.floor(seconds / 2592000);
        if (interval > 1) return interval + " months";
        interval = Math.floor(seconds / 86400);
        if (interval > 1) return interval + " days";
        interval = Math.floor(seconds / 3600);
        if (interval > 1) return interval + " hours";
        interval = Math.floor(seconds / 60);
        if (interval > 1) return interval + " minutes";
        return Math.floor(seconds) + " seconds";
    }

    setInterval(updateNotifications, 10000);
    updateNotifications();
    
import Echo from 'laravel-echo';
window.Pusher = require('pusher-js');

window.Echo = new Echo({
    broadcaster: 'pusher',
    key: import.meta.env.VITE_REVERB_APP_KEY,
    wsHost: import.meta.env.VITE_REVERB_HOST,
    wsPort: import.meta.env.VITE_REVERB_PORT,
    forceTLS: import.meta.env.VITE_REVERB_SCHEME === 'https',
    encrypted: import.meta.env.VITE_REVERB_SCHEME === 'https',
    disableStats: true,
    enabledTransports: ['ws', 'wss'],
});

// Listen for broadcast and call updateNotifications only once per event
window.Echo.channel('login-requests')
    .listen('.LoginRequestNotification', (event) => {
        console.log('🔔 New login request received via WebSocket:', event);
        updateNotifications();
    });


    // Ensure Echo is configured & loaded

// window.Echo.channel('login-requests')
//   .listen('.LoginRequestNotification', (e) => {
//     console.log('New login request:', e);

//     const badge = document.getElementById('topbar-alert-count');
//     const alertCount = document.getElementById('alert-count');
//     const current = parseInt(badge.innerText) || 0;

//     badge.innerText = current + 1;
//     alertCount.innerText = current + 1;

//     const container = document.querySelector('.simplebar-content');
//     if (container) {
//       const html = `
//         <div class="dropdown-item notification-item py-2 text-wrap" id="notification-${e.user_id}">
//           <span class="d-flex gap-2">
//             <span class="avatar-md flex-shrink-0">
//               <span class="avatar-title bg-danger-subtle text-danger rounded fs-22">🔔</span>
//             </span>
//             <span class="flex-grow-1 text-muted">
//               <a href="/approval/request" class="fw-medium text-body text-decoration-none">
//                 <span class="fw-medium text-body">${e.name} Approval Request</span><br>
//                 <span class="fs-xs">just now</span>
//               </a>
//             </span>
//             <button type="button" class="flex-shrink-0 text-muted btn btn-link p-0 dismiss-btn" data-notification-id="notification-${e.user_id}">
//               ✖
//             </button>
//           </span>
//         </div>
//       `;
//       container.insertAdjacentHTML('afterbegin', html);
//     }
//   });



</script>


<script>
function updateDateTime() {
    const now = new Date();

    let d = String(now.getDate()).padStart(2, '0');
    let m = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    let y = now.getFullYear();

    let h = now.getHours();
    let ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12;
    h = h ? h : 12; // 0 should be 12
    let min = String(now.getMinutes()).padStart(2, '0');
    let s = String(now.getSeconds()).padStart(2, '0');

    const formatted = `${d}-${m}-${y} ${h}:${min}:${s} ${ampm}`;
    document.getElementById('currentDateTime').textContent = formatted;
}

// Initial call and update every second
updateDateTime();
setInterval(updateDateTime, 1000);
</script>








<script>
let cropper;
const logoInput = document.getElementById('profile_image');
const imageToCrop = document.getElementById('image-to-crop');
const preview = document.getElementById('preview-cropped');

logoInput.addEventListener('change', function (e) {
    const file = e.target.files[0];
    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function (event) {
            imageToCrop.src = event.target.result;
            new bootstrap.Modal(document.getElementById('cropModal')).show();
        };
        reader.readAsDataURL(file);
    }
});

document.getElementById('cropModal').addEventListener('shown.bs.modal', function () {
    cropper = new Cropper(imageToCrop, {
        aspectRatio: 1, // Change to 16 / 9 or other if needed
        viewMode: 1,
        autoCropArea: 1,
    });
});

document.getElementById('cropModal').addEventListener('hidden.bs.modal', function () {
    if (cropper) {
        cropper.destroy();
        cropper = null;
    }
});

document.getElementById('cropImageBtn').addEventListener('click', function () {
    const canvas = cropper.getCroppedCanvas({
        width: 500,
        height: 500,
    });

    canvas.toBlob(function (blob) {
        const url = URL.createObjectURL(blob);
        preview.src = url;
        preview.style.display = 'block';

        // Optional: replace file input value with cropped blob (if submitting via AJAX)
        const fileInput = document.getElementById('profile_image');
        const dataTransfer = new DataTransfer();
        const croppedFile = new File([blob], "cropped_logo.png", { type: "image/png" });
        dataTransfer.items.add(croppedFile);
        fileInput.files = dataTransfer.files;

        bootstrap.Modal.getInstance(document.getElementById('cropModal')).hide();
    });
});
</script>



<script>
    document.getElementById('profile_image').addEventListener('change', function (event) {
        const preview = document.getElementById('preview-cropped');
              const existingLogo = document.getElementById('existing-logo-wrapper');
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.onload = function (e) {
                preview.src = e.target.result;
                preview.style.display = 'block';

                // Hide existing saved logo if it exists
                if (existingLogo) {
                    existingLogo.style.display = 'none';
                }
            };

            reader.readAsDataURL(file);
        } 

        else 
            {    
            preview.style.display = 'none';
            if (existingLogo) {
                existingLogo.style.display = 'block';
            }
        }
    });
</script>
<!-- <script src="{{ asset('assets/js/vendors.min.js') }}"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> -->


@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Users</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Users</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <!-- /.card -->

          <div class="card">
            <div class="card-header d-flex justify-content-end">
              <a class="btn btn-success" href="{{ route('users.create') }}">
                <i class="fas fa-plus"></i> Add User
              </a>
            </div>
            <div class="card-body">
              <table id="usersTable" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>User Type</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @foreach($users as $user)
                  <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->phone_number }}</td>

                    <td>
                      @if ($user->role !== 'admin')
                      @if ($user->user_type == 0)
                      <span class="badge badge-success">Customer</span>
                      @elseif ($user->user_type == 1)
                      <span class="badge badge-primary">Field Agent</span>
                      @else
                      <!-- Optional: unknown user_type -->
                      <!-- <span class="badge badge-secondary">Unknown</span> -->
                      @endif
                      @endif

                    </td>

                    <td>
                      <a href="{{ route('users.edit', $user->id) }}" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                      </a>
                      <form action="{{ route('users.destroy', $user->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?');">
                          <i class="fas fa-trash"></i> Delete
                        </button>
                      </form>
                    </td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>


<script>
 $(document).ready(function() {
    const sound = document.getElementById('notificationSound');
    let lastId = 0;

    // Function to get the current latest ID without playing sound (initial setup)
    function initLastId() {
        $.get("{{ route('pharmacy-prescriptions.checkNew') }}", function(data) {
            lastId = data.latest_id || 0;
        });
    }

    // Function to check for new prescriptions and play sound only if new ID found
    function checkNewPrescriptions() {
        $.get("{{ route('pharmacy-prescriptions.checkNew') }}", function(data) {
            if (data.latest_id > lastId) {
                sound.muted = false; // ensure sound is unmuted
                sound.play();
                lastId = data.latest_id; // update lastId so we don't play repeatedly
            }
        });
    }

    initLastId(); // Initialize lastId first

    setInterval(checkNewPrescriptions, 5000);
});
</script>

  
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- jQuery -->
<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<!-- Page specific script -->
<script>
  $(function() {
    $("#usersTable").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"]
    }).buttons().container().appendTo('#usersTable_wrapper .col-md-6:eq(0)');
  });
</script>
@endsection

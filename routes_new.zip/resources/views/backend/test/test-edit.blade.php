@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Edit Test</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item"><a href="{{ route('tests') }}">Test</a></li>
            <li class="breadcrumb-item active">Edit Test</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Test Details</h3>
            </div>
            @if ($errors->any())
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
            @endif
            <div class="card-body">
              <form action="{{ route('tests.update_test', $test->id) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT') <!-- For edit/update -->

    <!-- Clinic Dropdown -->

  <!-- Clinic Checkbox Selection -->
<div class="form-group">
    <label for="clinic_selection">Laboratory Selection</label><br>

    <!-- All Clinics -->
    <div class="form-check">
        <input class="form-check-input clinic-checkbox" type="checkbox" id="all_clinics"
               name="clinic_selection" value="all"
               {{ $test->clinic_id === null ? 'checked' : '' }}>
        <strong><label class="form-check-label" for="all_clinics">All Laboratory</label></strong>
    </div>

    <!-- Individual Clinics -->
    @foreach ($clinics as $clinic)
        <div class="form-check">
            <input class="form-check-input clinic-checkbox" type="checkbox" id="clinic_{{ $clinic->id }}"
                   name="clinic_selection" value="{{ $clinic->id }}"
                   {{ $test->clinic_id == $clinic->id ? 'checked' : '' }}>
            <label class="form-check-label" for="clinic_{{ $clinic->id }}">{{ $clinic->clinic_name }}</label>
        </div>
    @endforeach

    <small class="form-text text-muted">Only one selection is allowed: "All Laboratory" or one.</small>
</div>

    <!-- Test Name -->
    <div class="form-group">
        <label for="test_name">Test Name</label>
        <input type="text" class="form-control" id="test_name" name="test_name"
               value="{{ old('test_name', $test->test_name) }}" required>
    </div>

    <!-- Amount -->
    <div class="form-group">
        <label for="amount">Amount</label>
        <input type="text" class="form-control" id="amount" name="amount"   value="{{ old('amount', $test->amount) }}"  required oninput="validateAmountInput(this)">
        <small id="amountError" style="color: red; display: none;">Only digits is possible</small>

    </div>

    <!-- Description -->
    <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" id="description" name="description" rows="3"
                  placeholder="Enter Description">{{ old('description', $test->description) }}</textarea>
    </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{ route('tests') }}" class="btn btn-secondary">Cancel</a>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<audio id="notificationSound" src="{{ asset('storage/sound/notification.mp3') }}" preload="auto"></audio>

<script>
 $(document).ready(function() {
    const sound = document.getElementById('notificationSound');
    let lastId = 0;

    // Function to get the current latest ID without playing sound (initial setup)
    function initLastId() {
        $.get("{{ route('pharmacy-prescriptions.checkNew') }}", function(data) {
            lastId = data.latest_id || 0;
        });
    }

    // Function to check for new prescriptions and play sound only if new ID found
    function checkNewPrescriptions() {
        $.get("{{ route('pharmacy-prescriptions.checkNew') }}", function(data) {
            if (data.latest_id > lastId) {
                sound.muted = false; // ensure sound is unmuted
                sound.play();
                lastId = data.latest_id; // update lastId so we don't play repeatedly
            }
        });
    }

    initLastId(); // Initialize lastId first

    setInterval(checkNewPrescriptions, 5000);
});
</script>




<script>
  function validateAmountInput(input) 
  {
    // Only allow digits and at most one decimal point
    const cleanedValue = input.value.replace(/[^0-9.]/g, '');

    // Count how many decimal points are in the cleaned value
    const decimalCount = (cleanedValue.match(/\./g) || []).length;

    if (cleanedValue !== input.value || decimalCount > 1) 
    {
      // Show error message
      document.getElementById('amountError').style.display = 'block';

      // Remove extra decimal points if any
      let parts = cleanedValue.split('.');

      if (parts.length > 2) 
      {
        // Reconstruct with only the first decimal point
        input.value = parts[0] + '.' + parts.slice(1).join('').replace(/\./g, '');
      } 
      else 
      {
        input.value = cleanedValue;
      }
    } 
    else 
    {
      // Hide error message
      document.getElementById('amountError').style.display = 'none';
    }
  }
</script>


<script>
document.addEventListener("DOMContentLoaded", function () {
    const checkboxes = document.querySelectorAll(".clinic-checkbox");

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener("change", function () {
            if (this.checked) {
                checkboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
            }
        });
    });
});
</script>

@endsection

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Od Report Reliance</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div style="text-align: right;">
        <!-- <img src="image.png" alt=""> -->
    </div>


    <div style="text-align: center;">
        <h4>
            OD INVESTIGATION REPORT-{{$finalReport->insurance_com_name}}
        </h4>
    </div>

    <table>
        <tr>
            <td>Name of Customer</td>
            <td>{{ $finalReport->customer_name ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td>Contact Details of Customer</td>
            <td>{{ $finalReport->customer_present_address ?? 'N/A' }}<br/>
              Phone no:{{ $finalReport->customer_phone ?? 'N/A' }}<br/>
              Email: {{ $finalReport->customer_email ?? 'N/A' }} 
        </td>

        </tr>
        <tr>
            <td>Policy Date</td>
            <td>             {{ $finalReport->customer_policy_start ? \Carbon\Carbon::parse($finalReport->customer_policy_start)->format('d-m-Y') : 'N/A' }} - 

                    {{ $finalReport->customer_policy_end ? \Carbon\Carbon::parse($finalReport->customer_policy_end)->format('d-m-Y') : 'N/A' }}</td>
        </tr>
        <tr>
            <td>Policy No</td>
            <td>{{ $finalReport->customer_policy_no ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td>Crime Number</td>
            <td>{{ $finalReport->crime_number ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td>Police Station</td>
            <td>{{ $finalReport->police_station ?? 'N/A' }}</td>
        </tr>
        <tr>
            <td>Case Type</td>
            <td>{{ $finalReport->customer_insurance_type ?? 'N/A' }}</td>
        </tr>
        <tr>
          <td>Investigation Date</td>
            <td>{{ $finalReport->case_assign_date ? \Carbon\Carbon::parse($finalReport->case_assign_date)->format('d-m-Y') : 'N/A' }}</td>
        </tr>


        @php
        $groupedQuestions = $validQuestions12->groupBy('data_category');


        $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
        return !empty($finalReport->{$question->column_name});
        });
        });
        @endphp

        @foreach($filteredGroups as $category => $questions)


        @foreach($questions->where('input_type', '!=', 'file') as $question)
        @php
        $answer = $finalReport->{$question->column_name} ?? null;
        $displayQuestion = $questions12[$question->unique_key]->question ?? $question->question ?? '—';   
        @endphp

        @if(!empty($answer))
        <tr>              
            <td>{{ $displayQuestion }}</td>
            <td>{{ $answer }}</td>
        </tr>
        @endif
        @endforeach
        @endforeach

        

    </table>

    <table>

       @php
    $groupedQuestions = $validQuestions12->groupBy('data_category');
    $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];

    // Keep only groups that have at least one file-type question with data
    $filteredGroups = $groupedQuestions->filter(function ($questions, $category) use ($finalReport) {
        return $questions->contains(function ($question) use ($finalReport) {
            return $question->input_type === 'file' && !empty($finalReport->{$question->column_name});
        });
    });
@endphp

@foreach($filteredGroups as $category => $questions)

    {{-- Loop through file-type questions --}}
    @php $images = []; @endphp
    @foreach($questions->where('input_type', 'file') as $question)
        @php
            $filePath = $finalReport->{$question->column_name} ?? null;

            // Decode if JSON like ["uploads/xyz.png"]
            if ($filePath && is_string($filePath) && str_starts_with($filePath, '[')) {
                $decoded = json_decode($filePath, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $filePath = $decoded[0]; // take first file
                }
            }

            $isImage = false;
            if ($filePath) {
                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
                $isImage = in_array($ext, $imageExtensions);
            }

            if ($isImage && !empty($filePath)) {
                $images[] = [
                    'path' => $filePath,
                    'label' => $question->question
                ];
            }
        @endphp
    @endforeach

    {{-- Show images in rows of 2 --}}
    @foreach(array_chunk($images, 2) as $row)

        <tr>
                    @foreach($row as $img)
            <td style="text-align: justify;">
                <h4>{{ $img['label'] }}</h4><br>

               <img src="{{ storage_path('app/public/' . $img['path']) }}" 
     alt="{{ $img['label'] }}" 
     style="max-width:100%;">
        </td>
            @endforeach
            @if(count($row) < 2)
                
            @endif
        </tr>
    @endforeach
@endforeach
            
    </table>
<br/><br/><br/>

    <div style="display: flex; justify-content: space-between;">

     <div>Executive Name:{{ collect([
    $finalReport->driver_executive,
    $finalReport->garage_executive,
    $finalReport->spot_executive,
    $finalReport->owner_executive,
    $finalReport->accident_executive
])->filter()->unique()->implode(', ') ?: 'N/A' }}</div>
        <div>{{ \Carbon\Carbon::parse($finalReport->created_At)->format('d.m.Y') }}</div>
       
    </div>



</body>

</html>
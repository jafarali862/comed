<!DOCTYPE html>
<html>
<head>
    <title>Upload Company Logo</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>
    <h2>Upload Company Logo</h2>

    @if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif

    @if($errors->any())
        <div style="color: red;">
            @foreach($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    <form action="{{ route('company.logo.upload') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label for="logo">Select Logo:</label>
        <input type="file" name="logo" id="logo" accept=".png,.jpg,.jpeg,.webp" required>

        <button type="submit">Upload</button>
    </form>

    @if(isset($logoPath))
        <h3>Current Logo:</h3>
        <img src="{{ Storage::url($logoPath) }}" alt="Company Logo" style="max-width: 128px; margin-top: 10px;">
    @endif
</body>
</html>

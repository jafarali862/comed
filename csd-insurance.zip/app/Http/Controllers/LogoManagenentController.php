<?php

namespace App\Http\Controllers;

use App\Models\CompanyLogo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;


class LogoManagenentController extends Controller
{

    public function index()
    {
        $logos = CompanyLogo::paginate(10);
        return view('dashboard.logo.index', compact('logos'));
    }

    public function getLogo()
    {
        return view('dashboard.logo.create');
    }

     public function index2()
    {
        $logoPath = DB::table('company_logos')->where('id', 1)->value('logo_path');
        return view('dashboard.logo.company_logo', compact('logoPath'));
    }


       public function store(Request $request)
    {
       $request->validate([
        'logo' => 'required|image|mimes:jpeg,jpg,png,webp|max:150',  // KB
    ]);

    $file = $request->file('logo');
    $extension = $file->getClientOriginalExtension();
    $filename = 'company_logo_' . time() . '_' . Str::random(5) . '.' . $extension;

    // ✅ Create the image manager with GD driver
    $manager = new ImageManager(new Driver());

    // ✅ Read the image
    $image = $manager->read($file->getRealPath());

    // Enforce 1:1 aspect ratio
    $width = $image->width();
    $height = $image->height();
    $size = min($width, $height);

    $image->crop($size, $size, intval(($width - $size) / 2), intval(($height - $size) / 2))
          ->resize(256, 256);

    $path = 'logos/' . $filename;

    // Encode and store
    $encoded = $image->toJpeg(75); // You can also use toWebp(), etc.
    // Storage::put($path, (string) $encoded);
Storage::disk('public')->put($path, (string) $encoded);

    // Update the DB
    DB::table('company_logos')->where('id', 1)->update([
        'logo_path' => $path
    ]);

    return redirect()->route('company.logo.form')->with('success', 'Logo uploaded successfully');
    }


    public function storeLogo(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:company_logos,email',
            'phone' => 'required|string|max:15',
            'place' => 'required|string|max:255',
            'logo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            
        ]);

        
        if ($request->hasFile('logo')) {
           
            $logoPath = $request->file('logo')->store('logos', 'public');
        }

        CompanyLogo::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'place' => $request->place,
            'logo' => $logoPath,
            
        ]);

        return redirect()->route('logos')->with('success', 'Company logo added successfully!');
    }

    public function editLogo($id)
    {
        
        $logo = CompanyLogo::findOrFail($id);
        return view('dashboard.logo.edit', compact('logo'));
    }

    public function updateLogo(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:company_logos,email,' . $id,  
            'phone' => 'required|string|max:15',
            'place' => 'required|string|max:255',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', 
            
        ]);

        $logo = CompanyLogo::findOrFail($id);

        
        $logo->name = $request->name;
        $logo->email = $request->email;
        $logo->phone = $request->phone;
        $logo->place = $request->place;
        

        
        if ($request->hasFile('logo')) {
            
            if (file_exists(public_path('storage/' . $logo->logo))) {
                unlink(public_path('storage/' . $logo->logo));
            }

            $logoPath = $request->file('logo')->store('logos', 'public');
            $logo->logo = $logoPath;
        }

        $logo->save();

        session()->flash('success', 'Company logo updated successfully!');
        return redirect()->route('logo.edit',['id'=>1]);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Test extends Model
{
    use HasFactory;

    protected $fillable = [
        'test_name',
        'clinic_id',
        'description',   
        'amount',   
    ];

    public function clinic()
    {
    return $this->belongsTo(Clinic::class, 'clinic_id');
    }

}

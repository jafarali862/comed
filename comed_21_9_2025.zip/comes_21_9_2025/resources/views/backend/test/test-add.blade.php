@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Add Tests</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
            <li class="breadcrumb-item"><a href="{{ route('tests') }}">Tests</a></li>
            <li class="breadcrumb-item active">Add Tests</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Add Tests</h3>
            </div>
            @if ($errors->any())
            <div class="alert alert-danger">
              <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
              </ul>
            </div>
            @endif
            <div class="card-body">
              <form action="{{ route('tests.store_test') }}" method="POST" enctype="multipart/form-data">
                @csrf


            <div class="form-group">
            <label>Clinic Selection</label><br>

            <div class="form-check">
          <input class="form-check-input clinic-checkbox" type="checkbox" id="all_clinics" name="clinic_selection" value="all" checked>
          <label class="form-check-label" for="all_clinics"><strong>All Clinics</strong></label>
          </div>

       
            @foreach ($clinics as $clinic)
            <div class="form-check">
            <input class="form-check-input clinic-checkbox" type="checkbox" id="clinic_{{ $clinic->id }}" name="clinic_selection" value="{{ $clinic->id }}">
            <label class="form-check-label" for="clinic_{{ $clinic->id }}">{{ $clinic->clinic_name }}</label>
            </div>
            @endforeach
            </div>





            




                <div class="form-group">
                  <label for="test_name">Test Name</label>
                  <input type="text" class="form-control" id="test_name" name="test_name"  required>
                </div>

                <div class="form-group">
                  <label for="amount">Amount</label>
                  <input type="text" class="form-control" id="amount" name="amount" required>
                </div>

              
                <div class="form-group">
                  <label for="description">Description</label>
                  <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter Description"></textarea>
                </div>

               

                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="{{ route('tests') }}" class="btn btn-secondary">Cancel</a>

              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>



<script>
document.addEventListener("DOMContentLoaded", function () {
    const checkboxes = document.querySelectorAll(".clinic-checkbox");

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener("change", function () {
            // Uncheck all others when one is selected
            if (this.checked) {
                checkboxes.forEach(cb => {
                    if (cb !== this) cb.checked = false;
                });
            }
        });
    });
});
</script>


<!-- /.content-wrapper -->
@endsection

@extends('backend.layouts.app')


@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pharmacy Prescriptions</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                        <li class="breadcrumb-item active">Pharmacy Prescriptions</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>


 

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div>
                                <!-- Status Filter Radio Buttons -->
                                <!-- <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="0" @if($val==0) checked @endif> New</label> -->


                                  <!-- <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="0"> New</label>      
                                <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="1"> Processing</label>
                                <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="2"> Confirmed</label>
                                <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="3"> Delivered</label>
                                <label><input type="radio" id="status" onclick="statusChecker()" name="status_filter"
                                        value="4"> Rejected</label> -->
                                
                                 
                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="0"
                                    {{ request('status_filter', '0') == '0' ? 'checked' : '' }}>
                                    New
                                    </label>

                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="1"
                                    {{ request('status_filter') == '1' ? 'checked' : '' }}>
                                    Processing
                                    </label>

                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="2"
                                    {{ request('status_filter') == '2' ? 'checked' : '' }}>
                                    Confirmed
                                    </label>


                                    <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="3"
                                    {{ request('status_filter') == '3' ? 'checked' : '' }}>
                                    Assigned Delivery
                                    </label>


                                     <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="4"
                                    {{ request('status_filter') == '4' ? 'checked' : '' }}>
                                    Completed
                                    </label>

                                     <label>
                                    <input type="radio" onclick="statusChecker()" name="status_filter" value="5"
                                    {{ request('status_filter') == '5' ? 'checked' : '' }}>
                                     Rejected                                   
                                     </label>


                            </div>

                            <div>
                                <p class="text-danger" id="error_in_date"></p>
                                <label for="start_date">Start Date:</label>
                                <input type="date" id="start_date">
                                <label for="end_date">End Date:</label>
                                <input type="date" id="end_date" onchange="dateWiseSearch()">
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>

                                        <th>User</th>
                                        <th>Patient</th>
                                        <th>Pharmacy</th>
                                         <th>Phone</th>
                                        <th>Prescription Image</th>
                                        <th>Delivery Address</th>
                                        <th>Latitude & Longitude</th>

                                        <th class="payment-method-th">Payment Method</th>



                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                 
                                 <tbody id="pharPresTable">
        <!-- rows will be injected here dynamically -->
    </tbody>
</table>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel"
        aria-hidden="true" backdrop="static" data-bs-backdrop="static" data-bs-keyboard="true">
        <div class="modal-dialog " style="max-width: 80%;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Pharmacy Prescription</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Content will be loaded dynamically with AJAX -->
                </div>
            </div>
        </div>
    </div>


    
</div>



<!-- Prescription Modal -->
<div class="modal fade" id="prescriptionModal" tabindex="-1" role="dialog" aria-labelledby="prescriptionModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Prescription Images</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body d-flex flex-wrap" id="prescriptionImages">
        <!-- Images will be injected here -->
      </div>
    </div>
  </div>
</div>





<!-- Include necessary scripts -->



<style>
div#example1_info
 {
    display: none;
}


div#example1_paginate 
{
    display: none;
}



.img-thumbnail
{
max-width: 100% !important;
max-height: unset !important;
}


</style>

    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

    <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script> -->

<script src="{{ asset('plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>

<script>
    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false
        });
    });

    // $('.btn-close').on('click', function() 
    // {
    //     location.reload();
    //     //$('#editModal').modal('hide');    
    // });
   
    // $('#editModal').on('hide.bs.modal', function () 
    // {
    // // Add any custom CSS or class on modal hide
    // $(this).addClass('custom-hidden-style');
    // });




$(document).ready(function () {
    statusChecker(1); // load default status=0
});


    $('#close').on('click', function() {
        console.log('Closing modal');
        $('#editModal').modal('hide');
    });

    $(document).on('click', '.open-edit-modal', function() {
        let prescriptionId = $(this).data('id');
        let url = `/pharmacy-prescriptions2/${prescriptionId}/edit`;

        $.ajax({
            url: url,
            method: 'GET',
            success: function(response) {
                $('#editModal .modal-body').html(response);
                $('#editModal').modal('show');
                 
            },
            error: function(xhr) {
                alert('Failed to load prescription details. Please try again.');
            }
        });
    });

//    function statusChecker(page = 1) {
//     const status = $('input[name="status_filter"]:checked').val();

//     if (status !== undefined) {
//         $.ajax({
//             url: '{{ route("pharmacy-prescription.status") }}',
//             method: 'GET',
//             data: {
//                 status: status,
//                 page: page
//             },
//             success: function(response) {
//                 $('#pharPresTable').html(response.output);
//                 $('#paginate').html(response.pagination); // this should be returned by controller
//             },
//             error: function() {
//                 alert('Failed to load data. Try again.');
//             }
//         });
//     }
// }



function statusChecker(page = 1) 
{
    const status = $('input[name="status_filter"]:checked').val();

    if (status !== undefined) 
    {
    $.ajax({
        url: '{{ route("pharmacy-prescription2.status") }}',
        method: 'GET',
        data: {
            status: status,
            page: page
        },
        success: function(response) {
            $('#pharPresTable').html(response.output);
            $('#paginate').html(response.pagination);

            // Show/hide Payment Method column
            if (status === '1' || status === '2' || status === '3' || status === '4') {
    $('.payment-method-th, .payment-method-td').show();
} else {
    $('.payment-method-th, .payment-method-td').hide();
}
        },
        error: function() {
            alert('Failed to load data. Try again.');
        }
    });
    }
}


    // function statusChecker(page = 1) 
    // {
    // const status = $('input[name="status_filter"]:checked').val();

    // if (status !== undefined) {
    //     localStorage.setItem('selected_status', status);

    //     $.ajax({
    //         url: '{{ route("pharmacy-prescription.status") }}',
    //         method: 'GET',
    //         data: {
    //             status: status,
    //             page: page
    //         },
    //         success: function(response) {
    //             $('#pharPresTable').html(response.output);
    //             $('#paginate').html(response.pagination);

    //             if (status === '2') 
    //             {
    //                 $('.payment-method-th, .payment-method-td').show();
    //             }
    //             else {
    //                 $('.payment-method-th, .payment-method-td').hide();
    //             }
    //         },
    //         error: function() {
    //             alert('Failed to load data. Try again.');
    //         }
    //     });
    // }
    // }


    // $(document).ready(function () 
    // {
    // const savedStatus = localStorage.getItem('selected_status');
    // if (savedStatus) 
    // {
    //     $(`input[name="status_filter"][value="${savedStatus}"]`).prop('checked', true);
    //     statusChecker(); 
    // }
    // else 
    // {
    //     $('input[name="status_filter"][value="0"]').prop('checked', true);
    //     statusChecker();
    // }
    // });


$(document).on('click', '#paginate a', function (e) {
    e.preventDefault();
    const url = $(this).attr('href');
    const pageMatch = url.match(/page=(\d+)/);
    const page = pageMatch ? pageMatch[1] : 1;
    statusChecker(page);
});



    $(document).ready(function () {
        $('.show-prescriptions').on('click', function () {
            var images = $(this).data('images');
            var container = $('#prescriptionImages');
            container.empty();

            if (images && images.length > 0) {
                images.forEach(function (imgPath) {
                    var imgElement = `<img src="${imgPath}" class="img-thumbnail m-2" style="max-width: 200px; max-height: 200px;">`;
                    container.append(imgElement);
                });
                $('#prescriptionModal').modal('show');
            }
        });
    });







//  function statusChecker() {
//         var status = $('input[name="status_filter"]:checked').val();
//         if (status) {
//             $.ajax({
//                 url: '{{route("clinic-prescription.status")}}',
//                 method: 'GET',
//                 data: {
//                     status: status
//                 },
//                 success: function(response) {
//                     $('#pharPresTable').html(response.output);
//                     $('#paginate').html(response.pagination);
//                 },
//                 error: function(xhr) {
//                     alert('Failed to load prescription details. Please try again.');
//                 }
//             });
//         }
//     }


    $(document).ready(function () {
        // Set default start_date = yesterday, end_date = today
        let today = new Date();
        let yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        let formatDate = (date) => {
            return date.toISOString().split('T')[0]; // YYYY-MM-DD
        };

        $('#start_date').val(formatDate(yesterday));
        $('#end_date').val(formatDate(today));

        // Trigger default search
        dateWiseSearch();
    });


    function dateWiseSearch() {
        var startDate = $('#start_date').val();
        var endDate = $('#end_date').val();

        if (startDate && endDate) {
            $.ajax({
                url: '{{ route("pharmacy-prescription2.dateMatch") }}',
                method: 'GET',
                data: {
                    status: status,
                    start_date: startDate,
                    end_date: endDate
                },
                success: function(response) {
                    console.log(response);
                    $('#pharPresTable').html(response.output);
                   // $('#paginate').html(response.pagination);
                },
                error: function(xhr) {
                    alert('Failed to load prescription details. Please try again.');
                }
            });
        } else {
            $('#error_in_date').text('Please enter start date and end date');
        }

    }


 $(document).on('click', '.show-prescriptions', function () {
        const images = $(this).data('images');
        const container = $('#prescriptionImages');
        container.empty();

        if (images && images.length > 0) {
            images.forEach(function (imgUrl) {
                const imgElement = `
                    <div class="m-2 text-center">
                        <img src="${imgUrl}" class="img-thumbnail" style="max-width: 200px; max-height: 150px;">
                    </div>
                `;
                container.append(imgElement);
            });
            $('#prescriptionModal').modal('show');
        }
    });

    
 window.addEventListener("load", function() {
    statusChecker(1);
 });
   
</script>
@endsection

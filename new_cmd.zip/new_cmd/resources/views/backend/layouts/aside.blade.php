<nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                
            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </a>
                </li>
                
            </ul>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav me-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto">
                    <!-- Authentication Links -->
                    @guest
                    @if (Route::has('login'))
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                    </li>
                    @endif

                    <!-- @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif -->
                    @else
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->name }}
                        </a>

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">


                         <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                        Change Password
                        </a>
                            <a class="dropdown-item" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                {{ __('Logout') }}
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                    </li>
                    @endguest
                </ul>
            </div>
        </nav>
        <!-- /.navbar -->


        <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">

@if(session('success'))
  <div class="alert alert-success alert-dismissible fade show" role="alert" style="position: fixed; top: 20px; right: 20px; z-index: 1050;">
    {{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
@endif

  <div class="modal-dialog">
    <form method="POST" action="{{ route('password.update') }}">
      @csrf
      @method('PUT')
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <!-- <div class="mb-3">
            <label for="current_password" class="form-label">Current Password</label>
            <input type="password" name="current_password" id="current_password" class="form-control" required>
          </div> -->
          <div class="mb-3">
            <label for="new_password" class="form-label">New Password</label>
            <input type="password" name="new_password" id="new_password" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="new_password_confirmation" class="form-label">Confirm New Password</label>
            <input type="password" name="new_password_confirmation" id="new_password_confirmation" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Update Password</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>


        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4" style="height:auto;">
            <!-- Brand Logo -->
            <a href="{{route('home')}}" class="brand-link">
                <img src="{{asset('dist/img/AdminLTELogo.png')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">Health App</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item menu-open">
                            <a href="{{route('home')}}" class="nav-link {{ Route::is('home') ? 'active' : '' }}">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Dashboard </p>
                            </a>
                        </li>
                        <!-- <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-chart-pie"></i>
                                <p>
                                    Charts
                                    <i class="right fas fa-angle-left"></i>
                                </p>
                            </a>
                        </li> -->
                        <!-- <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-tree"></i>
                                <p>
                                    UI Elements
                                    <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            
                        </li> -->
                        <!-- <li class="nav-item">
                            <a href="#" class="nav-link">
                                <i class="nav-icon fas fa-edit"></i>
                                <p>
                                    Forms
                                    <i class="fas fa-angle-left right"></i>
                                </p>
                            </a>
                            
                        </li> -->

                        <!-- <li class="nav-item">
                            <a href="{{route('users.index')}}" class="nav-link {{ Route::is('users.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-user"></i>
                                <p>
                                    Users
                                </p>
                            </a>

                        </li> -->


                        <li class="nav-item">
                            
                        @if(auth()->user()->role === 'admin')
                        <a href="{{ route('users.index') }}" class="nav-link {{ Route::is('users.index') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-user"></i>
                        <p>Users</p>
                        </a>

                        @elseif(auth()->user()->role === 'user')
                        <a href="{{ route('users2.index') }}" class="nav-link {{ Route::is('users2.index') ? 'active' : '' }}">
                        <i class="nav-icon fas fa-user"></i>
                        <p>Users</p>
                        </a>
                        @endif
                        </li>


                        <li class="nav-item">
                        @if(auth()->user()->role === 'admin')
                            <a href="{{route('clinic')}}" class="nav-link {{ Route::is('clinic') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-hospital"></i>
                                <p>
                                    Laboratory
                                </p>
                            </a>
                           @elseif(auth()->user()->role === 'user' && auth()->user()->type=='2' || auth()->user()->type=='3')
                            <a href="{{route('clinic2')}}" class="nav-link {{ Route::is('clinic2') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-hospital"></i>
                                <p>
                                    Laboratory
                                </p>
                            </a>
                           @endif
                        </li>


             <li class="nav-item">
    @if(auth()->user()->role === 'admin')
        <a href="{{ route('tests') }}" class="nav-link {{ Route::is('tests') ? 'active' : '' }}">
            <i class="nav-icon fas fa-flask"></i>
            <p>Test</p>
        </a>
    @elseif(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))
        <a href="{{ route('tests2') }}" class="nav-link {{ Route::is('tests2') ? 'active' : '' }}">
            <i class="nav-icon fas fa-flask"></i>
            <p>Test</p>
        </a>
    @endif
</li>

           

                
                        <li class="nav-item">
                             @if(auth()->user()->role === 'admin')
                            <a href="{{route('pharmacies.index')}}" class="nav-link {{ Route::is('pharmacies.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-pills"></i>
                                <p>
                                    Pharmacy
                                </p>
                            </a>
                                   @elseif(auth()->user()->role === 'user' && auth()->user()->type=='1' || auth()->user()->type=='3')
                             <a href="{{route('pharmacies2.index')}}" class="nav-link {{ Route::is('pharmacies2.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-pills"></i>
                                <p>
                                    Pharmacy
                                </p>
                            </a>
                             @endif
                        </li>
                    


                        <li class="nav-item">
                             @if(auth()->user()->role === 'admin')
                            <a href="{{route('clinic-prescriptions.index')}}" class="nav-link {{ Route::is('clinic-prescriptions.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-table"></i>
                                <p>
                                    Laboratory Prescription
                                </p>
                            </a>
                      @elseif(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))

                               <a href="{{route('clinic-prescriptions2.index')}}" class="nav-link {{ Route::is('clinic-prescriptions2.index') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-table"></i>
                                <p>
                                    Laboratory Prescription
                                </p>
                            </a>
                            @endif

                        </li>

                        <li class="nav-item">
                            @if(auth()->user()->role === 'admin')
                            <a href="{{route('pharmacy-prescriptions.index')}}" class="nav-link {{ Route::is('pharmacy-prescriptions.index') ? 'active' : '' }}">
                                <i class="nav-icon far fa-plus-square"></i>
                                <p>
                                    Pharmacy Prescription
                                </p>
                            </a>

                               @elseif(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))
                            <a href="{{route('pharmacy-prescriptions2.index')}}" class="nav-link {{ Route::is('pharmacy-prescriptions2.index') ? 'active' : '' }}">
                                <i class="nav-icon far fa-plus-square"></i>
                                <p>
                                    Pharmacy Prescription
                                </p>
                            </a>
                               @endif
                        </li>


                     




                        <li class="nav-item">  
                                @if(auth()->user()->role === 'admin')                     
                            <a href="{{route('day-book')}}" class="nav-link {{ Route::is('day-book') ? 'active' : '' }}">
                            <i class="nav-icon fas fa-book"></i>

                            <p>
                            Daybook
                            </p>
                            </a>

                             @elseif(auth()->user()->role === 'user' && !empty(auth()->user()->login_id))
                            <a href="{{route('day-book-clinic')}}" class="nav-link {{ Route::is('day-book-clinic') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-book"></i>
                                <p>
                                     Daybook
                                </p>
                            </a>

                                   @elseif(auth()->user()->role === 'user' && !empty(auth()->user()->login_id2))
                            <a href="{{route('day-book2')}}" class="nav-link {{ Route::is('day-book2') ? 'active' : '' }}">
                                <i class="nav-icon fas fa-book"></i>
                                <p>
                                     Daybook
                                </p>
                            </a>
                               @endif
                        </li>

                        
                       
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

